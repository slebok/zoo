// $ANTLR 3.2 Sep 23, 2009 12:02:23 D:\\m\\antlr\\pascal\\pascal.g 2010-07-15 09:11:14

import java.util.*;
import java.io.*;
import antlr.collections.AST;
import antlr.collections.impl.*;
import antlr.debug.misc.*;
import antlr.*;
import org.antlr.runtime.CharStream;
import org.antlr.runtime.Parser;
import org.antlr.runtime.BitSet;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.Token;
import org.antlr.runtime.TokenStream;
import org.antlr.runtime.NoViableAltException;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class pascalParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "BLOCK", "IDLIST", "ELIST", "FUNC_CALL", "PROC_CALL", "SCALARTYPE", "TYPELIST", "VARIANT_TAG", "VARIANT_TAG_NO_ID", "VARIANT_CASE", "CONSTLIST", "FIELDLIST", "ARGDECLS", "VARDECL", "ARGDECL", "ARGLIST", "TYPEDECL", "FIELD", "METHOD", "ADDSUBOR", "ASSIGNEQUAL", "SIGN", "FUNC", "NODE_NOT_EMIT", "MYASTVAR", "LF", "NUM_REAL", "INTERFACE", "DOT", "PROGRAM", "LPAREN", "RPAREN", "SEMI", "UNIT", "IDENT", "IMPLEMENTATION", "USES", "LABEL", "COMMA", "CONST", "EQUAL", "CHR", "NUM_INT", "PLUS", "MINUS", "STRING_LITERAL", "TYPE", "FUNCTION", "COLON", "PROCEDURE", "DOTDOT", "CHAR", "BOOLEAN", "INTEGER", "REAL", "STRING", "PACKED", "LBRACK", "RBRACK", "ARRAY", "OF", "LBRACK2", "RBRACK2", "RECORD", "END", "CASE", "SET", "FILE", "POINTER", "VAR", "ASSIGN", "AT", "NOT_EQUAL", "LT", "LE", "GE", "GT", "IN", "OR", "STAR", "SLASH", "DIV", "MOD", "AND", "NOT", "NIL", "GOTO", "BEGIN", "IF", "THEN", "ELSE", "WHILE", "DO", "REPEAT", "UNTIL", "FOR", "TO", "DOWNTO", "WITH", "LCURLY", "RCURLY", "WS", "COMMENT_1", "COMMENT_2", "EXPONENT"
    };
    public static final int SIGN=25;
    public static final int FUNCTION=51;
    public static final int EXPONENT=108;
    public static final int LT=77;
    public static final int STAR=83;
    public static final int WHILE=95;
    public static final int MOD=86;
    public static final int CONST=43;
    public static final int POINTER=72;
    public static final int CASE=69;
    public static final int CHAR=55;
    public static final int MYASTVAR=28;
    public static final int DO=96;
    public static final int ARGLIST=19;
    public static final int ASSIGNEQUAL=24;
    public static final int NOT=88;
    public static final int FIELDLIST=15;
    public static final int EOF=-1;
    public static final int FUNC_CALL=7;
    public static final int TYPE=50;
    public static final int RPAREN=35;
    public static final int DOWNTO=101;
    public static final int STRING_LITERAL=49;
    public static final int VARIANT_CASE=13;
    public static final int ELIST=6;
    public static final int ARGDECLS=16;
    public static final int NOT_EQUAL=76;
    public static final int NUM_REAL=30;
    public static final int TYPELIST=10;
    public static final int BEGIN=91;
    public static final int IMPLEMENTATION=39;
    public static final int VAR=73;
    public static final int GOTO=90;
    public static final int ARRAY=63;
    public static final int RBRACK=62;
    public static final int GE=79;
    public static final int RECORD=67;
    public static final int ELSE=94;
    public static final int LCURLY=103;
    public static final int SCALARTYPE=9;
    public static final int OF=64;
    public static final int FILE=71;
    public static final int ARGDECL=18;
    public static final int REAL=58;
    public static final int UNIT=37;
    public static final int WS=105;
    public static final int PACKED=60;
    public static final int NIL=89;
    public static final int USES=40;
    public static final int UNTIL=98;
    public static final int FUNC=26;
    public static final int NUM_INT=46;
    public static final int OR=82;
    public static final int IDLIST=5;
    public static final int GT=80;
    public static final int FIELD=21;
    public static final int REPEAT=97;
    public static final int END=68;
    public static final int LBRACK=61;
    public static final int PROC_CALL=8;
    public static final int VARIANT_TAG_NO_ID=12;
    public static final int FOR=99;
    public static final int DOTDOT=54;
    public static final int VARDECL=17;
    public static final int AND=87;
    public static final int LPAREN=34;
    public static final int IF=92;
    public static final int AT=75;
    public static final int COMMENT_2=107;
    public static final int BOOLEAN=56;
    public static final int SLASH=84;
    public static final int THEN=93;
    public static final int IN=81;
    public static final int COMMENT_1=106;
    public static final int COMMA=42;
    public static final int EQUAL=44;
    public static final int NODE_NOT_EMIT=27;
    public static final int IDENT=38;
    public static final int PLUS=47;
    public static final int TYPEDECL=20;
    public static final int DOT=32;
    public static final int LBRACK2=65;
    public static final int WITH=102;
    public static final int CONSTLIST=14;
    public static final int INTEGER=57;
    public static final int TO=100;
    public static final int SET=70;
    public static final int MINUS=48;
    public static final int SEMI=36;
    public static final int PROCEDURE=53;
    public static final int CHR=45;
    public static final int ADDSUBOR=23;
    public static final int COLON=52;
    public static final int VARIANT_TAG=11;
    public static final int RBRACK2=66;
    public static final int LABEL=41;
    public static final int BLOCK=4;
    public static final int RCURLY=104;
    public static final int ASSIGN=74;
    public static final int PROGRAM=33;
    public static final int INTERFACE=31;
    public static final int DIV=85;
    public static final int METHOD=22;
    public static final int LE=78;
    public static final int STRING=59;
    public static final int LF=29;

    // delegates
    // delegators


        public pascalParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public pascalParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return pascalParser.tokenNames; }
    public String getGrammarFileName() { return "D:\\m\\antlr\\pascal\\pascal.g"; }


        /** Overall symbol table for translator */
        public static SymbolTable symbolTable = new SymbolTable();

        // This method decides what action to take based on the type of
        //   file we are looking at
        public  static void doFile(File f) throws Exception {
          // If this is a directory, walk each file/dir in that directory
          translateFilePath = f.getParent();
          if (f.isDirectory()) {
            String files[] = f.list();
            for(int i=0; i < files.length; i++)
            {
              doFile(new File(f, files[i]));
            }
          }
          // otherwise, if this is a Pascal file, parse it!
          else if ((f.getName().length()>4) &&
                 f.getName().substring(f.getName().length()-4).toLowerCase().equals(".pas")) {
            System.err.println("   "+f.getAbsolutePath());

            if (translateFileName == null) {
              translateFileName = f.getName(); //set this file as the one to translate
              currentFileName = f.getName();
            }

            parseFile(f.getName(),new ANTLRNoCaseFileStream(f.getAbsolutePath()));
          }
          else {
            System.err.println("Can not parse:   "+f.getAbsolutePath());
          }
        }
       //---begin adaptor code here...
       // Custom adaptor to create PascalAST node type
       private static final TreeAdaptor pascaladaptor = new CommonTreeAdaptor() {
             @Override public Object create(Token payload) {
                return new PascalAST(payload);
             }
             @Override public Object dupNode(Object old) {
                return (old==null)? null : ((PascalAST)old).dupNode();
             }
             @Override public Object errorNode(TokenStream input,
                                               Token start, Token stop,
                                               RecognitionException e) {
                return new PascalASTErrorNode(input, start, stop, e);
             }
          };
    //----end adaptor code.
        // Here's where we do the real work...
        public  static void parseFile(String f,ANTLRNoCaseFileStream s) throws Exception {
          try {
            currentFileName = f; // set this File as the currentFileName

            // Create a scanner that reads from the input stream passed to us
             pascalLexer lexer = new pascalLexer(s);

            //System.out.println(parser.getAST().toStringList());
                 TokenStream tokenStream = new CommonTokenStream(lexer);
                // Create a parser that reads from the scanner
                 pascalParser parser = new pascalParser(tokenStream);

                // set AST type to PascalAST (has symbol)
              //  parser.setASTNodeClass("PascalAST");
                 parser.setTreeAdaptor(pascaladaptor);

                // start parsing at the program rule
                program_return res=parser.program(); 

               // CommonAST t = (CommonAST)res.getTree();

                // do something with the tree
                parser.doTreeAction(f, (CommonTree)res.getTree(), parser.getTokenNames());
                //System.out.println(parser.getAST().toStringList());
                    


        // build symbol table
                
                // Get the tree out of the parser
               /* CommonTree resultTree1 = (CommonTree) res.getTree();   


            // Make an instance of the tree parser
            // PascalTreeParserSuper treeParser1 = new PascalTreeParserSuper();
            SymtabPhase treeParser1 = new SymtabPhase();

            treeParser1.setASTNodeClass("PascalAST");

            // Begin tree parser at only rule
            treeParser1.program(resultTree1);*/



    //        parser.doTreeAction(f, treeParser1.getAST(), treeParser1.getTokenNames());



           
          }
          catch (Exception e) {
            System.err.println("parser exception: "+e);
            e.printStackTrace();   // so we can get stack trace
          }
        }
        public void printTree(CommonTree t, int indent) {
    	if ( t != null ) {
    		StringBuffer sb = new StringBuffer(indent);
    		for ( int i = 0; i < indent; i++ )
    			sb = sb.append("   ");
    		for ( int i = 0; i < t.getChildCount(); i++ ) {
    			System.out.println(sb.toString() + t.getChild(i).toString());
    			printTree((CommonTree)t.getChild(i), indent+1);
    		}
    	}
    }
        public void doTreeAction(String f, CommonTree t, String[] tokenNames) {
          if ( t==null ) return;
          if ( showTree ) {
            printTree(t,0);
           /*  ((CommonAST)t).setVerboseStringConversion(true, tokenNames);
             ASTFactory factory = new ASTFactory();
             AST r = factory.create(0,"AST ROOT");
             r.setFirstChild(t);
             ASTFrame frame = new ASTFrame("Pascal AST", r);
             frame.setVisible(true);*/
             //System.out.println(t.toStringList());
          }

        }
      static boolean showTree = true;
      public static String translateFilePath;
      public static String translateFileName;
      public static String currentFileName; // not static, recursive USES ... other FileName in currentFileName
      public static String oldtranslateFileName;


    // main
      public static void main(String[] args) {
        // Use a try/catch block for parser exceptions
        try {
          // if we have at least one command-line argument
          if (args.length > 0 ) {

            // for each directory/file specified on the command line
            for(int i=0; i< args.length;i++)
    {
    	  if ( args[i].equals("-showtree") ) {
                 showTree = true;
              }
              else {
                System.err.println("Parsing...");
                doFile(new File(args[i])); // parse it
              }
            }
          }
          else
            System.err.println("Usage: java PascalParser <file/directory name>");

        }
        catch(Exception e) {
          System.err.println("exception: "+e);
          e.printStackTrace(System.err);   // so we can get stack trace
        }
      }



    public static class program_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "program"
    // D:\\m\\antlr\\pascal\\pascal.g:270:1: program : programHeading ( INTERFACE )? block DOT ;
    public final pascalParser.program_return program() throws RecognitionException {
        pascalParser.program_return retval = new pascalParser.program_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token INTERFACE2=null;
        Token DOT4=null;
        pascalParser.programHeading_return programHeading1 = null;

        pascalParser.block_return block3 = null;


        PascalAST INTERFACE2_tree=null;
        PascalAST DOT4_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:271:5: ( programHeading ( INTERFACE )? block DOT )
            // D:\\m\\antlr\\pascal\\pascal.g:271:7: programHeading ( INTERFACE )? block DOT
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_programHeading_in_program521);
            programHeading1=programHeading();

            state._fsp--;

            adaptor.addChild(root_0, programHeading1.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:271:22: ( INTERFACE )?
            int alt1=2;
            alt1 = dfa1.predict(input);
            switch (alt1) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:271:23: INTERFACE
                    {
                    INTERFACE2=(Token)match(input,INTERFACE,FOLLOW_INTERFACE_in_program524); 

                    }
                    break;

            }

            pushFollow(FOLLOW_block_in_program535);
            block3=block();

            state._fsp--;

            adaptor.addChild(root_0, block3.getTree());
            DOT4=(Token)match(input,DOT,FOLLOW_DOT_in_program543); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "program"

    public static class programHeading_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "programHeading"
    // D:\\m\\antlr\\pascal\\pascal.g:276:1: programHeading : ( PROGRAM identifier ( LPAREN identifierList RPAREN )? SEMI | UNIT identifier SEMI );
    public final pascalParser.programHeading_return programHeading() throws RecognitionException {
        pascalParser.programHeading_return retval = new pascalParser.programHeading_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token PROGRAM5=null;
        Token LPAREN7=null;
        Token RPAREN9=null;
        Token SEMI10=null;
        Token UNIT11=null;
        Token SEMI13=null;
        pascalParser.identifier_return identifier6 = null;

        pascalParser.identifierList_return identifierList8 = null;

        pascalParser.identifier_return identifier12 = null;


        PascalAST PROGRAM5_tree=null;
        PascalAST LPAREN7_tree=null;
        PascalAST RPAREN9_tree=null;
        PascalAST SEMI10_tree=null;
        PascalAST UNIT11_tree=null;
        PascalAST SEMI13_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:277:5: ( PROGRAM identifier ( LPAREN identifierList RPAREN )? SEMI | UNIT identifier SEMI )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==PROGRAM) ) {
                alt3=1;
            }
            else if ( (LA3_0==UNIT) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:277:7: PROGRAM identifier ( LPAREN identifierList RPAREN )? SEMI
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    PROGRAM5=(Token)match(input,PROGRAM,FOLLOW_PROGRAM_in_programHeading561); 
                    PROGRAM5_tree = (PascalAST)adaptor.create(PROGRAM5);
                    root_0 = (PascalAST)adaptor.becomeRoot(PROGRAM5_tree, root_0);

                    pushFollow(FOLLOW_identifier_in_programHeading564);
                    identifier6=identifier();

                    state._fsp--;

                    adaptor.addChild(root_0, identifier6.getTree());
                    // D:\\m\\antlr\\pascal\\pascal.g:277:27: ( LPAREN identifierList RPAREN )?
                    int alt2=2;
                    int LA2_0 = input.LA(1);

                    if ( (LA2_0==LPAREN) ) {
                        alt2=1;
                    }
                    switch (alt2) {
                        case 1 :
                            // D:\\m\\antlr\\pascal\\pascal.g:277:28: LPAREN identifierList RPAREN
                            {
                            LPAREN7=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_programHeading567); 
                            pushFollow(FOLLOW_identifierList_in_programHeading570);
                            identifierList8=identifierList();

                            state._fsp--;

                            adaptor.addChild(root_0, identifierList8.getTree());
                            RPAREN9=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_programHeading572); 

                            }
                            break;

                    }

                    SEMI10=(Token)match(input,SEMI,FOLLOW_SEMI_in_programHeading577); 

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:278:7: UNIT identifier SEMI
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    UNIT11=(Token)match(input,UNIT,FOLLOW_UNIT_in_programHeading586); 
                    UNIT11_tree = (PascalAST)adaptor.create(UNIT11);
                    root_0 = (PascalAST)adaptor.becomeRoot(UNIT11_tree, root_0);

                    pushFollow(FOLLOW_identifier_in_programHeading589);
                    identifier12=identifier();

                    state._fsp--;

                    adaptor.addChild(root_0, identifier12.getTree());
                    SEMI13=(Token)match(input,SEMI,FOLLOW_SEMI_in_programHeading591); 

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "programHeading"

    public static class identifier_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "identifier"
    // D:\\m\\antlr\\pascal\\pascal.g:281:1: identifier : IDENT ;
    public final pascalParser.identifier_return identifier() throws RecognitionException {
        pascalParser.identifier_return retval = new pascalParser.identifier_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token IDENT14=null;

        PascalAST IDENT14_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:282:5: ( IDENT )
            // D:\\m\\antlr\\pascal\\pascal.g:282:7: IDENT
            {
            root_0 = (PascalAST)adaptor.nil();

            IDENT14=(Token)match(input,IDENT,FOLLOW_IDENT_in_identifier606); 
            IDENT14_tree = (PascalAST)adaptor.create(IDENT14);
            adaptor.addChild(root_0, IDENT14_tree);


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "identifier"

    public static class block_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "block"
    // D:\\m\\antlr\\pascal\\pascal.g:285:1: block : ( labelDeclarationPart | constantDefinitionPart | typeDefinitionPart | variableDeclarationPart | procedureAndFunctionDeclarationPart | usesUnitsPart | IMPLEMENTATION )* compoundStatement ;
    public final pascalParser.block_return block() throws RecognitionException {
        pascalParser.block_return retval = new pascalParser.block_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token IMPLEMENTATION21=null;
        pascalParser.labelDeclarationPart_return labelDeclarationPart15 = null;

        pascalParser.constantDefinitionPart_return constantDefinitionPart16 = null;

        pascalParser.typeDefinitionPart_return typeDefinitionPart17 = null;

        pascalParser.variableDeclarationPart_return variableDeclarationPart18 = null;

        pascalParser.procedureAndFunctionDeclarationPart_return procedureAndFunctionDeclarationPart19 = null;

        pascalParser.usesUnitsPart_return usesUnitsPart20 = null;

        pascalParser.compoundStatement_return compoundStatement22 = null;


        PascalAST IMPLEMENTATION21_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:286:5: ( ( labelDeclarationPart | constantDefinitionPart | typeDefinitionPart | variableDeclarationPart | procedureAndFunctionDeclarationPart | usesUnitsPart | IMPLEMENTATION )* compoundStatement )
            // D:\\m\\antlr\\pascal\\pascal.g:286:7: ( labelDeclarationPart | constantDefinitionPart | typeDefinitionPart | variableDeclarationPart | procedureAndFunctionDeclarationPart | usesUnitsPart | IMPLEMENTATION )* compoundStatement
            {
            root_0 = (PascalAST)adaptor.nil();

            // D:\\m\\antlr\\pascal\\pascal.g:286:7: ( labelDeclarationPart | constantDefinitionPart | typeDefinitionPart | variableDeclarationPart | procedureAndFunctionDeclarationPart | usesUnitsPart | IMPLEMENTATION )*
            loop4:
            do {
                int alt4=8;
                alt4 = dfa4.predict(input);
                switch (alt4) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:286:9: labelDeclarationPart
            	    {
            	    pushFollow(FOLLOW_labelDeclarationPart_in_block625);
            	    labelDeclarationPart15=labelDeclarationPart();

            	    state._fsp--;

            	    adaptor.addChild(root_0, labelDeclarationPart15.getTree());

            	    }
            	    break;
            	case 2 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:287:9: constantDefinitionPart
            	    {
            	    pushFollow(FOLLOW_constantDefinitionPart_in_block635);
            	    constantDefinitionPart16=constantDefinitionPart();

            	    state._fsp--;

            	    adaptor.addChild(root_0, constantDefinitionPart16.getTree());

            	    }
            	    break;
            	case 3 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:288:9: typeDefinitionPart
            	    {
            	    pushFollow(FOLLOW_typeDefinitionPart_in_block645);
            	    typeDefinitionPart17=typeDefinitionPart();

            	    state._fsp--;

            	    adaptor.addChild(root_0, typeDefinitionPart17.getTree());

            	    }
            	    break;
            	case 4 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:289:9: variableDeclarationPart
            	    {
            	    pushFollow(FOLLOW_variableDeclarationPart_in_block655);
            	    variableDeclarationPart18=variableDeclarationPart();

            	    state._fsp--;

            	    adaptor.addChild(root_0, variableDeclarationPart18.getTree());

            	    }
            	    break;
            	case 5 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:290:9: procedureAndFunctionDeclarationPart
            	    {
            	    pushFollow(FOLLOW_procedureAndFunctionDeclarationPart_in_block665);
            	    procedureAndFunctionDeclarationPart19=procedureAndFunctionDeclarationPart();

            	    state._fsp--;

            	    adaptor.addChild(root_0, procedureAndFunctionDeclarationPart19.getTree());

            	    }
            	    break;
            	case 6 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:291:9: usesUnitsPart
            	    {
            	    pushFollow(FOLLOW_usesUnitsPart_in_block675);
            	    usesUnitsPart20=usesUnitsPart();

            	    state._fsp--;

            	    adaptor.addChild(root_0, usesUnitsPart20.getTree());

            	    }
            	    break;
            	case 7 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:292:9: IMPLEMENTATION
            	    {
            	    IMPLEMENTATION21=(Token)match(input,IMPLEMENTATION,FOLLOW_IMPLEMENTATION_in_block685); 
            	    IMPLEMENTATION21_tree = (PascalAST)adaptor.create(IMPLEMENTATION21);
            	    adaptor.addChild(root_0, IMPLEMENTATION21_tree);


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            pushFollow(FOLLOW_compoundStatement_in_block702);
            compoundStatement22=compoundStatement();

            state._fsp--;

            adaptor.addChild(root_0, compoundStatement22.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "block"

    public static class usesUnitsPart_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "usesUnitsPart"
    // D:\\m\\antlr\\pascal\\pascal.g:297:1: usesUnitsPart : USES identifierList SEMI ;
    public final pascalParser.usesUnitsPart_return usesUnitsPart() throws RecognitionException {
        pascalParser.usesUnitsPart_return retval = new pascalParser.usesUnitsPart_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token USES23=null;
        Token SEMI25=null;
        pascalParser.identifierList_return identifierList24 = null;


        PascalAST USES23_tree=null;
        PascalAST SEMI25_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:298:5: ( USES identifierList SEMI )
            // D:\\m\\antlr\\pascal\\pascal.g:298:7: USES identifierList SEMI
            {
            root_0 = (PascalAST)adaptor.nil();

            USES23=(Token)match(input,USES,FOLLOW_USES_in_usesUnitsPart719); 
            USES23_tree = (PascalAST)adaptor.create(USES23);
            root_0 = (PascalAST)adaptor.becomeRoot(USES23_tree, root_0);

            pushFollow(FOLLOW_identifierList_in_usesUnitsPart722);
            identifierList24=identifierList();

            state._fsp--;

            adaptor.addChild(root_0, identifierList24.getTree());
            SEMI25=(Token)match(input,SEMI,FOLLOW_SEMI_in_usesUnitsPart724); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "usesUnitsPart"

    public static class labelDeclarationPart_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "labelDeclarationPart"
    // D:\\m\\antlr\\pascal\\pascal.g:301:1: labelDeclarationPart : LABEL label ( COMMA label )* SEMI ;
    public final pascalParser.labelDeclarationPart_return labelDeclarationPart() throws RecognitionException {
        pascalParser.labelDeclarationPart_return retval = new pascalParser.labelDeclarationPart_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token LABEL26=null;
        Token COMMA28=null;
        Token SEMI30=null;
        pascalParser.label_return label27 = null;

        pascalParser.label_return label29 = null;


        PascalAST LABEL26_tree=null;
        PascalAST COMMA28_tree=null;
        PascalAST SEMI30_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:302:5: ( LABEL label ( COMMA label )* SEMI )
            // D:\\m\\antlr\\pascal\\pascal.g:302:7: LABEL label ( COMMA label )* SEMI
            {
            root_0 = (PascalAST)adaptor.nil();

            LABEL26=(Token)match(input,LABEL,FOLLOW_LABEL_in_labelDeclarationPart742); 
            LABEL26_tree = (PascalAST)adaptor.create(LABEL26);
            root_0 = (PascalAST)adaptor.becomeRoot(LABEL26_tree, root_0);

            pushFollow(FOLLOW_label_in_labelDeclarationPart745);
            label27=label();

            state._fsp--;

            adaptor.addChild(root_0, label27.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:302:20: ( COMMA label )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==COMMA) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:302:22: COMMA label
            	    {
            	    COMMA28=(Token)match(input,COMMA,FOLLOW_COMMA_in_labelDeclarationPart749); 
            	    pushFollow(FOLLOW_label_in_labelDeclarationPart752);
            	    label29=label();

            	    state._fsp--;

            	    adaptor.addChild(root_0, label29.getTree());

            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            SEMI30=(Token)match(input,SEMI,FOLLOW_SEMI_in_labelDeclarationPart757); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "labelDeclarationPart"

    public static class label_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "label"
    // D:\\m\\antlr\\pascal\\pascal.g:305:1: label : unsignedInteger ;
    public final pascalParser.label_return label() throws RecognitionException {
        pascalParser.label_return retval = new pascalParser.label_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.unsignedInteger_return unsignedInteger31 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:306:5: ( unsignedInteger )
            // D:\\m\\antlr\\pascal\\pascal.g:306:7: unsignedInteger
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_unsignedInteger_in_label775);
            unsignedInteger31=unsignedInteger();

            state._fsp--;

            adaptor.addChild(root_0, unsignedInteger31.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "label"

    public static class constantDefinitionPart_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "constantDefinitionPart"
    // D:\\m\\antlr\\pascal\\pascal.g:309:1: constantDefinitionPart : CONST constantDefinition ( SEMI constantDefinition )* SEMI ;
    public final pascalParser.constantDefinitionPart_return constantDefinitionPart() throws RecognitionException {
        pascalParser.constantDefinitionPart_return retval = new pascalParser.constantDefinitionPart_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token CONST32=null;
        Token SEMI34=null;
        Token SEMI36=null;
        pascalParser.constantDefinition_return constantDefinition33 = null;

        pascalParser.constantDefinition_return constantDefinition35 = null;


        PascalAST CONST32_tree=null;
        PascalAST SEMI34_tree=null;
        PascalAST SEMI36_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:310:5: ( CONST constantDefinition ( SEMI constantDefinition )* SEMI )
            // D:\\m\\antlr\\pascal\\pascal.g:310:7: CONST constantDefinition ( SEMI constantDefinition )* SEMI
            {
            root_0 = (PascalAST)adaptor.nil();

            CONST32=(Token)match(input,CONST,FOLLOW_CONST_in_constantDefinitionPart792); 
            CONST32_tree = (PascalAST)adaptor.create(CONST32);
            root_0 = (PascalAST)adaptor.becomeRoot(CONST32_tree, root_0);

            pushFollow(FOLLOW_constantDefinition_in_constantDefinitionPart795);
            constantDefinition33=constantDefinition();

            state._fsp--;

            adaptor.addChild(root_0, constantDefinition33.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:310:33: ( SEMI constantDefinition )*
            loop6:
            do {
                int alt6=2;
                alt6 = dfa6.predict(input);
                switch (alt6) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:310:35: SEMI constantDefinition
            	    {
            	    SEMI34=(Token)match(input,SEMI,FOLLOW_SEMI_in_constantDefinitionPart799); 
            	    pushFollow(FOLLOW_constantDefinition_in_constantDefinitionPart802);
            	    constantDefinition35=constantDefinition();

            	    state._fsp--;

            	    adaptor.addChild(root_0, constantDefinition35.getTree());

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            SEMI36=(Token)match(input,SEMI,FOLLOW_SEMI_in_constantDefinitionPart807); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "constantDefinitionPart"

    public static class constantDefinition_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "constantDefinition"
    // D:\\m\\antlr\\pascal\\pascal.g:313:1: constantDefinition : identifier EQUAL constant ;
    public final pascalParser.constantDefinition_return constantDefinition() throws RecognitionException {
        pascalParser.constantDefinition_return retval = new pascalParser.constantDefinition_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token EQUAL38=null;
        pascalParser.identifier_return identifier37 = null;

        pascalParser.constant_return constant39 = null;


        PascalAST EQUAL38_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:314:5: ( identifier EQUAL constant )
            // D:\\m\\antlr\\pascal\\pascal.g:314:7: identifier EQUAL constant
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_identifier_in_constantDefinition825);
            identifier37=identifier();

            state._fsp--;

            adaptor.addChild(root_0, identifier37.getTree());
            EQUAL38=(Token)match(input,EQUAL,FOLLOW_EQUAL_in_constantDefinition827); 
            EQUAL38_tree = (PascalAST)adaptor.create(EQUAL38);
            root_0 = (PascalAST)adaptor.becomeRoot(EQUAL38_tree, root_0);

            pushFollow(FOLLOW_constant_in_constantDefinition830);
            constant39=constant();

            state._fsp--;

            adaptor.addChild(root_0, constant39.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "constantDefinition"

    public static class constantChr_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "constantChr"
    // D:\\m\\antlr\\pascal\\pascal.g:317:1: constantChr : CHR LPAREN unsignedInteger RPAREN ;
    public final pascalParser.constantChr_return constantChr() throws RecognitionException {
        pascalParser.constantChr_return retval = new pascalParser.constantChr_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token CHR40=null;
        Token LPAREN41=null;
        Token RPAREN43=null;
        pascalParser.unsignedInteger_return unsignedInteger42 = null;


        PascalAST CHR40_tree=null;
        PascalAST LPAREN41_tree=null;
        PascalAST RPAREN43_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:318:5: ( CHR LPAREN unsignedInteger RPAREN )
            // D:\\m\\antlr\\pascal\\pascal.g:318:7: CHR LPAREN unsignedInteger RPAREN
            {
            root_0 = (PascalAST)adaptor.nil();

            CHR40=(Token)match(input,CHR,FOLLOW_CHR_in_constantChr847); 
            CHR40_tree = (PascalAST)adaptor.create(CHR40);
            root_0 = (PascalAST)adaptor.becomeRoot(CHR40_tree, root_0);

            LPAREN41=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_constantChr850); 
            pushFollow(FOLLOW_unsignedInteger_in_constantChr853);
            unsignedInteger42=unsignedInteger();

            state._fsp--;

            adaptor.addChild(root_0, unsignedInteger42.getTree());
            RPAREN43=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_constantChr855); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "constantChr"

    public static class constant_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "constant"
    // D:\\m\\antlr\\pascal\\pascal.g:321:1: constant : ( unsignedNumber | s= sign n= unsignedNumber -> ^( $s $n) | identifier | s2= sign id= identifier -> ^( $s2 $id) | string | constantChr );
    public final pascalParser.constant_return constant() throws RecognitionException {
        pascalParser.constant_return retval = new pascalParser.constant_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.sign_return s = null;

        pascalParser.unsignedNumber_return n = null;

        pascalParser.sign_return s2 = null;

        pascalParser.identifier_return id = null;

        pascalParser.unsignedNumber_return unsignedNumber44 = null;

        pascalParser.identifier_return identifier45 = null;

        pascalParser.string_return string46 = null;

        pascalParser.constantChr_return constantChr47 = null;


        RewriteRuleSubtreeStream stream_sign=new RewriteRuleSubtreeStream(adaptor,"rule sign");
        RewriteRuleSubtreeStream stream_unsignedNumber=new RewriteRuleSubtreeStream(adaptor,"rule unsignedNumber");
        RewriteRuleSubtreeStream stream_identifier=new RewriteRuleSubtreeStream(adaptor,"rule identifier");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:322:5: ( unsignedNumber | s= sign n= unsignedNumber -> ^( $s $n) | identifier | s2= sign id= identifier -> ^( $s2 $id) | string | constantChr )
            int alt7=6;
            alt7 = dfa7.predict(input);
            switch (alt7) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:322:7: unsignedNumber
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_unsignedNumber_in_constant873);
                    unsignedNumber44=unsignedNumber();

                    state._fsp--;

                    adaptor.addChild(root_0, unsignedNumber44.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:323:7: s= sign n= unsignedNumber
                    {
                    pushFollow(FOLLOW_sign_in_constant883);
                    s=sign();

                    state._fsp--;

                    stream_sign.add(s.getTree());
                    pushFollow(FOLLOW_unsignedNumber_in_constant887);
                    n=unsignedNumber();

                    state._fsp--;

                    stream_unsignedNumber.add(n.getTree());


                    // AST REWRITE
                    // elements: n, s
                    // token labels: 
                    // rule labels: retval, s, n
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_s=new RewriteRuleSubtreeStream(adaptor,"rule s",s!=null?s.tree:null);
                    RewriteRuleSubtreeStream stream_n=new RewriteRuleSubtreeStream(adaptor,"rule n",n!=null?n.tree:null);

                    root_0 = (PascalAST)adaptor.nil();
                    // 323:31: -> ^( $s $n)
                    {
                        // D:\\m\\antlr\\pascal\\pascal.g:323:34: ^( $s $n)
                        {
                        PascalAST root_1 = (PascalAST)adaptor.nil();
                        root_1 = (PascalAST)adaptor.becomeRoot(stream_s.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_n.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 3 :
                    // D:\\m\\antlr\\pascal\\pascal.g:324:7: identifier
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_identifier_in_constant906);
                    identifier45=identifier();

                    state._fsp--;

                    adaptor.addChild(root_0, identifier45.getTree());

                    }
                    break;
                case 4 :
                    // D:\\m\\antlr\\pascal\\pascal.g:325:7: s2= sign id= identifier
                    {
                    pushFollow(FOLLOW_sign_in_constant916);
                    s2=sign();

                    state._fsp--;

                    stream_sign.add(s2.getTree());
                    pushFollow(FOLLOW_identifier_in_constant920);
                    id=identifier();

                    state._fsp--;

                    stream_identifier.add(id.getTree());


                    // AST REWRITE
                    // elements: id, s2
                    // token labels: 
                    // rule labels: id, retval, s2
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id",id!=null?id.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_s2=new RewriteRuleSubtreeStream(adaptor,"rule s2",s2!=null?s2.tree:null);

                    root_0 = (PascalAST)adaptor.nil();
                    // 325:29: -> ^( $s2 $id)
                    {
                        // D:\\m\\antlr\\pascal\\pascal.g:325:32: ^( $s2 $id)
                        {
                        PascalAST root_1 = (PascalAST)adaptor.nil();
                        root_1 = (PascalAST)adaptor.becomeRoot(stream_s2.nextNode(), root_1);

                        adaptor.addChild(root_1, stream_id.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 5 :
                    // D:\\m\\antlr\\pascal\\pascal.g:327:7: string
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_string_in_constant944);
                    string46=string();

                    state._fsp--;

                    adaptor.addChild(root_0, string46.getTree());

                    }
                    break;
                case 6 :
                    // D:\\m\\antlr\\pascal\\pascal.g:328:7: constantChr
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_constantChr_in_constant952);
                    constantChr47=constantChr();

                    state._fsp--;

                    adaptor.addChild(root_0, constantChr47.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "constant"

    public static class unsignedNumber_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unsignedNumber"
    // D:\\m\\antlr\\pascal\\pascal.g:331:1: unsignedNumber : ( unsignedInteger | unsignedReal );
    public final pascalParser.unsignedNumber_return unsignedNumber() throws RecognitionException {
        pascalParser.unsignedNumber_return retval = new pascalParser.unsignedNumber_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.unsignedInteger_return unsignedInteger48 = null;

        pascalParser.unsignedReal_return unsignedReal49 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:332:5: ( unsignedInteger | unsignedReal )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==NUM_INT) ) {
                alt8=1;
            }
            else if ( (LA8_0==NUM_REAL) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:332:7: unsignedInteger
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_unsignedInteger_in_unsignedNumber969);
                    unsignedInteger48=unsignedInteger();

                    state._fsp--;

                    adaptor.addChild(root_0, unsignedInteger48.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:333:7: unsignedReal
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_unsignedReal_in_unsignedNumber977);
                    unsignedReal49=unsignedReal();

                    state._fsp--;

                    adaptor.addChild(root_0, unsignedReal49.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unsignedNumber"

    public static class unsignedInteger_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unsignedInteger"
    // D:\\m\\antlr\\pascal\\pascal.g:336:1: unsignedInteger : NUM_INT ;
    public final pascalParser.unsignedInteger_return unsignedInteger() throws RecognitionException {
        pascalParser.unsignedInteger_return retval = new pascalParser.unsignedInteger_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token NUM_INT50=null;

        PascalAST NUM_INT50_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:337:5: ( NUM_INT )
            // D:\\m\\antlr\\pascal\\pascal.g:337:7: NUM_INT
            {
            root_0 = (PascalAST)adaptor.nil();

            NUM_INT50=(Token)match(input,NUM_INT,FOLLOW_NUM_INT_in_unsignedInteger994); 
            NUM_INT50_tree = (PascalAST)adaptor.create(NUM_INT50);
            adaptor.addChild(root_0, NUM_INT50_tree);


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unsignedInteger"

    public static class unsignedReal_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unsignedReal"
    // D:\\m\\antlr\\pascal\\pascal.g:340:1: unsignedReal : NUM_REAL ;
    public final pascalParser.unsignedReal_return unsignedReal() throws RecognitionException {
        pascalParser.unsignedReal_return retval = new pascalParser.unsignedReal_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token NUM_REAL51=null;

        PascalAST NUM_REAL51_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:341:5: ( NUM_REAL )
            // D:\\m\\antlr\\pascal\\pascal.g:341:7: NUM_REAL
            {
            root_0 = (PascalAST)adaptor.nil();

            NUM_REAL51=(Token)match(input,NUM_REAL,FOLLOW_NUM_REAL_in_unsignedReal1011); 
            NUM_REAL51_tree = (PascalAST)adaptor.create(NUM_REAL51);
            adaptor.addChild(root_0, NUM_REAL51_tree);


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unsignedReal"

    public static class sign_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "sign"
    // D:\\m\\antlr\\pascal\\pascal.g:344:1: sign : ( PLUS | MINUS );
    public final pascalParser.sign_return sign() throws RecognitionException {
        pascalParser.sign_return retval = new pascalParser.sign_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token set52=null;

        PascalAST set52_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:345:5: ( PLUS | MINUS )
            // D:\\m\\antlr\\pascal\\pascal.g:
            {
            root_0 = (PascalAST)adaptor.nil();

            set52=(Token)input.LT(1);
            if ( (input.LA(1)>=PLUS && input.LA(1)<=MINUS) ) {
                input.consume();
                adaptor.addChild(root_0, (PascalAST)adaptor.create(set52));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "sign"

    public static class string_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "string"
    // D:\\m\\antlr\\pascal\\pascal.g:348:1: string : STRING_LITERAL ;
    public final pascalParser.string_return string() throws RecognitionException {
        pascalParser.string_return retval = new pascalParser.string_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token STRING_LITERAL53=null;

        PascalAST STRING_LITERAL53_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:349:5: ( STRING_LITERAL )
            // D:\\m\\antlr\\pascal\\pascal.g:349:7: STRING_LITERAL
            {
            root_0 = (PascalAST)adaptor.nil();

            STRING_LITERAL53=(Token)match(input,STRING_LITERAL,FOLLOW_STRING_LITERAL_in_string1049); 
            STRING_LITERAL53_tree = (PascalAST)adaptor.create(STRING_LITERAL53);
            adaptor.addChild(root_0, STRING_LITERAL53_tree);


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "string"

    public static class typeDefinitionPart_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeDefinitionPart"
    // D:\\m\\antlr\\pascal\\pascal.g:352:1: typeDefinitionPart : TYPE typeDefinition ( SEMI typeDefinition )* SEMI ;
    public final pascalParser.typeDefinitionPart_return typeDefinitionPart() throws RecognitionException {
        pascalParser.typeDefinitionPart_return retval = new pascalParser.typeDefinitionPart_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token TYPE54=null;
        Token SEMI56=null;
        Token SEMI58=null;
        pascalParser.typeDefinition_return typeDefinition55 = null;

        pascalParser.typeDefinition_return typeDefinition57 = null;


        PascalAST TYPE54_tree=null;
        PascalAST SEMI56_tree=null;
        PascalAST SEMI58_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:353:5: ( TYPE typeDefinition ( SEMI typeDefinition )* SEMI )
            // D:\\m\\antlr\\pascal\\pascal.g:353:7: TYPE typeDefinition ( SEMI typeDefinition )* SEMI
            {
            root_0 = (PascalAST)adaptor.nil();

            TYPE54=(Token)match(input,TYPE,FOLLOW_TYPE_in_typeDefinitionPart1066); 
            TYPE54_tree = (PascalAST)adaptor.create(TYPE54);
            root_0 = (PascalAST)adaptor.becomeRoot(TYPE54_tree, root_0);

            pushFollow(FOLLOW_typeDefinition_in_typeDefinitionPart1069);
            typeDefinition55=typeDefinition();

            state._fsp--;

            adaptor.addChild(root_0, typeDefinition55.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:353:28: ( SEMI typeDefinition )*
            loop9:
            do {
                int alt9=2;
                alt9 = dfa9.predict(input);
                switch (alt9) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:353:30: SEMI typeDefinition
            	    {
            	    SEMI56=(Token)match(input,SEMI,FOLLOW_SEMI_in_typeDefinitionPart1073); 
            	    pushFollow(FOLLOW_typeDefinition_in_typeDefinitionPart1076);
            	    typeDefinition57=typeDefinition();

            	    state._fsp--;

            	    adaptor.addChild(root_0, typeDefinition57.getTree());

            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

            SEMI58=(Token)match(input,SEMI,FOLLOW_SEMI_in_typeDefinitionPart1081); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeDefinitionPart"

    public static class typeDefinition_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeDefinition"
    // D:\\m\\antlr\\pascal\\pascal.g:357:1: typeDefinition : identifier e= EQUAL ( type | functionType | procedureType ) ;
    public final pascalParser.typeDefinition_return typeDefinition() throws RecognitionException {
        pascalParser.typeDefinition_return retval = new pascalParser.typeDefinition_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token e=null;
        pascalParser.identifier_return identifier59 = null;

        pascalParser.type_return type60 = null;

        pascalParser.functionType_return functionType61 = null;

        pascalParser.procedureType_return procedureType62 = null;


        PascalAST e_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:358:5: ( identifier e= EQUAL ( type | functionType | procedureType ) )
            // D:\\m\\antlr\\pascal\\pascal.g:358:7: identifier e= EQUAL ( type | functionType | procedureType )
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_identifier_in_typeDefinition1100);
            identifier59=identifier();

            state._fsp--;

            adaptor.addChild(root_0, identifier59.getTree());
            e=(Token)match(input,EQUAL,FOLLOW_EQUAL_in_typeDefinition1104); 
            e_tree = (PascalAST)adaptor.create(e);
            root_0 = (PascalAST)adaptor.becomeRoot(e_tree, root_0);

            e.setType(TYPEDECL);
            // D:\\m\\antlr\\pascal\\pascal.g:359:7: ( type | functionType | procedureType )
            int alt10=3;
            alt10 = dfa10.predict(input);
            switch (alt10) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:359:9: type
                    {
                    pushFollow(FOLLOW_type_in_typeDefinition1117);
                    type60=type();

                    state._fsp--;

                    adaptor.addChild(root_0, type60.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:360:9: functionType
                    {
                    pushFollow(FOLLOW_functionType_in_typeDefinition1127);
                    functionType61=functionType();

                    state._fsp--;

                    adaptor.addChild(root_0, functionType61.getTree());

                    }
                    break;
                case 3 :
                    // D:\\m\\antlr\\pascal\\pascal.g:362:9: procedureType
                    {
                    pushFollow(FOLLOW_procedureType_in_typeDefinition1139);
                    procedureType62=procedureType();

                    state._fsp--;

                    adaptor.addChild(root_0, procedureType62.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeDefinition"

    public static class functionType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "functionType"
    // D:\\m\\antlr\\pascal\\pascal.g:367:1: functionType : FUNCTION ( formalParameterList )? COLON resultType ;
    public final pascalParser.functionType_return functionType() throws RecognitionException {
        pascalParser.functionType_return retval = new pascalParser.functionType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token FUNCTION63=null;
        Token COLON65=null;
        pascalParser.formalParameterList_return formalParameterList64 = null;

        pascalParser.resultType_return resultType66 = null;


        PascalAST FUNCTION63_tree=null;
        PascalAST COLON65_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:368:5: ( FUNCTION ( formalParameterList )? COLON resultType )
            // D:\\m\\antlr\\pascal\\pascal.g:368:7: FUNCTION ( formalParameterList )? COLON resultType
            {
            root_0 = (PascalAST)adaptor.nil();

            FUNCTION63=(Token)match(input,FUNCTION,FOLLOW_FUNCTION_in_functionType1165); 
            FUNCTION63_tree = (PascalAST)adaptor.create(FUNCTION63);
            root_0 = (PascalAST)adaptor.becomeRoot(FUNCTION63_tree, root_0);

            // D:\\m\\antlr\\pascal\\pascal.g:368:17: ( formalParameterList )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==LPAREN) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:368:18: formalParameterList
                    {
                    pushFollow(FOLLOW_formalParameterList_in_functionType1169);
                    formalParameterList64=formalParameterList();

                    state._fsp--;

                    adaptor.addChild(root_0, formalParameterList64.getTree());

                    }
                    break;

            }

            COLON65=(Token)match(input,COLON,FOLLOW_COLON_in_functionType1173); 
            pushFollow(FOLLOW_resultType_in_functionType1176);
            resultType66=resultType();

            state._fsp--;

            adaptor.addChild(root_0, resultType66.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "functionType"

    public static class procedureType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "procedureType"
    // D:\\m\\antlr\\pascal\\pascal.g:371:1: procedureType : PROCEDURE ( formalParameterList )? ;
    public final pascalParser.procedureType_return procedureType() throws RecognitionException {
        pascalParser.procedureType_return retval = new pascalParser.procedureType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token PROCEDURE67=null;
        pascalParser.formalParameterList_return formalParameterList68 = null;


        PascalAST PROCEDURE67_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:372:5: ( PROCEDURE ( formalParameterList )? )
            // D:\\m\\antlr\\pascal\\pascal.g:372:7: PROCEDURE ( formalParameterList )?
            {
            root_0 = (PascalAST)adaptor.nil();

            PROCEDURE67=(Token)match(input,PROCEDURE,FOLLOW_PROCEDURE_in_procedureType1193); 
            PROCEDURE67_tree = (PascalAST)adaptor.create(PROCEDURE67);
            root_0 = (PascalAST)adaptor.becomeRoot(PROCEDURE67_tree, root_0);

            // D:\\m\\antlr\\pascal\\pascal.g:372:18: ( formalParameterList )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==LPAREN) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:372:19: formalParameterList
                    {
                    pushFollow(FOLLOW_formalParameterList_in_procedureType1197);
                    formalParameterList68=formalParameterList();

                    state._fsp--;

                    adaptor.addChild(root_0, formalParameterList68.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "procedureType"

    public static class type_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "type"
    // D:\\m\\antlr\\pascal\\pascal.g:375:1: type : ( simpleType | structuredType | pointerType );
    public final pascalParser.type_return type() throws RecognitionException {
        pascalParser.type_return retval = new pascalParser.type_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.simpleType_return simpleType69 = null;

        pascalParser.structuredType_return structuredType70 = null;

        pascalParser.pointerType_return pointerType71 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:376:5: ( simpleType | structuredType | pointerType )
            int alt13=3;
            alt13 = dfa13.predict(input);
            switch (alt13) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:376:7: simpleType
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_simpleType_in_type1216);
                    simpleType69=simpleType();

                    state._fsp--;

                    adaptor.addChild(root_0, simpleType69.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:377:7: structuredType
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_structuredType_in_type1224);
                    structuredType70=structuredType();

                    state._fsp--;

                    adaptor.addChild(root_0, structuredType70.getTree());

                    }
                    break;
                case 3 :
                    // D:\\m\\antlr\\pascal\\pascal.g:378:7: pointerType
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_pointerType_in_type1232);
                    pointerType71=pointerType();

                    state._fsp--;

                    adaptor.addChild(root_0, pointerType71.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "type"

    public static class simpleType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleType"
    // D:\\m\\antlr\\pascal\\pascal.g:381:1: simpleType : ( scalarType | subrangeType | typeIdentifier | stringtype );
    public final pascalParser.simpleType_return simpleType() throws RecognitionException {
        pascalParser.simpleType_return retval = new pascalParser.simpleType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.scalarType_return scalarType72 = null;

        pascalParser.subrangeType_return subrangeType73 = null;

        pascalParser.typeIdentifier_return typeIdentifier74 = null;

        pascalParser.stringtype_return stringtype75 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:382:5: ( scalarType | subrangeType | typeIdentifier | stringtype )
            int alt14=4;
            alt14 = dfa14.predict(input);
            switch (alt14) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:382:7: scalarType
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_scalarType_in_simpleType1249);
                    scalarType72=scalarType();

                    state._fsp--;

                    adaptor.addChild(root_0, scalarType72.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:383:7: subrangeType
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_subrangeType_in_simpleType1257);
                    subrangeType73=subrangeType();

                    state._fsp--;

                    adaptor.addChild(root_0, subrangeType73.getTree());

                    }
                    break;
                case 3 :
                    // D:\\m\\antlr\\pascal\\pascal.g:384:7: typeIdentifier
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_typeIdentifier_in_simpleType1265);
                    typeIdentifier74=typeIdentifier();

                    state._fsp--;

                    adaptor.addChild(root_0, typeIdentifier74.getTree());

                    }
                    break;
                case 4 :
                    // D:\\m\\antlr\\pascal\\pascal.g:385:7: stringtype
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_stringtype_in_simpleType1273);
                    stringtype75=stringtype();

                    state._fsp--;

                    adaptor.addChild(root_0, stringtype75.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleType"

    public static class scalarType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "scalarType"
    // D:\\m\\antlr\\pascal\\pascal.g:388:1: scalarType : LPAREN identifierList RPAREN -> ^( SCALARTYPE identifierList ) ;
    public final pascalParser.scalarType_return scalarType() throws RecognitionException {
        pascalParser.scalarType_return retval = new pascalParser.scalarType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token LPAREN76=null;
        Token RPAREN78=null;
        pascalParser.identifierList_return identifierList77 = null;


        PascalAST LPAREN76_tree=null;
        PascalAST RPAREN78_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_identifierList=new RewriteRuleSubtreeStream(adaptor,"rule identifierList");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:389:5: ( LPAREN identifierList RPAREN -> ^( SCALARTYPE identifierList ) )
            // D:\\m\\antlr\\pascal\\pascal.g:389:7: LPAREN identifierList RPAREN
            {
            LPAREN76=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_scalarType1290);  
            stream_LPAREN.add(LPAREN76);

            pushFollow(FOLLOW_identifierList_in_scalarType1292);
            identifierList77=identifierList();

            state._fsp--;

            stream_identifierList.add(identifierList77.getTree());
            RPAREN78=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_scalarType1294);  
            stream_RPAREN.add(RPAREN78);



            // AST REWRITE
            // elements: identifierList
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (PascalAST)adaptor.nil();
            // 389:37: -> ^( SCALARTYPE identifierList )
            {
                // D:\\m\\antlr\\pascal\\pascal.g:389:40: ^( SCALARTYPE identifierList )
                {
                PascalAST root_1 = (PascalAST)adaptor.nil();
                root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(SCALARTYPE, "SCALARTYPE"), root_1);

                adaptor.addChild(root_1, stream_identifierList.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "scalarType"

    public static class subrangeType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "subrangeType"
    // D:\\m\\antlr\\pascal\\pascal.g:393:1: subrangeType : constant DOTDOT constant ;
    public final pascalParser.subrangeType_return subrangeType() throws RecognitionException {
        pascalParser.subrangeType_return retval = new pascalParser.subrangeType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token DOTDOT80=null;
        pascalParser.constant_return constant79 = null;

        pascalParser.constant_return constant81 = null;


        PascalAST DOTDOT80_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:394:5: ( constant DOTDOT constant )
            // D:\\m\\antlr\\pascal\\pascal.g:394:7: constant DOTDOT constant
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_constant_in_subrangeType1325);
            constant79=constant();

            state._fsp--;

            adaptor.addChild(root_0, constant79.getTree());
            DOTDOT80=(Token)match(input,DOTDOT,FOLLOW_DOTDOT_in_subrangeType1327); 
            DOTDOT80_tree = (PascalAST)adaptor.create(DOTDOT80);
            root_0 = (PascalAST)adaptor.becomeRoot(DOTDOT80_tree, root_0);

            pushFollow(FOLLOW_constant_in_subrangeType1330);
            constant81=constant();

            state._fsp--;

            adaptor.addChild(root_0, constant81.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "subrangeType"

    public static class typeIdentifier_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeIdentifier"
    // D:\\m\\antlr\\pascal\\pascal.g:397:1: typeIdentifier : ( identifier | CHAR | BOOLEAN | INTEGER | REAL | STRING );
    public final pascalParser.typeIdentifier_return typeIdentifier() throws RecognitionException {
        pascalParser.typeIdentifier_return retval = new pascalParser.typeIdentifier_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token CHAR83=null;
        Token BOOLEAN84=null;
        Token INTEGER85=null;
        Token REAL86=null;
        Token STRING87=null;
        pascalParser.identifier_return identifier82 = null;


        PascalAST CHAR83_tree=null;
        PascalAST BOOLEAN84_tree=null;
        PascalAST INTEGER85_tree=null;
        PascalAST REAL86_tree=null;
        PascalAST STRING87_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:398:5: ( identifier | CHAR | BOOLEAN | INTEGER | REAL | STRING )
            int alt15=6;
            switch ( input.LA(1) ) {
            case IDENT:
                {
                alt15=1;
                }
                break;
            case CHAR:
                {
                alt15=2;
                }
                break;
            case BOOLEAN:
                {
                alt15=3;
                }
                break;
            case INTEGER:
                {
                alt15=4;
                }
                break;
            case REAL:
                {
                alt15=5;
                }
                break;
            case STRING:
                {
                alt15=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }

            switch (alt15) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:398:7: identifier
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_identifier_in_typeIdentifier1347);
                    identifier82=identifier();

                    state._fsp--;

                    adaptor.addChild(root_0, identifier82.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:399:7: CHAR
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    CHAR83=(Token)match(input,CHAR,FOLLOW_CHAR_in_typeIdentifier1355); 
                    CHAR83_tree = (PascalAST)adaptor.create(CHAR83);
                    adaptor.addChild(root_0, CHAR83_tree);


                    }
                    break;
                case 3 :
                    // D:\\m\\antlr\\pascal\\pascal.g:400:7: BOOLEAN
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    BOOLEAN84=(Token)match(input,BOOLEAN,FOLLOW_BOOLEAN_in_typeIdentifier1363); 
                    BOOLEAN84_tree = (PascalAST)adaptor.create(BOOLEAN84);
                    adaptor.addChild(root_0, BOOLEAN84_tree);


                    }
                    break;
                case 4 :
                    // D:\\m\\antlr\\pascal\\pascal.g:401:7: INTEGER
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    INTEGER85=(Token)match(input,INTEGER,FOLLOW_INTEGER_in_typeIdentifier1371); 
                    INTEGER85_tree = (PascalAST)adaptor.create(INTEGER85);
                    adaptor.addChild(root_0, INTEGER85_tree);


                    }
                    break;
                case 5 :
                    // D:\\m\\antlr\\pascal\\pascal.g:402:7: REAL
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    REAL86=(Token)match(input,REAL,FOLLOW_REAL_in_typeIdentifier1379); 
                    REAL86_tree = (PascalAST)adaptor.create(REAL86);
                    adaptor.addChild(root_0, REAL86_tree);


                    }
                    break;
                case 6 :
                    // D:\\m\\antlr\\pascal\\pascal.g:403:7: STRING
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    STRING87=(Token)match(input,STRING,FOLLOW_STRING_in_typeIdentifier1387); 
                    STRING87_tree = (PascalAST)adaptor.create(STRING87);
                    adaptor.addChild(root_0, STRING87_tree);


                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeIdentifier"

    public static class structuredType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "structuredType"
    // D:\\m\\antlr\\pascal\\pascal.g:406:1: structuredType : ( PACKED unpackedStructuredType | unpackedStructuredType );
    public final pascalParser.structuredType_return structuredType() throws RecognitionException {
        pascalParser.structuredType_return retval = new pascalParser.structuredType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token PACKED88=null;
        pascalParser.unpackedStructuredType_return unpackedStructuredType89 = null;

        pascalParser.unpackedStructuredType_return unpackedStructuredType90 = null;


        PascalAST PACKED88_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:407:5: ( PACKED unpackedStructuredType | unpackedStructuredType )
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==PACKED) ) {
                alt16=1;
            }
            else if ( (LA16_0==ARRAY||LA16_0==RECORD||(LA16_0>=SET && LA16_0<=FILE)) ) {
                alt16=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }
            switch (alt16) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:407:7: PACKED unpackedStructuredType
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    PACKED88=(Token)match(input,PACKED,FOLLOW_PACKED_in_structuredType1405); 
                    PACKED88_tree = (PascalAST)adaptor.create(PACKED88);
                    root_0 = (PascalAST)adaptor.becomeRoot(PACKED88_tree, root_0);

                    pushFollow(FOLLOW_unpackedStructuredType_in_structuredType1408);
                    unpackedStructuredType89=unpackedStructuredType();

                    state._fsp--;

                    adaptor.addChild(root_0, unpackedStructuredType89.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:408:5: unpackedStructuredType
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_unpackedStructuredType_in_structuredType1414);
                    unpackedStructuredType90=unpackedStructuredType();

                    state._fsp--;

                    adaptor.addChild(root_0, unpackedStructuredType90.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "structuredType"

    public static class unpackedStructuredType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unpackedStructuredType"
    // D:\\m\\antlr\\pascal\\pascal.g:411:1: unpackedStructuredType : ( arrayType | recordType | setType | fileType );
    public final pascalParser.unpackedStructuredType_return unpackedStructuredType() throws RecognitionException {
        pascalParser.unpackedStructuredType_return retval = new pascalParser.unpackedStructuredType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.arrayType_return arrayType91 = null;

        pascalParser.recordType_return recordType92 = null;

        pascalParser.setType_return setType93 = null;

        pascalParser.fileType_return fileType94 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:412:5: ( arrayType | recordType | setType | fileType )
            int alt17=4;
            switch ( input.LA(1) ) {
            case ARRAY:
                {
                alt17=1;
                }
                break;
            case RECORD:
                {
                alt17=2;
                }
                break;
            case SET:
                {
                alt17=3;
                }
                break;
            case FILE:
                {
                alt17=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:412:7: arrayType
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_arrayType_in_unpackedStructuredType1431);
                    arrayType91=arrayType();

                    state._fsp--;

                    adaptor.addChild(root_0, arrayType91.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:413:7: recordType
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_recordType_in_unpackedStructuredType1439);
                    recordType92=recordType();

                    state._fsp--;

                    adaptor.addChild(root_0, recordType92.getTree());

                    }
                    break;
                case 3 :
                    // D:\\m\\antlr\\pascal\\pascal.g:414:7: setType
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_setType_in_unpackedStructuredType1447);
                    setType93=setType();

                    state._fsp--;

                    adaptor.addChild(root_0, setType93.getTree());

                    }
                    break;
                case 4 :
                    // D:\\m\\antlr\\pascal\\pascal.g:415:7: fileType
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_fileType_in_unpackedStructuredType1455);
                    fileType94=fileType();

                    state._fsp--;

                    adaptor.addChild(root_0, fileType94.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unpackedStructuredType"

    public static class stringtype_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "stringtype"
    // D:\\m\\antlr\\pascal\\pascal.g:418:1: stringtype : STRING LBRACK ( identifier | unsignedNumber ) RBRACK ;
    public final pascalParser.stringtype_return stringtype() throws RecognitionException {
        pascalParser.stringtype_return retval = new pascalParser.stringtype_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token STRING95=null;
        Token LBRACK96=null;
        Token RBRACK99=null;
        pascalParser.identifier_return identifier97 = null;

        pascalParser.unsignedNumber_return unsignedNumber98 = null;


        PascalAST STRING95_tree=null;
        PascalAST LBRACK96_tree=null;
        PascalAST RBRACK99_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:419:5: ( STRING LBRACK ( identifier | unsignedNumber ) RBRACK )
            // D:\\m\\antlr\\pascal\\pascal.g:419:7: STRING LBRACK ( identifier | unsignedNumber ) RBRACK
            {
            root_0 = (PascalAST)adaptor.nil();

            STRING95=(Token)match(input,STRING,FOLLOW_STRING_in_stringtype1472); 
            STRING95_tree = (PascalAST)adaptor.create(STRING95);
            root_0 = (PascalAST)adaptor.becomeRoot(STRING95_tree, root_0);

            LBRACK96=(Token)match(input,LBRACK,FOLLOW_LBRACK_in_stringtype1475); 
            // D:\\m\\antlr\\pascal\\pascal.g:419:23: ( identifier | unsignedNumber )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==IDENT) ) {
                alt18=1;
            }
            else if ( (LA18_0==NUM_REAL||LA18_0==NUM_INT) ) {
                alt18=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:419:24: identifier
                    {
                    pushFollow(FOLLOW_identifier_in_stringtype1479);
                    identifier97=identifier();

                    state._fsp--;

                    adaptor.addChild(root_0, identifier97.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:419:35: unsignedNumber
                    {
                    pushFollow(FOLLOW_unsignedNumber_in_stringtype1481);
                    unsignedNumber98=unsignedNumber();

                    state._fsp--;

                    adaptor.addChild(root_0, unsignedNumber98.getTree());

                    }
                    break;

            }

            RBRACK99=(Token)match(input,RBRACK,FOLLOW_RBRACK_in_stringtype1484); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "stringtype"

    public static class arrayType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "arrayType"
    // D:\\m\\antlr\\pascal\\pascal.g:422:1: arrayType : ( ARRAY LBRACK typeList RBRACK OF componentType | ARRAY LBRACK2 typeList RBRACK2 OF componentType );
    public final pascalParser.arrayType_return arrayType() throws RecognitionException {
        pascalParser.arrayType_return retval = new pascalParser.arrayType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token ARRAY100=null;
        Token LBRACK101=null;
        Token RBRACK103=null;
        Token OF104=null;
        Token ARRAY106=null;
        Token LBRACK2107=null;
        Token RBRACK2109=null;
        Token OF110=null;
        pascalParser.typeList_return typeList102 = null;

        pascalParser.componentType_return componentType105 = null;

        pascalParser.typeList_return typeList108 = null;

        pascalParser.componentType_return componentType111 = null;


        PascalAST ARRAY100_tree=null;
        PascalAST LBRACK101_tree=null;
        PascalAST RBRACK103_tree=null;
        PascalAST OF104_tree=null;
        PascalAST ARRAY106_tree=null;
        PascalAST LBRACK2107_tree=null;
        PascalAST RBRACK2109_tree=null;
        PascalAST OF110_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:423:5: ( ARRAY LBRACK typeList RBRACK OF componentType | ARRAY LBRACK2 typeList RBRACK2 OF componentType )
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==ARRAY) ) {
                int LA19_1 = input.LA(2);

                if ( (LA19_1==LBRACK) ) {
                    alt19=1;
                }
                else if ( (LA19_1==LBRACK2) ) {
                    alt19=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 19, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }
            switch (alt19) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:423:7: ARRAY LBRACK typeList RBRACK OF componentType
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    ARRAY100=(Token)match(input,ARRAY,FOLLOW_ARRAY_in_arrayType1502); 
                    ARRAY100_tree = (PascalAST)adaptor.create(ARRAY100);
                    root_0 = (PascalAST)adaptor.becomeRoot(ARRAY100_tree, root_0);

                    LBRACK101=(Token)match(input,LBRACK,FOLLOW_LBRACK_in_arrayType1505); 
                    pushFollow(FOLLOW_typeList_in_arrayType1508);
                    typeList102=typeList();

                    state._fsp--;

                    adaptor.addChild(root_0, typeList102.getTree());
                    RBRACK103=(Token)match(input,RBRACK,FOLLOW_RBRACK_in_arrayType1510); 
                    OF104=(Token)match(input,OF,FOLLOW_OF_in_arrayType1513); 
                    pushFollow(FOLLOW_componentType_in_arrayType1516);
                    componentType105=componentType();

                    state._fsp--;

                    adaptor.addChild(root_0, componentType105.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:424:7: ARRAY LBRACK2 typeList RBRACK2 OF componentType
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    ARRAY106=(Token)match(input,ARRAY,FOLLOW_ARRAY_in_arrayType1524); 
                    ARRAY106_tree = (PascalAST)adaptor.create(ARRAY106);
                    root_0 = (PascalAST)adaptor.becomeRoot(ARRAY106_tree, root_0);

                    LBRACK2107=(Token)match(input,LBRACK2,FOLLOW_LBRACK2_in_arrayType1527); 
                    pushFollow(FOLLOW_typeList_in_arrayType1530);
                    typeList108=typeList();

                    state._fsp--;

                    adaptor.addChild(root_0, typeList108.getTree());
                    RBRACK2109=(Token)match(input,RBRACK2,FOLLOW_RBRACK2_in_arrayType1532); 
                    OF110=(Token)match(input,OF,FOLLOW_OF_in_arrayType1535); 
                    pushFollow(FOLLOW_componentType_in_arrayType1538);
                    componentType111=componentType();

                    state._fsp--;

                    adaptor.addChild(root_0, componentType111.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "arrayType"

    public static class typeList_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "typeList"
    // D:\\m\\antlr\\pascal\\pascal.g:427:1: typeList : indexType ( COMMA indexType )* -> ^( TYPELIST ( indexType )+ ) ;
    public final pascalParser.typeList_return typeList() throws RecognitionException {
        pascalParser.typeList_return retval = new pascalParser.typeList_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token COMMA113=null;
        pascalParser.indexType_return indexType112 = null;

        pascalParser.indexType_return indexType114 = null;


        PascalAST COMMA113_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_indexType=new RewriteRuleSubtreeStream(adaptor,"rule indexType");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:428:2: ( indexType ( COMMA indexType )* -> ^( TYPELIST ( indexType )+ ) )
            // D:\\m\\antlr\\pascal\\pascal.g:428:4: indexType ( COMMA indexType )*
            {
            pushFollow(FOLLOW_indexType_in_typeList1549);
            indexType112=indexType();

            state._fsp--;

            stream_indexType.add(indexType112.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:428:14: ( COMMA indexType )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==COMMA) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:428:16: COMMA indexType
            	    {
            	    COMMA113=(Token)match(input,COMMA,FOLLOW_COMMA_in_typeList1553);  
            	    stream_COMMA.add(COMMA113);

            	    pushFollow(FOLLOW_indexType_in_typeList1555);
            	    indexType114=indexType();

            	    state._fsp--;

            	    stream_indexType.add(indexType114.getTree());

            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);



            // AST REWRITE
            // elements: indexType
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (PascalAST)adaptor.nil();
            // 428:36: -> ^( TYPELIST ( indexType )+ )
            {
                // D:\\m\\antlr\\pascal\\pascal.g:428:39: ^( TYPELIST ( indexType )+ )
                {
                PascalAST root_1 = (PascalAST)adaptor.nil();
                root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(TYPELIST, "TYPELIST"), root_1);

                if ( !(stream_indexType.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_indexType.hasNext() ) {
                    adaptor.addChild(root_1, stream_indexType.nextTree());

                }
                stream_indexType.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "typeList"

    public static class indexType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "indexType"
    // D:\\m\\antlr\\pascal\\pascal.g:431:1: indexType : simpleType ;
    public final pascalParser.indexType_return indexType() throws RecognitionException {
        pascalParser.indexType_return retval = new pascalParser.indexType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.simpleType_return simpleType115 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:432:5: ( simpleType )
            // D:\\m\\antlr\\pascal\\pascal.g:432:7: simpleType
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_simpleType_in_indexType1582);
            simpleType115=simpleType();

            state._fsp--;

            adaptor.addChild(root_0, simpleType115.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "indexType"

    public static class componentType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "componentType"
    // D:\\m\\antlr\\pascal\\pascal.g:435:1: componentType : type ;
    public final pascalParser.componentType_return componentType() throws RecognitionException {
        pascalParser.componentType_return retval = new pascalParser.componentType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.type_return type116 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:436:5: ( type )
            // D:\\m\\antlr\\pascal\\pascal.g:436:7: type
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_type_in_componentType1599);
            type116=type();

            state._fsp--;

            adaptor.addChild(root_0, type116.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "componentType"

    public static class recordType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "recordType"
    // D:\\m\\antlr\\pascal\\pascal.g:439:1: recordType : RECORD fieldList END ;
    public final pascalParser.recordType_return recordType() throws RecognitionException {
        pascalParser.recordType_return retval = new pascalParser.recordType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token RECORD117=null;
        Token END119=null;
        pascalParser.fieldList_return fieldList118 = null;


        PascalAST RECORD117_tree=null;
        PascalAST END119_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:440:5: ( RECORD fieldList END )
            // D:\\m\\antlr\\pascal\\pascal.g:440:7: RECORD fieldList END
            {
            root_0 = (PascalAST)adaptor.nil();

            RECORD117=(Token)match(input,RECORD,FOLLOW_RECORD_in_recordType1616); 
            RECORD117_tree = (PascalAST)adaptor.create(RECORD117);
            root_0 = (PascalAST)adaptor.becomeRoot(RECORD117_tree, root_0);

            pushFollow(FOLLOW_fieldList_in_recordType1619);
            fieldList118=fieldList();

            state._fsp--;

            adaptor.addChild(root_0, fieldList118.getTree());
            END119=(Token)match(input,END,FOLLOW_END_in_recordType1621); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "recordType"

    public static class fieldList_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fieldList"
    // D:\\m\\antlr\\pascal\\pascal.g:443:1: fieldList : ( fixedPart ( SEMI variantPart | SEMI )? -> ^( FIELDLIST fixedPart variantPart ) | variantPart -> ^( FIELDLIST variantPart ) ) ;
    public final pascalParser.fieldList_return fieldList() throws RecognitionException {
        pascalParser.fieldList_return retval = new pascalParser.fieldList_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token SEMI121=null;
        Token SEMI123=null;
        pascalParser.fixedPart_return fixedPart120 = null;

        pascalParser.variantPart_return variantPart122 = null;

        pascalParser.variantPart_return variantPart124 = null;


        PascalAST SEMI121_tree=null;
        PascalAST SEMI123_tree=null;
        RewriteRuleTokenStream stream_SEMI=new RewriteRuleTokenStream(adaptor,"token SEMI");
        RewriteRuleSubtreeStream stream_fixedPart=new RewriteRuleSubtreeStream(adaptor,"rule fixedPart");
        RewriteRuleSubtreeStream stream_variantPart=new RewriteRuleSubtreeStream(adaptor,"rule variantPart");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:444:5: ( ( fixedPart ( SEMI variantPart | SEMI )? -> ^( FIELDLIST fixedPart variantPart ) | variantPart -> ^( FIELDLIST variantPart ) ) )
            // D:\\m\\antlr\\pascal\\pascal.g:444:7: ( fixedPart ( SEMI variantPart | SEMI )? -> ^( FIELDLIST fixedPart variantPart ) | variantPart -> ^( FIELDLIST variantPart ) )
            {
            // D:\\m\\antlr\\pascal\\pascal.g:444:7: ( fixedPart ( SEMI variantPart | SEMI )? -> ^( FIELDLIST fixedPart variantPart ) | variantPart -> ^( FIELDLIST variantPart ) )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==IDENT) ) {
                alt22=1;
            }
            else if ( (LA22_0==CASE) ) {
                alt22=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:444:9: fixedPart ( SEMI variantPart | SEMI )?
                    {
                    pushFollow(FOLLOW_fixedPart_in_fieldList1641);
                    fixedPart120=fixedPart();

                    state._fsp--;

                    stream_fixedPart.add(fixedPart120.getTree());
                    // D:\\m\\antlr\\pascal\\pascal.g:444:19: ( SEMI variantPart | SEMI )?
                    int alt21=3;
                    int LA21_0 = input.LA(1);

                    if ( (LA21_0==SEMI) ) {
                        int LA21_1 = input.LA(2);

                        if ( (LA21_1==RPAREN||LA21_1==END) ) {
                            alt21=2;
                        }
                        else if ( (LA21_1==CASE) ) {
                            alt21=1;
                        }
                    }
                    switch (alt21) {
                        case 1 :
                            // D:\\m\\antlr\\pascal\\pascal.g:444:21: SEMI variantPart
                            {
                            SEMI121=(Token)match(input,SEMI,FOLLOW_SEMI_in_fieldList1645);  
                            stream_SEMI.add(SEMI121);

                            pushFollow(FOLLOW_variantPart_in_fieldList1647);
                            variantPart122=variantPart();

                            state._fsp--;

                            stream_variantPart.add(variantPart122.getTree());

                            }
                            break;
                        case 2 :
                            // D:\\m\\antlr\\pascal\\pascal.g:444:40: SEMI
                            {
                            SEMI123=(Token)match(input,SEMI,FOLLOW_SEMI_in_fieldList1651);  
                            stream_SEMI.add(SEMI123);


                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: variantPart, fixedPart
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (PascalAST)adaptor.nil();
                    // 444:48: -> ^( FIELDLIST fixedPart variantPart )
                    {
                        // D:\\m\\antlr\\pascal\\pascal.g:444:51: ^( FIELDLIST fixedPart variantPart )
                        {
                        PascalAST root_1 = (PascalAST)adaptor.nil();
                        root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(FIELDLIST, "FIELDLIST"), root_1);

                        adaptor.addChild(root_1, stream_fixedPart.nextTree());
                        adaptor.addChild(root_1, stream_variantPart.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:445:9: variantPart
                    {
                    pushFollow(FOLLOW_variantPart_in_fieldList1674);
                    variantPart124=variantPart();

                    state._fsp--;

                    stream_variantPart.add(variantPart124.getTree());


                    // AST REWRITE
                    // elements: variantPart
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (PascalAST)adaptor.nil();
                    // 445:22: -> ^( FIELDLIST variantPart )
                    {
                        // D:\\m\\antlr\\pascal\\pascal.g:445:25: ^( FIELDLIST variantPart )
                        {
                        PascalAST root_1 = (PascalAST)adaptor.nil();
                        root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(FIELDLIST, "FIELDLIST"), root_1);

                        adaptor.addChild(root_1, stream_variantPart.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fieldList"

    public static class fixedPart_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fixedPart"
    // D:\\m\\antlr\\pascal\\pascal.g:450:1: fixedPart : recordSection ( SEMI recordSection )* ;
    public final pascalParser.fixedPart_return fixedPart() throws RecognitionException {
        pascalParser.fixedPart_return retval = new pascalParser.fixedPart_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token SEMI126=null;
        pascalParser.recordSection_return recordSection125 = null;

        pascalParser.recordSection_return recordSection127 = null;


        PascalAST SEMI126_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:451:5: ( recordSection ( SEMI recordSection )* )
            // D:\\m\\antlr\\pascal\\pascal.g:451:7: recordSection ( SEMI recordSection )*
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_recordSection_in_fixedPart1713);
            recordSection125=recordSection();

            state._fsp--;

            adaptor.addChild(root_0, recordSection125.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:451:21: ( SEMI recordSection )*
            loop23:
            do {
                int alt23=2;
                int LA23_0 = input.LA(1);

                if ( (LA23_0==SEMI) ) {
                    int LA23_1 = input.LA(2);

                    if ( (LA23_1==IDENT) ) {
                        alt23=1;
                    }


                }


                switch (alt23) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:451:23: SEMI recordSection
            	    {
            	    SEMI126=(Token)match(input,SEMI,FOLLOW_SEMI_in_fixedPart1717); 
            	    pushFollow(FOLLOW_recordSection_in_fixedPart1720);
            	    recordSection127=recordSection();

            	    state._fsp--;

            	    adaptor.addChild(root_0, recordSection127.getTree());

            	    }
            	    break;

            	default :
            	    break loop23;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fixedPart"

    public static class recordSection_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "recordSection"
    // D:\\m\\antlr\\pascal\\pascal.g:454:1: recordSection : identifierList COLON type -> ^( FIELD identifierList type ) ;
    public final pascalParser.recordSection_return recordSection() throws RecognitionException {
        pascalParser.recordSection_return retval = new pascalParser.recordSection_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token COLON129=null;
        pascalParser.identifierList_return identifierList128 = null;

        pascalParser.type_return type130 = null;


        PascalAST COLON129_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleSubtreeStream stream_identifierList=new RewriteRuleSubtreeStream(adaptor,"rule identifierList");
        RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:455:5: ( identifierList COLON type -> ^( FIELD identifierList type ) )
            // D:\\m\\antlr\\pascal\\pascal.g:455:7: identifierList COLON type
            {
            pushFollow(FOLLOW_identifierList_in_recordSection1740);
            identifierList128=identifierList();

            state._fsp--;

            stream_identifierList.add(identifierList128.getTree());
            COLON129=(Token)match(input,COLON,FOLLOW_COLON_in_recordSection1742);  
            stream_COLON.add(COLON129);

            pushFollow(FOLLOW_type_in_recordSection1744);
            type130=type();

            state._fsp--;

            stream_type.add(type130.getTree());


            // AST REWRITE
            // elements: type, identifierList
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (PascalAST)adaptor.nil();
            // 455:33: -> ^( FIELD identifierList type )
            {
                // D:\\m\\antlr\\pascal\\pascal.g:455:36: ^( FIELD identifierList type )
                {
                PascalAST root_1 = (PascalAST)adaptor.nil();
                root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(FIELD, "FIELD"), root_1);

                adaptor.addChild(root_1, stream_identifierList.nextTree());
                adaptor.addChild(root_1, stream_type.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "recordSection"

    public static class variantPart_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variantPart"
    // D:\\m\\antlr\\pascal\\pascal.g:459:1: variantPart : CASE tag OF variant ( SEMI variant | SEMI )* ;
    public final pascalParser.variantPart_return variantPart() throws RecognitionException {
        pascalParser.variantPart_return retval = new pascalParser.variantPart_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token CASE131=null;
        Token OF133=null;
        Token SEMI135=null;
        Token SEMI137=null;
        pascalParser.tag_return tag132 = null;

        pascalParser.variant_return variant134 = null;

        pascalParser.variant_return variant136 = null;


        PascalAST CASE131_tree=null;
        PascalAST OF133_tree=null;
        PascalAST SEMI135_tree=null;
        PascalAST SEMI137_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:460:5: ( CASE tag OF variant ( SEMI variant | SEMI )* )
            // D:\\m\\antlr\\pascal\\pascal.g:460:7: CASE tag OF variant ( SEMI variant | SEMI )*
            {
            root_0 = (PascalAST)adaptor.nil();

            CASE131=(Token)match(input,CASE,FOLLOW_CASE_in_variantPart1772); 
            CASE131_tree = (PascalAST)adaptor.create(CASE131);
            root_0 = (PascalAST)adaptor.becomeRoot(CASE131_tree, root_0);

            pushFollow(FOLLOW_tag_in_variantPart1775);
            tag132=tag();

            state._fsp--;

            adaptor.addChild(root_0, tag132.getTree());
            OF133=(Token)match(input,OF,FOLLOW_OF_in_variantPart1777); 
            pushFollow(FOLLOW_variant_in_variantPart1780);
            variant134=variant();

            state._fsp--;

            adaptor.addChild(root_0, variant134.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:460:29: ( SEMI variant | SEMI )*
            loop24:
            do {
                int alt24=3;
                alt24 = dfa24.predict(input);
                switch (alt24) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:460:31: SEMI variant
            	    {
            	    SEMI135=(Token)match(input,SEMI,FOLLOW_SEMI_in_variantPart1784); 
            	    pushFollow(FOLLOW_variant_in_variantPart1787);
            	    variant136=variant();

            	    state._fsp--;

            	    adaptor.addChild(root_0, variant136.getTree());

            	    }
            	    break;
            	case 2 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:460:47: SEMI
            	    {
            	    SEMI137=(Token)match(input,SEMI,FOLLOW_SEMI_in_variantPart1791); 

            	    }
            	    break;

            	default :
            	    break loop24;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variantPart"

    public static class tag_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "tag"
    // D:\\m\\antlr\\pascal\\pascal.g:463:1: tag : (id= identifier COLON t= typeIdentifier -> ^( VARIANT_TAG $id $t) | t2= typeIdentifier -> ^( VARIANT_TAG_NO_ID $t2) );
    public final pascalParser.tag_return tag() throws RecognitionException {
        pascalParser.tag_return retval = new pascalParser.tag_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token COLON138=null;
        pascalParser.identifier_return id = null;

        pascalParser.typeIdentifier_return t = null;

        pascalParser.typeIdentifier_return t2 = null;


        PascalAST COLON138_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleSubtreeStream stream_typeIdentifier=new RewriteRuleSubtreeStream(adaptor,"rule typeIdentifier");
        RewriteRuleSubtreeStream stream_identifier=new RewriteRuleSubtreeStream(adaptor,"rule identifier");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:464:5: (id= identifier COLON t= typeIdentifier -> ^( VARIANT_TAG $id $t) | t2= typeIdentifier -> ^( VARIANT_TAG_NO_ID $t2) )
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==IDENT) ) {
                int LA25_1 = input.LA(2);

                if ( (LA25_1==COLON) ) {
                    alt25=1;
                }
                else if ( (LA25_1==OF) ) {
                    alt25=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 25, 1, input);

                    throw nvae;
                }
            }
            else if ( ((LA25_0>=CHAR && LA25_0<=STRING)) ) {
                alt25=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 25, 0, input);

                throw nvae;
            }
            switch (alt25) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:464:7: id= identifier COLON t= typeIdentifier
                    {
                    pushFollow(FOLLOW_identifier_in_tag1815);
                    id=identifier();

                    state._fsp--;

                    stream_identifier.add(id.getTree());
                    COLON138=(Token)match(input,COLON,FOLLOW_COLON_in_tag1817);  
                    stream_COLON.add(COLON138);

                    pushFollow(FOLLOW_typeIdentifier_in_tag1821);
                    t=typeIdentifier();

                    state._fsp--;

                    stream_typeIdentifier.add(t.getTree());


                    // AST REWRITE
                    // elements: t, id
                    // token labels: 
                    // rule labels: id, retval, t
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id",id!=null?id.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
                    RewriteRuleSubtreeStream stream_t=new RewriteRuleSubtreeStream(adaptor,"rule t",t!=null?t.tree:null);

                    root_0 = (PascalAST)adaptor.nil();
                    // 464:44: -> ^( VARIANT_TAG $id $t)
                    {
                        // D:\\m\\antlr\\pascal\\pascal.g:464:47: ^( VARIANT_TAG $id $t)
                        {
                        PascalAST root_1 = (PascalAST)adaptor.nil();
                        root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(VARIANT_TAG, "VARIANT_TAG"), root_1);

                        adaptor.addChild(root_1, stream_id.nextTree());
                        adaptor.addChild(root_1, stream_t.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:465:7: t2= typeIdentifier
                    {
                    pushFollow(FOLLOW_typeIdentifier_in_tag1844);
                    t2=typeIdentifier();

                    state._fsp--;

                    stream_typeIdentifier.add(t2.getTree());


                    // AST REWRITE
                    // elements: t2
                    // token labels: 
                    // rule labels: t2, retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_t2=new RewriteRuleSubtreeStream(adaptor,"rule t2",t2!=null?t2.tree:null);
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (PascalAST)adaptor.nil();
                    // 465:26: -> ^( VARIANT_TAG_NO_ID $t2)
                    {
                        // D:\\m\\antlr\\pascal\\pascal.g:465:29: ^( VARIANT_TAG_NO_ID $t2)
                        {
                        PascalAST root_1 = (PascalAST)adaptor.nil();
                        root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(VARIANT_TAG_NO_ID, "VARIANT_TAG_NO_ID"), root_1);

                        adaptor.addChild(root_1, stream_t2.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "tag"

    public static class variant_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variant"
    // D:\\m\\antlr\\pascal\\pascal.g:468:1: variant : constList c= COLON LPAREN fieldList RPAREN ;
    public final pascalParser.variant_return variant() throws RecognitionException {
        pascalParser.variant_return retval = new pascalParser.variant_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token c=null;
        Token LPAREN140=null;
        Token RPAREN142=null;
        pascalParser.constList_return constList139 = null;

        pascalParser.fieldList_return fieldList141 = null;


        PascalAST c_tree=null;
        PascalAST LPAREN140_tree=null;
        PascalAST RPAREN142_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:469:5: ( constList c= COLON LPAREN fieldList RPAREN )
            // D:\\m\\antlr\\pascal\\pascal.g:469:7: constList c= COLON LPAREN fieldList RPAREN
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_constList_in_variant1880);
            constList139=constList();

            state._fsp--;

            adaptor.addChild(root_0, constList139.getTree());
            c=(Token)match(input,COLON,FOLLOW_COLON_in_variant1884); 
            c_tree = (PascalAST)adaptor.create(c);
            root_0 = (PascalAST)adaptor.becomeRoot(c_tree, root_0);

            c.setType(VARIANT_CASE);
            LPAREN140=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_variant1892); 
            pushFollow(FOLLOW_fieldList_in_variant1895);
            fieldList141=fieldList();

            state._fsp--;

            adaptor.addChild(root_0, fieldList141.getTree());
            RPAREN142=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_variant1897); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variant"

    public static class setType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "setType"
    // D:\\m\\antlr\\pascal\\pascal.g:473:1: setType : SET OF baseType ;
    public final pascalParser.setType_return setType() throws RecognitionException {
        pascalParser.setType_return retval = new pascalParser.setType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token SET143=null;
        Token OF144=null;
        pascalParser.baseType_return baseType145 = null;


        PascalAST SET143_tree=null;
        PascalAST OF144_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:474:5: ( SET OF baseType )
            // D:\\m\\antlr\\pascal\\pascal.g:474:7: SET OF baseType
            {
            root_0 = (PascalAST)adaptor.nil();

            SET143=(Token)match(input,SET,FOLLOW_SET_in_setType1915); 
            SET143_tree = (PascalAST)adaptor.create(SET143);
            root_0 = (PascalAST)adaptor.becomeRoot(SET143_tree, root_0);

            OF144=(Token)match(input,OF,FOLLOW_OF_in_setType1918); 
            pushFollow(FOLLOW_baseType_in_setType1921);
            baseType145=baseType();

            state._fsp--;

            adaptor.addChild(root_0, baseType145.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "setType"

    public static class baseType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "baseType"
    // D:\\m\\antlr\\pascal\\pascal.g:477:1: baseType : simpleType ;
    public final pascalParser.baseType_return baseType() throws RecognitionException {
        pascalParser.baseType_return retval = new pascalParser.baseType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.simpleType_return simpleType146 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:478:5: ( simpleType )
            // D:\\m\\antlr\\pascal\\pascal.g:478:7: simpleType
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_simpleType_in_baseType1938);
            simpleType146=simpleType();

            state._fsp--;

            adaptor.addChild(root_0, simpleType146.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "baseType"

    public static class fileType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "fileType"
    // D:\\m\\antlr\\pascal\\pascal.g:481:1: fileType : ( FILE OF type | FILE );
    public final pascalParser.fileType_return fileType() throws RecognitionException {
        pascalParser.fileType_return retval = new pascalParser.fileType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token FILE147=null;
        Token OF148=null;
        Token FILE150=null;
        pascalParser.type_return type149 = null;


        PascalAST FILE147_tree=null;
        PascalAST OF148_tree=null;
        PascalAST FILE150_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:482:5: ( FILE OF type | FILE )
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==FILE) ) {
                int LA26_1 = input.LA(2);

                if ( (LA26_1==OF) ) {
                    alt26=1;
                }
                else if ( ((LA26_1>=RPAREN && LA26_1<=SEMI)||LA26_1==END) ) {
                    alt26=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 26, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 26, 0, input);

                throw nvae;
            }
            switch (alt26) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:482:7: FILE OF type
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    FILE147=(Token)match(input,FILE,FOLLOW_FILE_in_fileType1955); 
                    FILE147_tree = (PascalAST)adaptor.create(FILE147);
                    root_0 = (PascalAST)adaptor.becomeRoot(FILE147_tree, root_0);

                    OF148=(Token)match(input,OF,FOLLOW_OF_in_fileType1958); 
                    pushFollow(FOLLOW_type_in_fileType1961);
                    type149=type();

                    state._fsp--;

                    adaptor.addChild(root_0, type149.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:483:7: FILE
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    FILE150=(Token)match(input,FILE,FOLLOW_FILE_in_fileType1969); 
                    FILE150_tree = (PascalAST)adaptor.create(FILE150);
                    adaptor.addChild(root_0, FILE150_tree);


                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "fileType"

    public static class pointerType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "pointerType"
    // D:\\m\\antlr\\pascal\\pascal.g:486:1: pointerType : POINTER typeIdentifier ;
    public final pascalParser.pointerType_return pointerType() throws RecognitionException {
        pascalParser.pointerType_return retval = new pascalParser.pointerType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token POINTER151=null;
        pascalParser.typeIdentifier_return typeIdentifier152 = null;


        PascalAST POINTER151_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:487:5: ( POINTER typeIdentifier )
            // D:\\m\\antlr\\pascal\\pascal.g:487:7: POINTER typeIdentifier
            {
            root_0 = (PascalAST)adaptor.nil();

            POINTER151=(Token)match(input,POINTER,FOLLOW_POINTER_in_pointerType1986); 
            POINTER151_tree = (PascalAST)adaptor.create(POINTER151);
            root_0 = (PascalAST)adaptor.becomeRoot(POINTER151_tree, root_0);

            pushFollow(FOLLOW_typeIdentifier_in_pointerType1989);
            typeIdentifier152=typeIdentifier();

            state._fsp--;

            adaptor.addChild(root_0, typeIdentifier152.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "pointerType"

    public static class variableDeclarationPart_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variableDeclarationPart"
    // D:\\m\\antlr\\pascal\\pascal.g:490:1: variableDeclarationPart : VAR variableDeclaration ( SEMI variableDeclaration )* SEMI ;
    public final pascalParser.variableDeclarationPart_return variableDeclarationPart() throws RecognitionException {
        pascalParser.variableDeclarationPart_return retval = new pascalParser.variableDeclarationPart_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token VAR153=null;
        Token SEMI155=null;
        Token SEMI157=null;
        pascalParser.variableDeclaration_return variableDeclaration154 = null;

        pascalParser.variableDeclaration_return variableDeclaration156 = null;


        PascalAST VAR153_tree=null;
        PascalAST SEMI155_tree=null;
        PascalAST SEMI157_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:492:5: ( VAR variableDeclaration ( SEMI variableDeclaration )* SEMI )
            // D:\\m\\antlr\\pascal\\pascal.g:492:7: VAR variableDeclaration ( SEMI variableDeclaration )* SEMI
            {
            root_0 = (PascalAST)adaptor.nil();

            VAR153=(Token)match(input,VAR,FOLLOW_VAR_in_variableDeclarationPart2008); 
            VAR153_tree = (PascalAST)adaptor.create(VAR153);
            root_0 = (PascalAST)adaptor.becomeRoot(VAR153_tree, root_0);

            pushFollow(FOLLOW_variableDeclaration_in_variableDeclarationPart2011);
            variableDeclaration154=variableDeclaration();

            state._fsp--;

            adaptor.addChild(root_0, variableDeclaration154.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:492:32: ( SEMI variableDeclaration )*
            loop27:
            do {
                int alt27=2;
                alt27 = dfa27.predict(input);
                switch (alt27) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:492:34: SEMI variableDeclaration
            	    {
            	    SEMI155=(Token)match(input,SEMI,FOLLOW_SEMI_in_variableDeclarationPart2015); 
            	    pushFollow(FOLLOW_variableDeclaration_in_variableDeclarationPart2018);
            	    variableDeclaration156=variableDeclaration();

            	    state._fsp--;

            	    adaptor.addChild(root_0, variableDeclaration156.getTree());

            	    }
            	    break;

            	default :
            	    break loop27;
                }
            } while (true);

            SEMI157=(Token)match(input,SEMI,FOLLOW_SEMI_in_variableDeclarationPart2023); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variableDeclarationPart"

    public static class variableDeclaration_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variableDeclaration"
    // D:\\m\\antlr\\pascal\\pascal.g:495:1: variableDeclaration : identifierList c= COLON type ;
    public final pascalParser.variableDeclaration_return variableDeclaration() throws RecognitionException {
        pascalParser.variableDeclaration_return retval = new pascalParser.variableDeclaration_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token c=null;
        pascalParser.identifierList_return identifierList158 = null;

        pascalParser.type_return type159 = null;


        PascalAST c_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:496:5: ( identifierList c= COLON type )
            // D:\\m\\antlr\\pascal\\pascal.g:496:7: identifierList c= COLON type
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_identifierList_in_variableDeclaration2041);
            identifierList158=identifierList();

            state._fsp--;

            adaptor.addChild(root_0, identifierList158.getTree());
            c=(Token)match(input,COLON,FOLLOW_COLON_in_variableDeclaration2045); 
            c_tree = (PascalAST)adaptor.create(c);
            root_0 = (PascalAST)adaptor.becomeRoot(c_tree, root_0);

            c.setType(VARDECL);
            pushFollow(FOLLOW_type_in_variableDeclaration2050);
            type159=type();

            state._fsp--;

            adaptor.addChild(root_0, type159.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variableDeclaration"

    public static class procedureAndFunctionDeclarationPart_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "procedureAndFunctionDeclarationPart"
    // D:\\m\\antlr\\pascal\\pascal.g:499:1: procedureAndFunctionDeclarationPart : procedureOrFunctionDeclaration SEMI ;
    public final pascalParser.procedureAndFunctionDeclarationPart_return procedureAndFunctionDeclarationPart() throws RecognitionException {
        pascalParser.procedureAndFunctionDeclarationPart_return retval = new pascalParser.procedureAndFunctionDeclarationPart_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token SEMI161=null;
        pascalParser.procedureOrFunctionDeclaration_return procedureOrFunctionDeclaration160 = null;


        PascalAST SEMI161_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:500:5: ( procedureOrFunctionDeclaration SEMI )
            // D:\\m\\antlr\\pascal\\pascal.g:500:7: procedureOrFunctionDeclaration SEMI
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_procedureOrFunctionDeclaration_in_procedureAndFunctionDeclarationPart2067);
            procedureOrFunctionDeclaration160=procedureOrFunctionDeclaration();

            state._fsp--;

            adaptor.addChild(root_0, procedureOrFunctionDeclaration160.getTree());
            SEMI161=(Token)match(input,SEMI,FOLLOW_SEMI_in_procedureAndFunctionDeclarationPart2069); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "procedureAndFunctionDeclarationPart"

    public static class procedureOrFunctionDeclaration_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "procedureOrFunctionDeclaration"
    // D:\\m\\antlr\\pascal\\pascal.g:503:1: procedureOrFunctionDeclaration : ( procedureDeclaration | functionDeclaration );
    public final pascalParser.procedureOrFunctionDeclaration_return procedureOrFunctionDeclaration() throws RecognitionException {
        pascalParser.procedureOrFunctionDeclaration_return retval = new pascalParser.procedureOrFunctionDeclaration_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.procedureDeclaration_return procedureDeclaration162 = null;

        pascalParser.functionDeclaration_return functionDeclaration163 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:504:5: ( procedureDeclaration | functionDeclaration )
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==PROCEDURE) ) {
                alt28=1;
            }
            else if ( (LA28_0==FUNCTION) ) {
                alt28=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 28, 0, input);

                throw nvae;
            }
            switch (alt28) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:504:7: procedureDeclaration
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_procedureDeclaration_in_procedureOrFunctionDeclaration2087);
                    procedureDeclaration162=procedureDeclaration();

                    state._fsp--;

                    adaptor.addChild(root_0, procedureDeclaration162.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:505:7: functionDeclaration
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_functionDeclaration_in_procedureOrFunctionDeclaration2095);
                    functionDeclaration163=functionDeclaration();

                    state._fsp--;

                    adaptor.addChild(root_0, functionDeclaration163.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "procedureOrFunctionDeclaration"

    public static class procedureDeclaration_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "procedureDeclaration"
    // D:\\m\\antlr\\pascal\\pascal.g:508:1: procedureDeclaration : PROCEDURE identifier ( formalParameterList )? SEMI block ;
    public final pascalParser.procedureDeclaration_return procedureDeclaration() throws RecognitionException {
        pascalParser.procedureDeclaration_return retval = new pascalParser.procedureDeclaration_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token PROCEDURE164=null;
        Token SEMI167=null;
        pascalParser.identifier_return identifier165 = null;

        pascalParser.formalParameterList_return formalParameterList166 = null;

        pascalParser.block_return block168 = null;


        PascalAST PROCEDURE164_tree=null;
        PascalAST SEMI167_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:509:5: ( PROCEDURE identifier ( formalParameterList )? SEMI block )
            // D:\\m\\antlr\\pascal\\pascal.g:509:7: PROCEDURE identifier ( formalParameterList )? SEMI block
            {
            root_0 = (PascalAST)adaptor.nil();

            PROCEDURE164=(Token)match(input,PROCEDURE,FOLLOW_PROCEDURE_in_procedureDeclaration2112); 
            PROCEDURE164_tree = (PascalAST)adaptor.create(PROCEDURE164);
            root_0 = (PascalAST)adaptor.becomeRoot(PROCEDURE164_tree, root_0);

            pushFollow(FOLLOW_identifier_in_procedureDeclaration2115);
            identifier165=identifier();

            state._fsp--;

            adaptor.addChild(root_0, identifier165.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:509:29: ( formalParameterList )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==LPAREN) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:509:30: formalParameterList
                    {
                    pushFollow(FOLLOW_formalParameterList_in_procedureDeclaration2118);
                    formalParameterList166=formalParameterList();

                    state._fsp--;

                    adaptor.addChild(root_0, formalParameterList166.getTree());

                    }
                    break;

            }

            SEMI167=(Token)match(input,SEMI,FOLLOW_SEMI_in_procedureDeclaration2122); 
            pushFollow(FOLLOW_block_in_procedureDeclaration2131);
            block168=block();

            state._fsp--;

            adaptor.addChild(root_0, block168.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "procedureDeclaration"

    public static class formalParameterList_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "formalParameterList"
    // D:\\m\\antlr\\pascal\\pascal.g:513:1: formalParameterList : LPAREN formalParameterSection ( SEMI formalParameterSection )* RPAREN -> ^( ARGDECLS ( formalParameterSection )+ ) ;
    public final pascalParser.formalParameterList_return formalParameterList() throws RecognitionException {
        pascalParser.formalParameterList_return retval = new pascalParser.formalParameterList_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token LPAREN169=null;
        Token SEMI171=null;
        Token RPAREN173=null;
        pascalParser.formalParameterSection_return formalParameterSection170 = null;

        pascalParser.formalParameterSection_return formalParameterSection172 = null;


        PascalAST LPAREN169_tree=null;
        PascalAST SEMI171_tree=null;
        PascalAST RPAREN173_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_SEMI=new RewriteRuleTokenStream(adaptor,"token SEMI");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_formalParameterSection=new RewriteRuleSubtreeStream(adaptor,"rule formalParameterSection");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:514:5: ( LPAREN formalParameterSection ( SEMI formalParameterSection )* RPAREN -> ^( ARGDECLS ( formalParameterSection )+ ) )
            // D:\\m\\antlr\\pascal\\pascal.g:514:7: LPAREN formalParameterSection ( SEMI formalParameterSection )* RPAREN
            {
            LPAREN169=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_formalParameterList2148);  
            stream_LPAREN.add(LPAREN169);

            pushFollow(FOLLOW_formalParameterSection_in_formalParameterList2150);
            formalParameterSection170=formalParameterSection();

            state._fsp--;

            stream_formalParameterSection.add(formalParameterSection170.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:514:37: ( SEMI formalParameterSection )*
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( (LA30_0==SEMI) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:514:39: SEMI formalParameterSection
            	    {
            	    SEMI171=(Token)match(input,SEMI,FOLLOW_SEMI_in_formalParameterList2154);  
            	    stream_SEMI.add(SEMI171);

            	    pushFollow(FOLLOW_formalParameterSection_in_formalParameterList2156);
            	    formalParameterSection172=formalParameterSection();

            	    state._fsp--;

            	    stream_formalParameterSection.add(formalParameterSection172.getTree());

            	    }
            	    break;

            	default :
            	    break loop30;
                }
            } while (true);

            RPAREN173=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_formalParameterList2161);  
            stream_RPAREN.add(RPAREN173);



            // AST REWRITE
            // elements: formalParameterSection
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (PascalAST)adaptor.nil();
            // 515:8: -> ^( ARGDECLS ( formalParameterSection )+ )
            {
                // D:\\m\\antlr\\pascal\\pascal.g:515:11: ^( ARGDECLS ( formalParameterSection )+ )
                {
                PascalAST root_1 = (PascalAST)adaptor.nil();
                root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(ARGDECLS, "ARGDECLS"), root_1);

                if ( !(stream_formalParameterSection.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_formalParameterSection.hasNext() ) {
                    adaptor.addChild(root_1, stream_formalParameterSection.nextTree());

                }
                stream_formalParameterSection.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "formalParameterList"

    public static class formalParameterSection_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "formalParameterSection"
    // D:\\m\\antlr\\pascal\\pascal.g:519:1: formalParameterSection : ( parameterGroup | VAR parameterGroup | FUNCTION parameterGroup | PROCEDURE parameterGroup );
    public final pascalParser.formalParameterSection_return formalParameterSection() throws RecognitionException {
        pascalParser.formalParameterSection_return retval = new pascalParser.formalParameterSection_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token VAR175=null;
        Token FUNCTION177=null;
        Token PROCEDURE179=null;
        pascalParser.parameterGroup_return parameterGroup174 = null;

        pascalParser.parameterGroup_return parameterGroup176 = null;

        pascalParser.parameterGroup_return parameterGroup178 = null;

        pascalParser.parameterGroup_return parameterGroup180 = null;


        PascalAST VAR175_tree=null;
        PascalAST FUNCTION177_tree=null;
        PascalAST PROCEDURE179_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:520:5: ( parameterGroup | VAR parameterGroup | FUNCTION parameterGroup | PROCEDURE parameterGroup )
            int alt31=4;
            switch ( input.LA(1) ) {
            case IDENT:
                {
                alt31=1;
                }
                break;
            case VAR:
                {
                alt31=2;
                }
                break;
            case FUNCTION:
                {
                alt31=3;
                }
                break;
            case PROCEDURE:
                {
                alt31=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 31, 0, input);

                throw nvae;
            }

            switch (alt31) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:520:7: parameterGroup
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_parameterGroup_in_formalParameterSection2197);
                    parameterGroup174=parameterGroup();

                    state._fsp--;

                    adaptor.addChild(root_0, parameterGroup174.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:521:7: VAR parameterGroup
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    VAR175=(Token)match(input,VAR,FOLLOW_VAR_in_formalParameterSection2205); 
                    VAR175_tree = (PascalAST)adaptor.create(VAR175);
                    root_0 = (PascalAST)adaptor.becomeRoot(VAR175_tree, root_0);

                    pushFollow(FOLLOW_parameterGroup_in_formalParameterSection2208);
                    parameterGroup176=parameterGroup();

                    state._fsp--;

                    adaptor.addChild(root_0, parameterGroup176.getTree());

                    }
                    break;
                case 3 :
                    // D:\\m\\antlr\\pascal\\pascal.g:522:7: FUNCTION parameterGroup
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    FUNCTION177=(Token)match(input,FUNCTION,FOLLOW_FUNCTION_in_formalParameterSection2216); 
                    FUNCTION177_tree = (PascalAST)adaptor.create(FUNCTION177);
                    root_0 = (PascalAST)adaptor.becomeRoot(FUNCTION177_tree, root_0);

                    pushFollow(FOLLOW_parameterGroup_in_formalParameterSection2219);
                    parameterGroup178=parameterGroup();

                    state._fsp--;

                    adaptor.addChild(root_0, parameterGroup178.getTree());

                    }
                    break;
                case 4 :
                    // D:\\m\\antlr\\pascal\\pascal.g:523:7: PROCEDURE parameterGroup
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    PROCEDURE179=(Token)match(input,PROCEDURE,FOLLOW_PROCEDURE_in_formalParameterSection2227); 
                    PROCEDURE179_tree = (PascalAST)adaptor.create(PROCEDURE179);
                    root_0 = (PascalAST)adaptor.becomeRoot(PROCEDURE179_tree, root_0);

                    pushFollow(FOLLOW_parameterGroup_in_formalParameterSection2230);
                    parameterGroup180=parameterGroup();

                    state._fsp--;

                    adaptor.addChild(root_0, parameterGroup180.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "formalParameterSection"

    public static class parameterGroup_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameterGroup"
    // D:\\m\\antlr\\pascal\\pascal.g:526:1: parameterGroup : ids= identifierList COLON t= typeIdentifier -> ^( ARGDECL $ids $t) ;
    public final pascalParser.parameterGroup_return parameterGroup() throws RecognitionException {
        pascalParser.parameterGroup_return retval = new pascalParser.parameterGroup_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token COLON181=null;
        pascalParser.identifierList_return ids = null;

        pascalParser.typeIdentifier_return t = null;


        PascalAST COLON181_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleSubtreeStream stream_typeIdentifier=new RewriteRuleSubtreeStream(adaptor,"rule typeIdentifier");
        RewriteRuleSubtreeStream stream_identifierList=new RewriteRuleSubtreeStream(adaptor,"rule identifierList");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:527:5: (ids= identifierList COLON t= typeIdentifier -> ^( ARGDECL $ids $t) )
            // D:\\m\\antlr\\pascal\\pascal.g:527:7: ids= identifierList COLON t= typeIdentifier
            {
            pushFollow(FOLLOW_identifierList_in_parameterGroup2250);
            ids=identifierList();

            state._fsp--;

            stream_identifierList.add(ids.getTree());
            COLON181=(Token)match(input,COLON,FOLLOW_COLON_in_parameterGroup2252);  
            stream_COLON.add(COLON181);

            pushFollow(FOLLOW_typeIdentifier_in_parameterGroup2256);
            t=typeIdentifier();

            state._fsp--;

            stream_typeIdentifier.add(t.getTree());


            // AST REWRITE
            // elements: t, ids
            // token labels: 
            // rule labels: retval, t, ids
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_t=new RewriteRuleSubtreeStream(adaptor,"rule t",t!=null?t.tree:null);
            RewriteRuleSubtreeStream stream_ids=new RewriteRuleSubtreeStream(adaptor,"rule ids",ids!=null?ids.tree:null);

            root_0 = (PascalAST)adaptor.nil();
            // 527:49: -> ^( ARGDECL $ids $t)
            {
                // D:\\m\\antlr\\pascal\\pascal.g:527:52: ^( ARGDECL $ids $t)
                {
                PascalAST root_1 = (PascalAST)adaptor.nil();
                root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(ARGDECL, "ARGDECL"), root_1);

                adaptor.addChild(root_1, stream_ids.nextTree());
                adaptor.addChild(root_1, stream_t.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameterGroup"

    public static class identifierList_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "identifierList"
    // D:\\m\\antlr\\pascal\\pascal.g:531:1: identifierList : identifier ( COMMA identifier )* -> ^( IDLIST ( identifier )+ ) ;
    public final pascalParser.identifierList_return identifierList() throws RecognitionException {
        pascalParser.identifierList_return retval = new pascalParser.identifierList_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token COMMA183=null;
        pascalParser.identifier_return identifier182 = null;

        pascalParser.identifier_return identifier184 = null;


        PascalAST COMMA183_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_identifier=new RewriteRuleSubtreeStream(adaptor,"rule identifier");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:532:5: ( identifier ( COMMA identifier )* -> ^( IDLIST ( identifier )+ ) )
            // D:\\m\\antlr\\pascal\\pascal.g:532:7: identifier ( COMMA identifier )*
            {
            pushFollow(FOLLOW_identifier_in_identifierList2287);
            identifier182=identifier();

            state._fsp--;

            stream_identifier.add(identifier182.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:532:18: ( COMMA identifier )*
            loop32:
            do {
                int alt32=2;
                int LA32_0 = input.LA(1);

                if ( (LA32_0==COMMA) ) {
                    alt32=1;
                }


                switch (alt32) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:532:20: COMMA identifier
            	    {
            	    COMMA183=(Token)match(input,COMMA,FOLLOW_COMMA_in_identifierList2291);  
            	    stream_COMMA.add(COMMA183);

            	    pushFollow(FOLLOW_identifier_in_identifierList2293);
            	    identifier184=identifier();

            	    state._fsp--;

            	    stream_identifier.add(identifier184.getTree());

            	    }
            	    break;

            	default :
            	    break loop32;
                }
            } while (true);



            // AST REWRITE
            // elements: identifier
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (PascalAST)adaptor.nil();
            // 532:40: -> ^( IDLIST ( identifier )+ )
            {
                // D:\\m\\antlr\\pascal\\pascal.g:532:43: ^( IDLIST ( identifier )+ )
                {
                PascalAST root_1 = (PascalAST)adaptor.nil();
                root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(IDLIST, "IDLIST"), root_1);

                if ( !(stream_identifier.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_identifier.hasNext() ) {
                    adaptor.addChild(root_1, stream_identifier.nextTree());

                }
                stream_identifier.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "identifierList"

    public static class constList_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "constList"
    // D:\\m\\antlr\\pascal\\pascal.g:536:1: constList : constant ( COMMA constant )* -> ^( CONSTLIST ( constant )+ ) ;
    public final pascalParser.constList_return constList() throws RecognitionException {
        pascalParser.constList_return retval = new pascalParser.constList_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token COMMA186=null;
        pascalParser.constant_return constant185 = null;

        pascalParser.constant_return constant187 = null;


        PascalAST COMMA186_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_constant=new RewriteRuleSubtreeStream(adaptor,"rule constant");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:537:5: ( constant ( COMMA constant )* -> ^( CONSTLIST ( constant )+ ) )
            // D:\\m\\antlr\\pascal\\pascal.g:537:7: constant ( COMMA constant )*
            {
            pushFollow(FOLLOW_constant_in_constList2324);
            constant185=constant();

            state._fsp--;

            stream_constant.add(constant185.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:537:16: ( COMMA constant )*
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( (LA33_0==COMMA) ) {
                    alt33=1;
                }


                switch (alt33) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:537:18: COMMA constant
            	    {
            	    COMMA186=(Token)match(input,COMMA,FOLLOW_COMMA_in_constList2328);  
            	    stream_COMMA.add(COMMA186);

            	    pushFollow(FOLLOW_constant_in_constList2330);
            	    constant187=constant();

            	    state._fsp--;

            	    stream_constant.add(constant187.getTree());

            	    }
            	    break;

            	default :
            	    break loop33;
                }
            } while (true);



            // AST REWRITE
            // elements: constant
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (PascalAST)adaptor.nil();
            // 537:36: -> ^( CONSTLIST ( constant )+ )
            {
                // D:\\m\\antlr\\pascal\\pascal.g:537:39: ^( CONSTLIST ( constant )+ )
                {
                PascalAST root_1 = (PascalAST)adaptor.nil();
                root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(CONSTLIST, "CONSTLIST"), root_1);

                if ( !(stream_constant.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_constant.hasNext() ) {
                    adaptor.addChild(root_1, stream_constant.nextTree());

                }
                stream_constant.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "constList"

    public static class functionDeclaration_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "functionDeclaration"
    // D:\\m\\antlr\\pascal\\pascal.g:541:1: functionDeclaration : FUNCTION identifier ( formalParameterList )? COLON resultType SEMI block ;
    public final pascalParser.functionDeclaration_return functionDeclaration() throws RecognitionException {
        pascalParser.functionDeclaration_return retval = new pascalParser.functionDeclaration_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token FUNCTION188=null;
        Token COLON191=null;
        Token SEMI193=null;
        pascalParser.identifier_return identifier189 = null;

        pascalParser.formalParameterList_return formalParameterList190 = null;

        pascalParser.resultType_return resultType192 = null;

        pascalParser.block_return block194 = null;


        PascalAST FUNCTION188_tree=null;
        PascalAST COLON191_tree=null;
        PascalAST SEMI193_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:542:5: ( FUNCTION identifier ( formalParameterList )? COLON resultType SEMI block )
            // D:\\m\\antlr\\pascal\\pascal.g:542:7: FUNCTION identifier ( formalParameterList )? COLON resultType SEMI block
            {
            root_0 = (PascalAST)adaptor.nil();

            FUNCTION188=(Token)match(input,FUNCTION,FOLLOW_FUNCTION_in_functionDeclaration2361); 
            FUNCTION188_tree = (PascalAST)adaptor.create(FUNCTION188);
            root_0 = (PascalAST)adaptor.becomeRoot(FUNCTION188_tree, root_0);

            pushFollow(FOLLOW_identifier_in_functionDeclaration2364);
            identifier189=identifier();

            state._fsp--;

            adaptor.addChild(root_0, identifier189.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:542:28: ( formalParameterList )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==LPAREN) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:542:29: formalParameterList
                    {
                    pushFollow(FOLLOW_formalParameterList_in_functionDeclaration2367);
                    formalParameterList190=formalParameterList();

                    state._fsp--;

                    adaptor.addChild(root_0, formalParameterList190.getTree());

                    }
                    break;

            }

            COLON191=(Token)match(input,COLON,FOLLOW_COLON_in_functionDeclaration2371); 
            pushFollow(FOLLOW_resultType_in_functionDeclaration2374);
            resultType192=resultType();

            state._fsp--;

            adaptor.addChild(root_0, resultType192.getTree());
            SEMI193=(Token)match(input,SEMI,FOLLOW_SEMI_in_functionDeclaration2376); 
            pushFollow(FOLLOW_block_in_functionDeclaration2385);
            block194=block();

            state._fsp--;

            adaptor.addChild(root_0, block194.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "functionDeclaration"

    public static class resultType_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "resultType"
    // D:\\m\\antlr\\pascal\\pascal.g:546:1: resultType : typeIdentifier ;
    public final pascalParser.resultType_return resultType() throws RecognitionException {
        pascalParser.resultType_return retval = new pascalParser.resultType_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.typeIdentifier_return typeIdentifier195 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:547:5: ( typeIdentifier )
            // D:\\m\\antlr\\pascal\\pascal.g:547:7: typeIdentifier
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_typeIdentifier_in_resultType2402);
            typeIdentifier195=typeIdentifier();

            state._fsp--;

            adaptor.addChild(root_0, typeIdentifier195.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "resultType"

    public static class statement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statement"
    // D:\\m\\antlr\\pascal\\pascal.g:550:1: statement : ( label COLON unlabelledStatement | unlabelledStatement );
    public final pascalParser.statement_return statement() throws RecognitionException {
        pascalParser.statement_return retval = new pascalParser.statement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token COLON197=null;
        pascalParser.label_return label196 = null;

        pascalParser.unlabelledStatement_return unlabelledStatement198 = null;

        pascalParser.unlabelledStatement_return unlabelledStatement199 = null;


        PascalAST COLON197_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:551:5: ( label COLON unlabelledStatement | unlabelledStatement )
            int alt35=2;
            alt35 = dfa35.predict(input);
            switch (alt35) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:551:7: label COLON unlabelledStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_label_in_statement2419);
                    label196=label();

                    state._fsp--;

                    adaptor.addChild(root_0, label196.getTree());
                    COLON197=(Token)match(input,COLON,FOLLOW_COLON_in_statement2421); 
                    COLON197_tree = (PascalAST)adaptor.create(COLON197);
                    root_0 = (PascalAST)adaptor.becomeRoot(COLON197_tree, root_0);

                    pushFollow(FOLLOW_unlabelledStatement_in_statement2424);
                    unlabelledStatement198=unlabelledStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, unlabelledStatement198.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:552:7: unlabelledStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_unlabelledStatement_in_statement2432);
                    unlabelledStatement199=unlabelledStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, unlabelledStatement199.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statement"

    public static class unlabelledStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unlabelledStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:555:1: unlabelledStatement : ( simpleStatement | structuredStatement );
    public final pascalParser.unlabelledStatement_return unlabelledStatement() throws RecognitionException {
        pascalParser.unlabelledStatement_return retval = new pascalParser.unlabelledStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.simpleStatement_return simpleStatement200 = null;

        pascalParser.structuredStatement_return structuredStatement201 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:556:5: ( simpleStatement | structuredStatement )
            int alt36=2;
            alt36 = dfa36.predict(input);
            switch (alt36) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:556:7: simpleStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_simpleStatement_in_unlabelledStatement2449);
                    simpleStatement200=simpleStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, simpleStatement200.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:557:7: structuredStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_structuredStatement_in_unlabelledStatement2457);
                    structuredStatement201=structuredStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, structuredStatement201.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unlabelledStatement"

    public static class simpleStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:560:1: simpleStatement : ( assignmentStatement | procedureStatement | gotoStatement | emptyStatement );
    public final pascalParser.simpleStatement_return simpleStatement() throws RecognitionException {
        pascalParser.simpleStatement_return retval = new pascalParser.simpleStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.assignmentStatement_return assignmentStatement202 = null;

        pascalParser.procedureStatement_return procedureStatement203 = null;

        pascalParser.gotoStatement_return gotoStatement204 = null;

        pascalParser.emptyStatement_return emptyStatement205 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:561:5: ( assignmentStatement | procedureStatement | gotoStatement | emptyStatement )
            int alt37=4;
            alt37 = dfa37.predict(input);
            switch (alt37) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:561:7: assignmentStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_assignmentStatement_in_simpleStatement2474);
                    assignmentStatement202=assignmentStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, assignmentStatement202.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:562:7: procedureStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_procedureStatement_in_simpleStatement2482);
                    procedureStatement203=procedureStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, procedureStatement203.getTree());

                    }
                    break;
                case 3 :
                    // D:\\m\\antlr\\pascal\\pascal.g:563:7: gotoStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_gotoStatement_in_simpleStatement2490);
                    gotoStatement204=gotoStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, gotoStatement204.getTree());

                    }
                    break;
                case 4 :
                    // D:\\m\\antlr\\pascal\\pascal.g:564:7: emptyStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_emptyStatement_in_simpleStatement2498);
                    emptyStatement205=emptyStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, emptyStatement205.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleStatement"

    public static class assignmentStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignmentStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:567:1: assignmentStatement : variable ASSIGN expression ;
    public final pascalParser.assignmentStatement_return assignmentStatement() throws RecognitionException {
        pascalParser.assignmentStatement_return retval = new pascalParser.assignmentStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token ASSIGN207=null;
        pascalParser.variable_return variable206 = null;

        pascalParser.expression_return expression208 = null;


        PascalAST ASSIGN207_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:568:5: ( variable ASSIGN expression )
            // D:\\m\\antlr\\pascal\\pascal.g:568:7: variable ASSIGN expression
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_variable_in_assignmentStatement2515);
            variable206=variable();

            state._fsp--;

            adaptor.addChild(root_0, variable206.getTree());
            ASSIGN207=(Token)match(input,ASSIGN,FOLLOW_ASSIGN_in_assignmentStatement2517); 
            ASSIGN207_tree = (PascalAST)adaptor.create(ASSIGN207);
            root_0 = (PascalAST)adaptor.becomeRoot(ASSIGN207_tree, root_0);

            pushFollow(FOLLOW_expression_in_assignmentStatement2520);
            expression208=expression();

            state._fsp--;

            adaptor.addChild(root_0, expression208.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignmentStatement"

    public static class variable_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "variable"
    // D:\\m\\antlr\\pascal\\pascal.g:571:1: variable : ( AT identifier | identifier ) ( LBRACK expression ( COMMA expression )* RBRACK | LBRACK2 expression ( COMMA expression )* RBRACK2 | DOT identifier | POINTER )* ;
    public final pascalParser.variable_return variable() throws RecognitionException {
        pascalParser.variable_return retval = new pascalParser.variable_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token AT209=null;
        Token LBRACK212=null;
        Token COMMA214=null;
        Token RBRACK216=null;
        Token LBRACK2217=null;
        Token COMMA219=null;
        Token RBRACK2221=null;
        Token DOT222=null;
        Token POINTER224=null;
        pascalParser.identifier_return identifier210 = null;

        pascalParser.identifier_return identifier211 = null;

        pascalParser.expression_return expression213 = null;

        pascalParser.expression_return expression215 = null;

        pascalParser.expression_return expression218 = null;

        pascalParser.expression_return expression220 = null;

        pascalParser.identifier_return identifier223 = null;


        PascalAST AT209_tree=null;
        PascalAST LBRACK212_tree=null;
        PascalAST COMMA214_tree=null;
        PascalAST RBRACK216_tree=null;
        PascalAST LBRACK2217_tree=null;
        PascalAST COMMA219_tree=null;
        PascalAST RBRACK2221_tree=null;
        PascalAST DOT222_tree=null;
        PascalAST POINTER224_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:587:5: ( ( AT identifier | identifier ) ( LBRACK expression ( COMMA expression )* RBRACK | LBRACK2 expression ( COMMA expression )* RBRACK2 | DOT identifier | POINTER )* )
            // D:\\m\\antlr\\pascal\\pascal.g:587:7: ( AT identifier | identifier ) ( LBRACK expression ( COMMA expression )* RBRACK | LBRACK2 expression ( COMMA expression )* RBRACK2 | DOT identifier | POINTER )*
            {
            root_0 = (PascalAST)adaptor.nil();

            // D:\\m\\antlr\\pascal\\pascal.g:587:7: ( AT identifier | identifier )
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==AT) ) {
                alt38=1;
            }
            else if ( (LA38_0==IDENT) ) {
                alt38=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 38, 0, input);

                throw nvae;
            }
            switch (alt38) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:587:9: AT identifier
                    {
                    AT209=(Token)match(input,AT,FOLLOW_AT_in_variable2541); 
                    AT209_tree = (PascalAST)adaptor.create(AT209);
                    root_0 = (PascalAST)adaptor.becomeRoot(AT209_tree, root_0);

                    pushFollow(FOLLOW_identifier_in_variable2544);
                    identifier210=identifier();

                    state._fsp--;

                    adaptor.addChild(root_0, identifier210.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:588:9: identifier
                    {
                    pushFollow(FOLLOW_identifier_in_variable2555);
                    identifier211=identifier();

                    state._fsp--;

                    adaptor.addChild(root_0, identifier211.getTree());

                    }
                    break;

            }

            // D:\\m\\antlr\\pascal\\pascal.g:590:7: ( LBRACK expression ( COMMA expression )* RBRACK | LBRACK2 expression ( COMMA expression )* RBRACK2 | DOT identifier | POINTER )*
            loop41:
            do {
                int alt41=5;
                alt41 = dfa41.predict(input);
                switch (alt41) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:590:9: LBRACK expression ( COMMA expression )* RBRACK
            	    {
            	    LBRACK212=(Token)match(input,LBRACK,FOLLOW_LBRACK_in_variable2573); 
            	    LBRACK212_tree = (PascalAST)adaptor.create(LBRACK212);
            	    root_0 = (PascalAST)adaptor.becomeRoot(LBRACK212_tree, root_0);

            	    pushFollow(FOLLOW_expression_in_variable2576);
            	    expression213=expression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, expression213.getTree());
            	    // D:\\m\\antlr\\pascal\\pascal.g:590:28: ( COMMA expression )*
            	    loop39:
            	    do {
            	        int alt39=2;
            	        int LA39_0 = input.LA(1);

            	        if ( (LA39_0==COMMA) ) {
            	            alt39=1;
            	        }


            	        switch (alt39) {
            	    	case 1 :
            	    	    // D:\\m\\antlr\\pascal\\pascal.g:590:30: COMMA expression
            	    	    {
            	    	    COMMA214=(Token)match(input,COMMA,FOLLOW_COMMA_in_variable2580); 
            	    	    pushFollow(FOLLOW_expression_in_variable2583);
            	    	    expression215=expression();

            	    	    state._fsp--;

            	    	    adaptor.addChild(root_0, expression215.getTree());

            	    	    }
            	    	    break;

            	    	default :
            	    	    break loop39;
            	        }
            	    } while (true);

            	    RBRACK216=(Token)match(input,RBRACK,FOLLOW_RBRACK_in_variable2587); 

            	    }
            	    break;
            	case 2 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:591:9: LBRACK2 expression ( COMMA expression )* RBRACK2
            	    {
            	    LBRACK2217=(Token)match(input,LBRACK2,FOLLOW_LBRACK2_in_variable2598); 
            	    LBRACK2217_tree = (PascalAST)adaptor.create(LBRACK2217);
            	    root_0 = (PascalAST)adaptor.becomeRoot(LBRACK2217_tree, root_0);

            	    pushFollow(FOLLOW_expression_in_variable2601);
            	    expression218=expression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, expression218.getTree());
            	    // D:\\m\\antlr\\pascal\\pascal.g:591:29: ( COMMA expression )*
            	    loop40:
            	    do {
            	        int alt40=2;
            	        int LA40_0 = input.LA(1);

            	        if ( (LA40_0==COMMA) ) {
            	            alt40=1;
            	        }


            	        switch (alt40) {
            	    	case 1 :
            	    	    // D:\\m\\antlr\\pascal\\pascal.g:591:31: COMMA expression
            	    	    {
            	    	    COMMA219=(Token)match(input,COMMA,FOLLOW_COMMA_in_variable2605); 
            	    	    pushFollow(FOLLOW_expression_in_variable2608);
            	    	    expression220=expression();

            	    	    state._fsp--;

            	    	    adaptor.addChild(root_0, expression220.getTree());

            	    	    }
            	    	    break;

            	    	default :
            	    	    break loop40;
            	        }
            	    } while (true);

            	    RBRACK2221=(Token)match(input,RBRACK2,FOLLOW_RBRACK2_in_variable2612); 

            	    }
            	    break;
            	case 3 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:592:9: DOT identifier
            	    {
            	    DOT222=(Token)match(input,DOT,FOLLOW_DOT_in_variable2623); 
            	    DOT222_tree = (PascalAST)adaptor.create(DOT222);
            	    root_0 = (PascalAST)adaptor.becomeRoot(DOT222_tree, root_0);

            	    pushFollow(FOLLOW_identifier_in_variable2626);
            	    identifier223=identifier();

            	    state._fsp--;

            	    adaptor.addChild(root_0, identifier223.getTree());

            	    }
            	    break;
            	case 4 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:593:9: POINTER
            	    {
            	    POINTER224=(Token)match(input,POINTER,FOLLOW_POINTER_in_variable2636); 
            	    POINTER224_tree = (PascalAST)adaptor.create(POINTER224);
            	    root_0 = (PascalAST)adaptor.becomeRoot(POINTER224_tree, root_0);


            	    }
            	    break;

            	default :
            	    break loop41;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "variable"

    public static class expression_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expression"
    // D:\\m\\antlr\\pascal\\pascal.g:597:1: expression : simpleExpression ( ( EQUAL | NOT_EQUAL | LT | LE | GE | GT | IN ) simpleExpression )* ;
    public final pascalParser.expression_return expression() throws RecognitionException {
        pascalParser.expression_return retval = new pascalParser.expression_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token EQUAL226=null;
        Token NOT_EQUAL227=null;
        Token LT228=null;
        Token LE229=null;
        Token GE230=null;
        Token GT231=null;
        Token IN232=null;
        pascalParser.simpleExpression_return simpleExpression225 = null;

        pascalParser.simpleExpression_return simpleExpression233 = null;


        PascalAST EQUAL226_tree=null;
        PascalAST NOT_EQUAL227_tree=null;
        PascalAST LT228_tree=null;
        PascalAST LE229_tree=null;
        PascalAST GE230_tree=null;
        PascalAST GT231_tree=null;
        PascalAST IN232_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:598:5: ( simpleExpression ( ( EQUAL | NOT_EQUAL | LT | LE | GE | GT | IN ) simpleExpression )* )
            // D:\\m\\antlr\\pascal\\pascal.g:598:7: simpleExpression ( ( EQUAL | NOT_EQUAL | LT | LE | GE | GT | IN ) simpleExpression )*
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_simpleExpression_in_expression2663);
            simpleExpression225=simpleExpression();

            state._fsp--;

            adaptor.addChild(root_0, simpleExpression225.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:599:4: ( ( EQUAL | NOT_EQUAL | LT | LE | GE | GT | IN ) simpleExpression )*
            loop43:
            do {
                int alt43=2;
                alt43 = dfa43.predict(input);
                switch (alt43) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:599:6: ( EQUAL | NOT_EQUAL | LT | LE | GE | GT | IN ) simpleExpression
            	    {
            	    // D:\\m\\antlr\\pascal\\pascal.g:599:6: ( EQUAL | NOT_EQUAL | LT | LE | GE | GT | IN )
            	    int alt42=7;
            	    switch ( input.LA(1) ) {
            	    case EQUAL:
            	        {
            	        alt42=1;
            	        }
            	        break;
            	    case NOT_EQUAL:
            	        {
            	        alt42=2;
            	        }
            	        break;
            	    case LT:
            	        {
            	        alt42=3;
            	        }
            	        break;
            	    case LE:
            	        {
            	        alt42=4;
            	        }
            	        break;
            	    case GE:
            	        {
            	        alt42=5;
            	        }
            	        break;
            	    case GT:
            	        {
            	        alt42=6;
            	        }
            	        break;
            	    case IN:
            	        {
            	        alt42=7;
            	        }
            	        break;
            	    default:
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 42, 0, input);

            	        throw nvae;
            	    }

            	    switch (alt42) {
            	        case 1 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:599:7: EQUAL
            	            {
            	            EQUAL226=(Token)match(input,EQUAL,FOLLOW_EQUAL_in_expression2671); 
            	            EQUAL226_tree = (PascalAST)adaptor.create(EQUAL226);
            	            root_0 = (PascalAST)adaptor.becomeRoot(EQUAL226_tree, root_0);


            	            }
            	            break;
            	        case 2 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:599:16: NOT_EQUAL
            	            {
            	            NOT_EQUAL227=(Token)match(input,NOT_EQUAL,FOLLOW_NOT_EQUAL_in_expression2676); 
            	            NOT_EQUAL227_tree = (PascalAST)adaptor.create(NOT_EQUAL227);
            	            root_0 = (PascalAST)adaptor.becomeRoot(NOT_EQUAL227_tree, root_0);


            	            }
            	            break;
            	        case 3 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:599:29: LT
            	            {
            	            LT228=(Token)match(input,LT,FOLLOW_LT_in_expression2681); 
            	            LT228_tree = (PascalAST)adaptor.create(LT228);
            	            root_0 = (PascalAST)adaptor.becomeRoot(LT228_tree, root_0);


            	            }
            	            break;
            	        case 4 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:599:35: LE
            	            {
            	            LE229=(Token)match(input,LE,FOLLOW_LE_in_expression2686); 
            	            LE229_tree = (PascalAST)adaptor.create(LE229);
            	            root_0 = (PascalAST)adaptor.becomeRoot(LE229_tree, root_0);


            	            }
            	            break;
            	        case 5 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:599:41: GE
            	            {
            	            GE230=(Token)match(input,GE,FOLLOW_GE_in_expression2691); 
            	            GE230_tree = (PascalAST)adaptor.create(GE230);
            	            root_0 = (PascalAST)adaptor.becomeRoot(GE230_tree, root_0);


            	            }
            	            break;
            	        case 6 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:599:47: GT
            	            {
            	            GT231=(Token)match(input,GT,FOLLOW_GT_in_expression2696); 
            	            GT231_tree = (PascalAST)adaptor.create(GT231);
            	            root_0 = (PascalAST)adaptor.becomeRoot(GT231_tree, root_0);


            	            }
            	            break;
            	        case 7 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:599:53: IN
            	            {
            	            IN232=(Token)match(input,IN,FOLLOW_IN_in_expression2701); 
            	            IN232_tree = (PascalAST)adaptor.create(IN232);
            	            root_0 = (PascalAST)adaptor.becomeRoot(IN232_tree, root_0);


            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_simpleExpression_in_expression2705);
            	    simpleExpression233=simpleExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, simpleExpression233.getTree());

            	    }
            	    break;

            	default :
            	    break loop43;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expression"

    public static class simpleExpression_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "simpleExpression"
    // D:\\m\\antlr\\pascal\\pascal.g:602:1: simpleExpression : term ( ( PLUS | MINUS | OR ) term )* ;
    public final pascalParser.simpleExpression_return simpleExpression() throws RecognitionException {
        pascalParser.simpleExpression_return retval = new pascalParser.simpleExpression_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token PLUS235=null;
        Token MINUS236=null;
        Token OR237=null;
        pascalParser.term_return term234 = null;

        pascalParser.term_return term238 = null;


        PascalAST PLUS235_tree=null;
        PascalAST MINUS236_tree=null;
        PascalAST OR237_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:603:5: ( term ( ( PLUS | MINUS | OR ) term )* )
            // D:\\m\\antlr\\pascal\\pascal.g:603:7: term ( ( PLUS | MINUS | OR ) term )*
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_term_in_simpleExpression2725);
            term234=term();

            state._fsp--;

            adaptor.addChild(root_0, term234.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:603:12: ( ( PLUS | MINUS | OR ) term )*
            loop45:
            do {
                int alt45=2;
                alt45 = dfa45.predict(input);
                switch (alt45) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:603:14: ( PLUS | MINUS | OR ) term
            	    {
            	    // D:\\m\\antlr\\pascal\\pascal.g:603:14: ( PLUS | MINUS | OR )
            	    int alt44=3;
            	    switch ( input.LA(1) ) {
            	    case PLUS:
            	        {
            	        alt44=1;
            	        }
            	        break;
            	    case MINUS:
            	        {
            	        alt44=2;
            	        }
            	        break;
            	    case OR:
            	        {
            	        alt44=3;
            	        }
            	        break;
            	    default:
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 44, 0, input);

            	        throw nvae;
            	    }

            	    switch (alt44) {
            	        case 1 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:603:15: PLUS
            	            {
            	            PLUS235=(Token)match(input,PLUS,FOLLOW_PLUS_in_simpleExpression2730); 
            	            PLUS235_tree = (PascalAST)adaptor.create(PLUS235);
            	            root_0 = (PascalAST)adaptor.becomeRoot(PLUS235_tree, root_0);


            	            }
            	            break;
            	        case 2 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:603:23: MINUS
            	            {
            	            MINUS236=(Token)match(input,MINUS,FOLLOW_MINUS_in_simpleExpression2735); 
            	            MINUS236_tree = (PascalAST)adaptor.create(MINUS236);
            	            root_0 = (PascalAST)adaptor.becomeRoot(MINUS236_tree, root_0);


            	            }
            	            break;
            	        case 3 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:603:32: OR
            	            {
            	            OR237=(Token)match(input,OR,FOLLOW_OR_in_simpleExpression2740); 
            	            OR237_tree = (PascalAST)adaptor.create(OR237);
            	            root_0 = (PascalAST)adaptor.becomeRoot(OR237_tree, root_0);


            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_term_in_simpleExpression2744);
            	    term238=term();

            	    state._fsp--;

            	    adaptor.addChild(root_0, term238.getTree());

            	    }
            	    break;

            	default :
            	    break loop45;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "simpleExpression"

    public static class term_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "term"
    // D:\\m\\antlr\\pascal\\pascal.g:606:1: term : signedFactor ( ( STAR | SLASH | DIV | MOD | AND ) signedFactor )* ;
    public final pascalParser.term_return term() throws RecognitionException {
        pascalParser.term_return retval = new pascalParser.term_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token STAR240=null;
        Token SLASH241=null;
        Token DIV242=null;
        Token MOD243=null;
        Token AND244=null;
        pascalParser.signedFactor_return signedFactor239 = null;

        pascalParser.signedFactor_return signedFactor245 = null;


        PascalAST STAR240_tree=null;
        PascalAST SLASH241_tree=null;
        PascalAST DIV242_tree=null;
        PascalAST MOD243_tree=null;
        PascalAST AND244_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:607:2: ( signedFactor ( ( STAR | SLASH | DIV | MOD | AND ) signedFactor )* )
            // D:\\m\\antlr\\pascal\\pascal.g:607:4: signedFactor ( ( STAR | SLASH | DIV | MOD | AND ) signedFactor )*
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_signedFactor_in_term2761);
            signedFactor239=signedFactor();

            state._fsp--;

            adaptor.addChild(root_0, signedFactor239.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:607:17: ( ( STAR | SLASH | DIV | MOD | AND ) signedFactor )*
            loop47:
            do {
                int alt47=2;
                alt47 = dfa47.predict(input);
                switch (alt47) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:607:19: ( STAR | SLASH | DIV | MOD | AND ) signedFactor
            	    {
            	    // D:\\m\\antlr\\pascal\\pascal.g:607:19: ( STAR | SLASH | DIV | MOD | AND )
            	    int alt46=5;
            	    switch ( input.LA(1) ) {
            	    case STAR:
            	        {
            	        alt46=1;
            	        }
            	        break;
            	    case SLASH:
            	        {
            	        alt46=2;
            	        }
            	        break;
            	    case DIV:
            	        {
            	        alt46=3;
            	        }
            	        break;
            	    case MOD:
            	        {
            	        alt46=4;
            	        }
            	        break;
            	    case AND:
            	        {
            	        alt46=5;
            	        }
            	        break;
            	    default:
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 46, 0, input);

            	        throw nvae;
            	    }

            	    switch (alt46) {
            	        case 1 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:607:20: STAR
            	            {
            	            STAR240=(Token)match(input,STAR,FOLLOW_STAR_in_term2766); 
            	            STAR240_tree = (PascalAST)adaptor.create(STAR240);
            	            root_0 = (PascalAST)adaptor.becomeRoot(STAR240_tree, root_0);


            	            }
            	            break;
            	        case 2 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:607:28: SLASH
            	            {
            	            SLASH241=(Token)match(input,SLASH,FOLLOW_SLASH_in_term2771); 
            	            SLASH241_tree = (PascalAST)adaptor.create(SLASH241);
            	            root_0 = (PascalAST)adaptor.becomeRoot(SLASH241_tree, root_0);


            	            }
            	            break;
            	        case 3 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:607:37: DIV
            	            {
            	            DIV242=(Token)match(input,DIV,FOLLOW_DIV_in_term2776); 
            	            DIV242_tree = (PascalAST)adaptor.create(DIV242);
            	            root_0 = (PascalAST)adaptor.becomeRoot(DIV242_tree, root_0);


            	            }
            	            break;
            	        case 4 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:607:44: MOD
            	            {
            	            MOD243=(Token)match(input,MOD,FOLLOW_MOD_in_term2781); 
            	            MOD243_tree = (PascalAST)adaptor.create(MOD243);
            	            root_0 = (PascalAST)adaptor.becomeRoot(MOD243_tree, root_0);


            	            }
            	            break;
            	        case 5 :
            	            // D:\\m\\antlr\\pascal\\pascal.g:607:51: AND
            	            {
            	            AND244=(Token)match(input,AND,FOLLOW_AND_in_term2786); 
            	            AND244_tree = (PascalAST)adaptor.create(AND244);
            	            root_0 = (PascalAST)adaptor.becomeRoot(AND244_tree, root_0);


            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_signedFactor_in_term2790);
            	    signedFactor245=signedFactor();

            	    state._fsp--;

            	    adaptor.addChild(root_0, signedFactor245.getTree());

            	    }
            	    break;

            	default :
            	    break loop47;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "term"

    public static class signedFactor_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "signedFactor"
    // D:\\m\\antlr\\pascal\\pascal.g:610:1: signedFactor : ( PLUS | MINUS )? factor ;
    public final pascalParser.signedFactor_return signedFactor() throws RecognitionException {
        pascalParser.signedFactor_return retval = new pascalParser.signedFactor_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token PLUS246=null;
        Token MINUS247=null;
        pascalParser.factor_return factor248 = null;


        PascalAST PLUS246_tree=null;
        PascalAST MINUS247_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:611:5: ( ( PLUS | MINUS )? factor )
            // D:\\m\\antlr\\pascal\\pascal.g:611:7: ( PLUS | MINUS )? factor
            {
            root_0 = (PascalAST)adaptor.nil();

            // D:\\m\\antlr\\pascal\\pascal.g:611:7: ( PLUS | MINUS )?
            int alt48=3;
            alt48 = dfa48.predict(input);
            switch (alt48) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:611:8: PLUS
                    {
                    PLUS246=(Token)match(input,PLUS,FOLLOW_PLUS_in_signedFactor2811); 
                    PLUS246_tree = (PascalAST)adaptor.create(PLUS246);
                    root_0 = (PascalAST)adaptor.becomeRoot(PLUS246_tree, root_0);


                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:611:14: MINUS
                    {
                    MINUS247=(Token)match(input,MINUS,FOLLOW_MINUS_in_signedFactor2814); 
                    MINUS247_tree = (PascalAST)adaptor.create(MINUS247);
                    root_0 = (PascalAST)adaptor.becomeRoot(MINUS247_tree, root_0);


                    }
                    break;

            }

            pushFollow(FOLLOW_factor_in_signedFactor2819);
            factor248=factor();

            state._fsp--;

            adaptor.addChild(root_0, factor248.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "signedFactor"

    public static class factor_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "factor"
    // D:\\m\\antlr\\pascal\\pascal.g:614:1: factor : ( variable | LPAREN expression RPAREN | functionDesignator | unsignedConstant | set | NOT factor );
    public final pascalParser.factor_return factor() throws RecognitionException {
        pascalParser.factor_return retval = new pascalParser.factor_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token LPAREN250=null;
        Token RPAREN252=null;
        Token NOT256=null;
        pascalParser.variable_return variable249 = null;

        pascalParser.expression_return expression251 = null;

        pascalParser.functionDesignator_return functionDesignator253 = null;

        pascalParser.unsignedConstant_return unsignedConstant254 = null;

        pascalParser.set_return set255 = null;

        pascalParser.factor_return factor257 = null;


        PascalAST LPAREN250_tree=null;
        PascalAST RPAREN252_tree=null;
        PascalAST NOT256_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:615:5: ( variable | LPAREN expression RPAREN | functionDesignator | unsignedConstant | set | NOT factor )
            int alt49=6;
            alt49 = dfa49.predict(input);
            switch (alt49) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:615:7: variable
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_variable_in_factor2836);
                    variable249=variable();

                    state._fsp--;

                    adaptor.addChild(root_0, variable249.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:616:7: LPAREN expression RPAREN
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    LPAREN250=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_factor2844); 
                    pushFollow(FOLLOW_expression_in_factor2847);
                    expression251=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, expression251.getTree());
                    RPAREN252=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_factor2849); 

                    }
                    break;
                case 3 :
                    // D:\\m\\antlr\\pascal\\pascal.g:617:7: functionDesignator
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_functionDesignator_in_factor2858);
                    functionDesignator253=functionDesignator();

                    state._fsp--;

                    adaptor.addChild(root_0, functionDesignator253.getTree());

                    }
                    break;
                case 4 :
                    // D:\\m\\antlr\\pascal\\pascal.g:618:7: unsignedConstant
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_unsignedConstant_in_factor2866);
                    unsignedConstant254=unsignedConstant();

                    state._fsp--;

                    adaptor.addChild(root_0, unsignedConstant254.getTree());

                    }
                    break;
                case 5 :
                    // D:\\m\\antlr\\pascal\\pascal.g:619:7: set
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_set_in_factor2874);
                    set255=set();

                    state._fsp--;

                    adaptor.addChild(root_0, set255.getTree());

                    }
                    break;
                case 6 :
                    // D:\\m\\antlr\\pascal\\pascal.g:620:7: NOT factor
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    NOT256=(Token)match(input,NOT,FOLLOW_NOT_in_factor2882); 
                    NOT256_tree = (PascalAST)adaptor.create(NOT256);
                    root_0 = (PascalAST)adaptor.becomeRoot(NOT256_tree, root_0);

                    pushFollow(FOLLOW_factor_in_factor2885);
                    factor257=factor();

                    state._fsp--;

                    adaptor.addChild(root_0, factor257.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "factor"

    public static class unsignedConstant_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unsignedConstant"
    // D:\\m\\antlr\\pascal\\pascal.g:623:1: unsignedConstant : ( unsignedNumber | constantChr | string | NIL );
    public final pascalParser.unsignedConstant_return unsignedConstant() throws RecognitionException {
        pascalParser.unsignedConstant_return retval = new pascalParser.unsignedConstant_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token NIL261=null;
        pascalParser.unsignedNumber_return unsignedNumber258 = null;

        pascalParser.constantChr_return constantChr259 = null;

        pascalParser.string_return string260 = null;


        PascalAST NIL261_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:624:5: ( unsignedNumber | constantChr | string | NIL )
            int alt50=4;
            switch ( input.LA(1) ) {
            case NUM_REAL:
            case NUM_INT:
                {
                alt50=1;
                }
                break;
            case CHR:
                {
                alt50=2;
                }
                break;
            case STRING_LITERAL:
                {
                alt50=3;
                }
                break;
            case NIL:
                {
                alt50=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 50, 0, input);

                throw nvae;
            }

            switch (alt50) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:624:7: unsignedNumber
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_unsignedNumber_in_unsignedConstant2902);
                    unsignedNumber258=unsignedNumber();

                    state._fsp--;

                    adaptor.addChild(root_0, unsignedNumber258.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:625:7: constantChr
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_constantChr_in_unsignedConstant2910);
                    constantChr259=constantChr();

                    state._fsp--;

                    adaptor.addChild(root_0, constantChr259.getTree());

                    }
                    break;
                case 3 :
                    // D:\\m\\antlr\\pascal\\pascal.g:626:7: string
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_string_in_unsignedConstant2927);
                    string260=string();

                    state._fsp--;

                    adaptor.addChild(root_0, string260.getTree());

                    }
                    break;
                case 4 :
                    // D:\\m\\antlr\\pascal\\pascal.g:627:7: NIL
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    NIL261=(Token)match(input,NIL,FOLLOW_NIL_in_unsignedConstant2935); 
                    NIL261_tree = (PascalAST)adaptor.create(NIL261);
                    adaptor.addChild(root_0, NIL261_tree);


                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unsignedConstant"

    public static class functionDesignator_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "functionDesignator"
    // D:\\m\\antlr\\pascal\\pascal.g:630:1: functionDesignator : id= identifier LPAREN args= parameterList RPAREN -> ^( FUNC_CALL $id $args) ;
    public final pascalParser.functionDesignator_return functionDesignator() throws RecognitionException {
        pascalParser.functionDesignator_return retval = new pascalParser.functionDesignator_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token LPAREN262=null;
        Token RPAREN263=null;
        pascalParser.identifier_return id = null;

        pascalParser.parameterList_return args = null;


        PascalAST LPAREN262_tree=null;
        PascalAST RPAREN263_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_parameterList=new RewriteRuleSubtreeStream(adaptor,"rule parameterList");
        RewriteRuleSubtreeStream stream_identifier=new RewriteRuleSubtreeStream(adaptor,"rule identifier");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:631:5: (id= identifier LPAREN args= parameterList RPAREN -> ^( FUNC_CALL $id $args) )
            // D:\\m\\antlr\\pascal\\pascal.g:631:7: id= identifier LPAREN args= parameterList RPAREN
            {
            pushFollow(FOLLOW_identifier_in_functionDesignator2955);
            id=identifier();

            state._fsp--;

            stream_identifier.add(id.getTree());
            LPAREN262=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_functionDesignator2957);  
            stream_LPAREN.add(LPAREN262);

            pushFollow(FOLLOW_parameterList_in_functionDesignator2961);
            args=parameterList();

            state._fsp--;

            stream_parameterList.add(args.getTree());
            RPAREN263=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_functionDesignator2963);  
            stream_RPAREN.add(RPAREN263);



            // AST REWRITE
            // elements: args, id
            // token labels: 
            // rule labels: id, retval, args
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id",id!=null?id.tree:null);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_args=new RewriteRuleSubtreeStream(adaptor,"rule args",args!=null?args.tree:null);

            root_0 = (PascalAST)adaptor.nil();
            // 631:54: -> ^( FUNC_CALL $id $args)
            {
                // D:\\m\\antlr\\pascal\\pascal.g:631:57: ^( FUNC_CALL $id $args)
                {
                PascalAST root_1 = (PascalAST)adaptor.nil();
                root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(FUNC_CALL, "FUNC_CALL"), root_1);

                adaptor.addChild(root_1, stream_id.nextTree());
                adaptor.addChild(root_1, stream_args.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "functionDesignator"

    public static class parameterList_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "parameterList"
    // D:\\m\\antlr\\pascal\\pascal.g:635:1: parameterList : actualParameter ( COMMA actualParameter )* -> ^( ARGLIST ( actualParameter )+ ) ;
    public final pascalParser.parameterList_return parameterList() throws RecognitionException {
        pascalParser.parameterList_return retval = new pascalParser.parameterList_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token COMMA265=null;
        pascalParser.actualParameter_return actualParameter264 = null;

        pascalParser.actualParameter_return actualParameter266 = null;


        PascalAST COMMA265_tree=null;
        RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
        RewriteRuleSubtreeStream stream_actualParameter=new RewriteRuleSubtreeStream(adaptor,"rule actualParameter");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:636:5: ( actualParameter ( COMMA actualParameter )* -> ^( ARGLIST ( actualParameter )+ ) )
            // D:\\m\\antlr\\pascal\\pascal.g:636:7: actualParameter ( COMMA actualParameter )*
            {
            pushFollow(FOLLOW_actualParameter_in_parameterList2994);
            actualParameter264=actualParameter();

            state._fsp--;

            stream_actualParameter.add(actualParameter264.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:636:23: ( COMMA actualParameter )*
            loop51:
            do {
                int alt51=2;
                int LA51_0 = input.LA(1);

                if ( (LA51_0==COMMA) ) {
                    alt51=1;
                }


                switch (alt51) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:636:25: COMMA actualParameter
            	    {
            	    COMMA265=(Token)match(input,COMMA,FOLLOW_COMMA_in_parameterList2998);  
            	    stream_COMMA.add(COMMA265);

            	    pushFollow(FOLLOW_actualParameter_in_parameterList3000);
            	    actualParameter266=actualParameter();

            	    state._fsp--;

            	    stream_actualParameter.add(actualParameter266.getTree());

            	    }
            	    break;

            	default :
            	    break loop51;
                }
            } while (true);



            // AST REWRITE
            // elements: actualParameter
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (PascalAST)adaptor.nil();
            // 636:50: -> ^( ARGLIST ( actualParameter )+ )
            {
                // D:\\m\\antlr\\pascal\\pascal.g:636:53: ^( ARGLIST ( actualParameter )+ )
                {
                PascalAST root_1 = (PascalAST)adaptor.nil();
                root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(ARGLIST, "ARGLIST"), root_1);

                if ( !(stream_actualParameter.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_actualParameter.hasNext() ) {
                    adaptor.addChild(root_1, stream_actualParameter.nextTree());

                }
                stream_actualParameter.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "parameterList"

    public static class set_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "set"
    // D:\\m\\antlr\\pascal\\pascal.g:640:1: set : ( LBRACK elementList RBRACK -> ^( SET elementList ) | LBRACK2 elementList RBRACK2 -> ^( SET elementList ) );
    public final pascalParser.set_return set() throws RecognitionException {
        pascalParser.set_return retval = new pascalParser.set_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token LBRACK267=null;
        Token RBRACK269=null;
        Token LBRACK2270=null;
        Token RBRACK2272=null;
        pascalParser.elementList_return elementList268 = null;

        pascalParser.elementList_return elementList271 = null;


        PascalAST LBRACK267_tree=null;
        PascalAST RBRACK269_tree=null;
        PascalAST LBRACK2270_tree=null;
        PascalAST RBRACK2272_tree=null;
        RewriteRuleTokenStream stream_RBRACK=new RewriteRuleTokenStream(adaptor,"token RBRACK");
        RewriteRuleTokenStream stream_LBRACK=new RewriteRuleTokenStream(adaptor,"token LBRACK");
        RewriteRuleTokenStream stream_RBRACK2=new RewriteRuleTokenStream(adaptor,"token RBRACK2");
        RewriteRuleTokenStream stream_LBRACK2=new RewriteRuleTokenStream(adaptor,"token LBRACK2");
        RewriteRuleSubtreeStream stream_elementList=new RewriteRuleSubtreeStream(adaptor,"rule elementList");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:641:5: ( LBRACK elementList RBRACK -> ^( SET elementList ) | LBRACK2 elementList RBRACK2 -> ^( SET elementList ) )
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==LBRACK) ) {
                alt52=1;
            }
            else if ( (LA52_0==LBRACK2) ) {
                alt52=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 52, 0, input);

                throw nvae;
            }
            switch (alt52) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:641:7: LBRACK elementList RBRACK
                    {
                    LBRACK267=(Token)match(input,LBRACK,FOLLOW_LBRACK_in_set3031);  
                    stream_LBRACK.add(LBRACK267);

                    pushFollow(FOLLOW_elementList_in_set3033);
                    elementList268=elementList();

                    state._fsp--;

                    stream_elementList.add(elementList268.getTree());
                    RBRACK269=(Token)match(input,RBRACK,FOLLOW_RBRACK_in_set3035);  
                    stream_RBRACK.add(RBRACK269);



                    // AST REWRITE
                    // elements: elementList
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (PascalAST)adaptor.nil();
                    // 641:34: -> ^( SET elementList )
                    {
                        // D:\\m\\antlr\\pascal\\pascal.g:641:37: ^( SET elementList )
                        {
                        PascalAST root_1 = (PascalAST)adaptor.nil();
                        root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(SET, "SET"), root_1);

                        adaptor.addChild(root_1, stream_elementList.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:642:7: LBRACK2 elementList RBRACK2
                    {
                    LBRACK2270=(Token)match(input,LBRACK2,FOLLOW_LBRACK2_in_set3053);  
                    stream_LBRACK2.add(LBRACK2270);

                    pushFollow(FOLLOW_elementList_in_set3055);
                    elementList271=elementList();

                    state._fsp--;

                    stream_elementList.add(elementList271.getTree());
                    RBRACK2272=(Token)match(input,RBRACK2,FOLLOW_RBRACK2_in_set3057);  
                    stream_RBRACK2.add(RBRACK2272);



                    // AST REWRITE
                    // elements: elementList
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (PascalAST)adaptor.nil();
                    // 642:35: -> ^( SET elementList )
                    {
                        // D:\\m\\antlr\\pascal\\pascal.g:642:38: ^( SET elementList )
                        {
                        PascalAST root_1 = (PascalAST)adaptor.nil();
                        root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(SET, "SET"), root_1);

                        adaptor.addChild(root_1, stream_elementList.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "set"

    public static class elementList_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "elementList"
    // D:\\m\\antlr\\pascal\\pascal.g:645:1: elementList : ( element ( COMMA element )* | );
    public final pascalParser.elementList_return elementList() throws RecognitionException {
        pascalParser.elementList_return retval = new pascalParser.elementList_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token COMMA274=null;
        pascalParser.element_return element273 = null;

        pascalParser.element_return element275 = null;


        PascalAST COMMA274_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:646:5: ( element ( COMMA element )* | )
            int alt54=2;
            alt54 = dfa54.predict(input);
            switch (alt54) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:646:7: element ( COMMA element )*
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_element_in_elementList3084);
                    element273=element();

                    state._fsp--;

                    adaptor.addChild(root_0, element273.getTree());
                    // D:\\m\\antlr\\pascal\\pascal.g:646:15: ( COMMA element )*
                    loop53:
                    do {
                        int alt53=2;
                        int LA53_0 = input.LA(1);

                        if ( (LA53_0==COMMA) ) {
                            alt53=1;
                        }


                        switch (alt53) {
                    	case 1 :
                    	    // D:\\m\\antlr\\pascal\\pascal.g:646:17: COMMA element
                    	    {
                    	    COMMA274=(Token)match(input,COMMA,FOLLOW_COMMA_in_elementList3088); 
                    	    pushFollow(FOLLOW_element_in_elementList3091);
                    	    element275=element();

                    	    state._fsp--;

                    	    adaptor.addChild(root_0, element275.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop53;
                        }
                    } while (true);


                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:648:5: 
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "elementList"

    public static class element_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "element"
    // D:\\m\\antlr\\pascal\\pascal.g:650:1: element : expression ( DOTDOT expression )? ;
    public final pascalParser.element_return element() throws RecognitionException {
        pascalParser.element_return retval = new pascalParser.element_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token DOTDOT277=null;
        pascalParser.expression_return expression276 = null;

        pascalParser.expression_return expression278 = null;


        PascalAST DOTDOT277_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:651:5: ( expression ( DOTDOT expression )? )
            // D:\\m\\antlr\\pascal\\pascal.g:651:7: expression ( DOTDOT expression )?
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_expression_in_element3117);
            expression276=expression();

            state._fsp--;

            adaptor.addChild(root_0, expression276.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:651:18: ( DOTDOT expression )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==DOTDOT) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:651:20: DOTDOT expression
                    {
                    DOTDOT277=(Token)match(input,DOTDOT,FOLLOW_DOTDOT_in_element3121); 
                    DOTDOT277_tree = (PascalAST)adaptor.create(DOTDOT277);
                    root_0 = (PascalAST)adaptor.becomeRoot(DOTDOT277_tree, root_0);

                    pushFollow(FOLLOW_expression_in_element3124);
                    expression278=expression();

                    state._fsp--;

                    adaptor.addChild(root_0, expression278.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "element"

    public static class procedureStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "procedureStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:654:1: procedureStatement : id= identifier ( LPAREN args= parameterList RPAREN )? -> ^( PROC_CALL $id $args) ;
    public final pascalParser.procedureStatement_return procedureStatement() throws RecognitionException {
        pascalParser.procedureStatement_return retval = new pascalParser.procedureStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token LPAREN279=null;
        Token RPAREN280=null;
        pascalParser.identifier_return id = null;

        pascalParser.parameterList_return args = null;


        PascalAST LPAREN279_tree=null;
        PascalAST RPAREN280_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_parameterList=new RewriteRuleSubtreeStream(adaptor,"rule parameterList");
        RewriteRuleSubtreeStream stream_identifier=new RewriteRuleSubtreeStream(adaptor,"rule identifier");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:655:5: (id= identifier ( LPAREN args= parameterList RPAREN )? -> ^( PROC_CALL $id $args) )
            // D:\\m\\antlr\\pascal\\pascal.g:655:7: id= identifier ( LPAREN args= parameterList RPAREN )?
            {
            pushFollow(FOLLOW_identifier_in_procedureStatement3146);
            id=identifier();

            state._fsp--;

            stream_identifier.add(id.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:655:21: ( LPAREN args= parameterList RPAREN )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==LPAREN) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:655:23: LPAREN args= parameterList RPAREN
                    {
                    LPAREN279=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_procedureStatement3150);  
                    stream_LPAREN.add(LPAREN279);

                    pushFollow(FOLLOW_parameterList_in_procedureStatement3154);
                    args=parameterList();

                    state._fsp--;

                    stream_parameterList.add(args.getTree());
                    RPAREN280=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_procedureStatement3156);  
                    stream_RPAREN.add(RPAREN280);


                    }
                    break;

            }



            // AST REWRITE
            // elements: args, id
            // token labels: 
            // rule labels: id, retval, args
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_id=new RewriteRuleSubtreeStream(adaptor,"rule id",id!=null?id.tree:null);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);
            RewriteRuleSubtreeStream stream_args=new RewriteRuleSubtreeStream(adaptor,"rule args",args!=null?args.tree:null);

            root_0 = (PascalAST)adaptor.nil();
            // 655:59: -> ^( PROC_CALL $id $args)
            {
                // D:\\m\\antlr\\pascal\\pascal.g:655:62: ^( PROC_CALL $id $args)
                {
                PascalAST root_1 = (PascalAST)adaptor.nil();
                root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(PROC_CALL, "PROC_CALL"), root_1);

                adaptor.addChild(root_1, stream_id.nextTree());
                adaptor.addChild(root_1, stream_args.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "procedureStatement"

    public static class actualParameter_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "actualParameter"
    // D:\\m\\antlr\\pascal\\pascal.g:659:1: actualParameter : expression ;
    public final pascalParser.actualParameter_return actualParameter() throws RecognitionException {
        pascalParser.actualParameter_return retval = new pascalParser.actualParameter_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.expression_return expression281 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:660:5: ( expression )
            // D:\\m\\antlr\\pascal\\pascal.g:660:7: expression
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_expression_in_actualParameter3190);
            expression281=expression();

            state._fsp--;

            adaptor.addChild(root_0, expression281.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "actualParameter"

    public static class gotoStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "gotoStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:663:1: gotoStatement : GOTO label ;
    public final pascalParser.gotoStatement_return gotoStatement() throws RecognitionException {
        pascalParser.gotoStatement_return retval = new pascalParser.gotoStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token GOTO282=null;
        pascalParser.label_return label283 = null;


        PascalAST GOTO282_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:664:5: ( GOTO label )
            // D:\\m\\antlr\\pascal\\pascal.g:664:7: GOTO label
            {
            root_0 = (PascalAST)adaptor.nil();

            GOTO282=(Token)match(input,GOTO,FOLLOW_GOTO_in_gotoStatement3207); 
            GOTO282_tree = (PascalAST)adaptor.create(GOTO282);
            root_0 = (PascalAST)adaptor.becomeRoot(GOTO282_tree, root_0);

            pushFollow(FOLLOW_label_in_gotoStatement3210);
            label283=label();

            state._fsp--;

            adaptor.addChild(root_0, label283.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "gotoStatement"

    public static class emptyStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "emptyStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:667:1: emptyStatement : ;
    public final pascalParser.emptyStatement_return emptyStatement() throws RecognitionException {
        pascalParser.emptyStatement_return retval = new pascalParser.emptyStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:668:5: ()
            // D:\\m\\antlr\\pascal\\pascal.g:669:5: 
            {
            root_0 = (PascalAST)adaptor.nil();

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "emptyStatement"

    public static class empty_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "empty"
    // D:\\m\\antlr\\pascal\\pascal.g:671:1: empty : ;
    public final pascalParser.empty_return empty() throws RecognitionException {
        pascalParser.empty_return retval = new pascalParser.empty_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:672:5: ()
            // D:\\m\\antlr\\pascal\\pascal.g:673:5: 
            {
            root_0 = (PascalAST)adaptor.nil();

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "empty"

    public static class structuredStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "structuredStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:675:1: structuredStatement : ( compoundStatement | conditionalStatement | repetetiveStatement | withStatement );
    public final pascalParser.structuredStatement_return structuredStatement() throws RecognitionException {
        pascalParser.structuredStatement_return retval = new pascalParser.structuredStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.compoundStatement_return compoundStatement284 = null;

        pascalParser.conditionalStatement_return conditionalStatement285 = null;

        pascalParser.repetetiveStatement_return repetetiveStatement286 = null;

        pascalParser.withStatement_return withStatement287 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:676:5: ( compoundStatement | conditionalStatement | repetetiveStatement | withStatement )
            int alt57=4;
            switch ( input.LA(1) ) {
            case BEGIN:
                {
                alt57=1;
                }
                break;
            case CASE:
            case IF:
                {
                alt57=2;
                }
                break;
            case WHILE:
            case REPEAT:
            case FOR:
                {
                alt57=3;
                }
                break;
            case WITH:
                {
                alt57=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 57, 0, input);

                throw nvae;
            }

            switch (alt57) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:676:7: compoundStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_compoundStatement_in_structuredStatement3259);
                    compoundStatement284=compoundStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, compoundStatement284.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:677:7: conditionalStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_conditionalStatement_in_structuredStatement3267);
                    conditionalStatement285=conditionalStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, conditionalStatement285.getTree());

                    }
                    break;
                case 3 :
                    // D:\\m\\antlr\\pascal\\pascal.g:678:7: repetetiveStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_repetetiveStatement_in_structuredStatement3275);
                    repetetiveStatement286=repetetiveStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, repetetiveStatement286.getTree());

                    }
                    break;
                case 4 :
                    // D:\\m\\antlr\\pascal\\pascal.g:679:7: withStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_withStatement_in_structuredStatement3283);
                    withStatement287=withStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, withStatement287.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "structuredStatement"

    public static class compoundStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "compoundStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:682:1: compoundStatement : BEGIN statements END ;
    public final pascalParser.compoundStatement_return compoundStatement() throws RecognitionException {
        pascalParser.compoundStatement_return retval = new pascalParser.compoundStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token BEGIN288=null;
        Token END290=null;
        pascalParser.statements_return statements289 = null;


        PascalAST BEGIN288_tree=null;
        PascalAST END290_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:683:5: ( BEGIN statements END )
            // D:\\m\\antlr\\pascal\\pascal.g:683:7: BEGIN statements END
            {
            root_0 = (PascalAST)adaptor.nil();

            BEGIN288=(Token)match(input,BEGIN,FOLLOW_BEGIN_in_compoundStatement3300); 
            pushFollow(FOLLOW_statements_in_compoundStatement3305);
            statements289=statements();

            state._fsp--;

            adaptor.addChild(root_0, statements289.getTree());
            END290=(Token)match(input,END,FOLLOW_END_in_compoundStatement3313); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "compoundStatement"

    public static class statements_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "statements"
    // D:\\m\\antlr\\pascal\\pascal.g:688:1: statements : statement ( SEMI statement )* -> ^( BLOCK ( statement )+ ) ;
    public final pascalParser.statements_return statements() throws RecognitionException {
        pascalParser.statements_return retval = new pascalParser.statements_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token SEMI292=null;
        pascalParser.statement_return statement291 = null;

        pascalParser.statement_return statement293 = null;


        PascalAST SEMI292_tree=null;
        RewriteRuleTokenStream stream_SEMI=new RewriteRuleTokenStream(adaptor,"token SEMI");
        RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
        try {
            // D:\\m\\antlr\\pascal\\pascal.g:689:5: ( statement ( SEMI statement )* -> ^( BLOCK ( statement )+ ) )
            // D:\\m\\antlr\\pascal\\pascal.g:689:7: statement ( SEMI statement )*
            {
            pushFollow(FOLLOW_statement_in_statements3331);
            statement291=statement();

            state._fsp--;

            stream_statement.add(statement291.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:689:17: ( SEMI statement )*
            loop58:
            do {
                int alt58=2;
                int LA58_0 = input.LA(1);

                if ( (LA58_0==SEMI) ) {
                    alt58=1;
                }


                switch (alt58) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:689:19: SEMI statement
            	    {
            	    SEMI292=(Token)match(input,SEMI,FOLLOW_SEMI_in_statements3335);  
            	    stream_SEMI.add(SEMI292);

            	    pushFollow(FOLLOW_statement_in_statements3337);
            	    statement293=statement();

            	    state._fsp--;

            	    stream_statement.add(statement293.getTree());

            	    }
            	    break;

            	default :
            	    break loop58;
                }
            } while (true);



            // AST REWRITE
            // elements: statement
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (PascalAST)adaptor.nil();
            // 689:37: -> ^( BLOCK ( statement )+ )
            {
                // D:\\m\\antlr\\pascal\\pascal.g:689:40: ^( BLOCK ( statement )+ )
                {
                PascalAST root_1 = (PascalAST)adaptor.nil();
                root_1 = (PascalAST)adaptor.becomeRoot((PascalAST)adaptor.create(BLOCK, "BLOCK"), root_1);

                if ( !(stream_statement.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_statement.hasNext() ) {
                    adaptor.addChild(root_1, stream_statement.nextTree());

                }
                stream_statement.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "statements"

    public static class conditionalStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "conditionalStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:692:1: conditionalStatement : ( ifStatement | caseStatement );
    public final pascalParser.conditionalStatement_return conditionalStatement() throws RecognitionException {
        pascalParser.conditionalStatement_return retval = new pascalParser.conditionalStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.ifStatement_return ifStatement294 = null;

        pascalParser.caseStatement_return caseStatement295 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:693:5: ( ifStatement | caseStatement )
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==IF) ) {
                alt59=1;
            }
            else if ( (LA59_0==CASE) ) {
                alt59=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 59, 0, input);

                throw nvae;
            }
            switch (alt59) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:693:7: ifStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_ifStatement_in_conditionalStatement3368);
                    ifStatement294=ifStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, ifStatement294.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:694:7: caseStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_caseStatement_in_conditionalStatement3376);
                    caseStatement295=caseStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, caseStatement295.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "conditionalStatement"

    public static class ifStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "ifStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:697:1: ifStatement : IF expression THEN statement ( ELSE statement )? ;
    public final pascalParser.ifStatement_return ifStatement() throws RecognitionException {
        pascalParser.ifStatement_return retval = new pascalParser.ifStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token IF296=null;
        Token THEN298=null;
        Token ELSE300=null;
        pascalParser.expression_return expression297 = null;

        pascalParser.statement_return statement299 = null;

        pascalParser.statement_return statement301 = null;


        PascalAST IF296_tree=null;
        PascalAST THEN298_tree=null;
        PascalAST ELSE300_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:698:5: ( IF expression THEN statement ( ELSE statement )? )
            // D:\\m\\antlr\\pascal\\pascal.g:698:7: IF expression THEN statement ( ELSE statement )?
            {
            root_0 = (PascalAST)adaptor.nil();

            IF296=(Token)match(input,IF,FOLLOW_IF_in_ifStatement3393); 
            IF296_tree = (PascalAST)adaptor.create(IF296);
            root_0 = (PascalAST)adaptor.becomeRoot(IF296_tree, root_0);

            pushFollow(FOLLOW_expression_in_ifStatement3396);
            expression297=expression();

            state._fsp--;

            adaptor.addChild(root_0, expression297.getTree());
            THEN298=(Token)match(input,THEN,FOLLOW_THEN_in_ifStatement3398); 
            pushFollow(FOLLOW_statement_in_ifStatement3401);
            statement299=statement();

            state._fsp--;

            adaptor.addChild(root_0, statement299.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:699:7: ( ELSE statement )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==ELSE) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:706:5: ELSE statement
                    {
                    ELSE300=(Token)match(input,ELSE,FOLLOW_ELSE_in_ifStatement3428); 
                    pushFollow(FOLLOW_statement_in_ifStatement3431);
                    statement301=statement();

                    state._fsp--;

                    adaptor.addChild(root_0, statement301.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "ifStatement"

    public static class caseStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "caseStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:710:1: caseStatement : CASE expression OF caseListElement ( SEMI caseListElement )* ( SEMI ELSE statements )? END ;
    public final pascalParser.caseStatement_return caseStatement() throws RecognitionException {
        pascalParser.caseStatement_return retval = new pascalParser.caseStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token CASE302=null;
        Token OF304=null;
        Token SEMI306=null;
        Token SEMI308=null;
        Token ELSE309=null;
        Token END311=null;
        pascalParser.expression_return expression303 = null;

        pascalParser.caseListElement_return caseListElement305 = null;

        pascalParser.caseListElement_return caseListElement307 = null;

        pascalParser.statements_return statements310 = null;


        PascalAST CASE302_tree=null;
        PascalAST OF304_tree=null;
        PascalAST SEMI306_tree=null;
        PascalAST SEMI308_tree=null;
        PascalAST ELSE309_tree=null;
        PascalAST END311_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:711:5: ( CASE expression OF caseListElement ( SEMI caseListElement )* ( SEMI ELSE statements )? END )
            // D:\\m\\antlr\\pascal\\pascal.g:711:7: CASE expression OF caseListElement ( SEMI caseListElement )* ( SEMI ELSE statements )? END
            {
            root_0 = (PascalAST)adaptor.nil();

            CASE302=(Token)match(input,CASE,FOLLOW_CASE_in_caseStatement3455); 
            CASE302_tree = (PascalAST)adaptor.create(CASE302);
            root_0 = (PascalAST)adaptor.becomeRoot(CASE302_tree, root_0);

            pushFollow(FOLLOW_expression_in_caseStatement3458);
            expression303=expression();

            state._fsp--;

            adaptor.addChild(root_0, expression303.getTree());
            OF304=(Token)match(input,OF,FOLLOW_OF_in_caseStatement3460); 
            pushFollow(FOLLOW_caseListElement_in_caseStatement3471);
            caseListElement305=caseListElement();

            state._fsp--;

            adaptor.addChild(root_0, caseListElement305.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:712:25: ( SEMI caseListElement )*
            loop61:
            do {
                int alt61=2;
                alt61 = dfa61.predict(input);
                switch (alt61) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:712:27: SEMI caseListElement
            	    {
            	    SEMI306=(Token)match(input,SEMI,FOLLOW_SEMI_in_caseStatement3475); 
            	    pushFollow(FOLLOW_caseListElement_in_caseStatement3478);
            	    caseListElement307=caseListElement();

            	    state._fsp--;

            	    adaptor.addChild(root_0, caseListElement307.getTree());

            	    }
            	    break;

            	default :
            	    break loop61;
                }
            } while (true);

            // D:\\m\\antlr\\pascal\\pascal.g:713:7: ( SEMI ELSE statements )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==SEMI) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:713:9: SEMI ELSE statements
                    {
                    SEMI308=(Token)match(input,SEMI,FOLLOW_SEMI_in_caseStatement3491); 
                    ELSE309=(Token)match(input,ELSE,FOLLOW_ELSE_in_caseStatement3494); 
                    pushFollow(FOLLOW_statements_in_caseStatement3497);
                    statements310=statements();

                    state._fsp--;

                    adaptor.addChild(root_0, statements310.getTree());

                    }
                    break;

            }

            END311=(Token)match(input,END,FOLLOW_END_in_caseStatement3508); 

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "caseStatement"

    public static class caseListElement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "caseListElement"
    // D:\\m\\antlr\\pascal\\pascal.g:717:1: caseListElement : constList COLON statement ;
    public final pascalParser.caseListElement_return caseListElement() throws RecognitionException {
        pascalParser.caseListElement_return retval = new pascalParser.caseListElement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token COLON313=null;
        pascalParser.constList_return constList312 = null;

        pascalParser.statement_return statement314 = null;


        PascalAST COLON313_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:718:5: ( constList COLON statement )
            // D:\\m\\antlr\\pascal\\pascal.g:718:7: constList COLON statement
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_constList_in_caseListElement3526);
            constList312=constList();

            state._fsp--;

            adaptor.addChild(root_0, constList312.getTree());
            COLON313=(Token)match(input,COLON,FOLLOW_COLON_in_caseListElement3528); 
            COLON313_tree = (PascalAST)adaptor.create(COLON313);
            root_0 = (PascalAST)adaptor.becomeRoot(COLON313_tree, root_0);

            pushFollow(FOLLOW_statement_in_caseListElement3531);
            statement314=statement();

            state._fsp--;

            adaptor.addChild(root_0, statement314.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "caseListElement"

    public static class repetetiveStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "repetetiveStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:721:1: repetetiveStatement : ( whileStatement | repeatStatement | forStatement );
    public final pascalParser.repetetiveStatement_return repetetiveStatement() throws RecognitionException {
        pascalParser.repetetiveStatement_return retval = new pascalParser.repetetiveStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.whileStatement_return whileStatement315 = null;

        pascalParser.repeatStatement_return repeatStatement316 = null;

        pascalParser.forStatement_return forStatement317 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:722:5: ( whileStatement | repeatStatement | forStatement )
            int alt63=3;
            switch ( input.LA(1) ) {
            case WHILE:
                {
                alt63=1;
                }
                break;
            case REPEAT:
                {
                alt63=2;
                }
                break;
            case FOR:
                {
                alt63=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 63, 0, input);

                throw nvae;
            }

            switch (alt63) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:722:7: whileStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_whileStatement_in_repetetiveStatement3548);
                    whileStatement315=whileStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, whileStatement315.getTree());

                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:723:7: repeatStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_repeatStatement_in_repetetiveStatement3556);
                    repeatStatement316=repeatStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, repeatStatement316.getTree());

                    }
                    break;
                case 3 :
                    // D:\\m\\antlr\\pascal\\pascal.g:724:7: forStatement
                    {
                    root_0 = (PascalAST)adaptor.nil();

                    pushFollow(FOLLOW_forStatement_in_repetetiveStatement3564);
                    forStatement317=forStatement();

                    state._fsp--;

                    adaptor.addChild(root_0, forStatement317.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "repetetiveStatement"

    public static class whileStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "whileStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:727:1: whileStatement : WHILE expression DO statement ;
    public final pascalParser.whileStatement_return whileStatement() throws RecognitionException {
        pascalParser.whileStatement_return retval = new pascalParser.whileStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token WHILE318=null;
        Token DO320=null;
        pascalParser.expression_return expression319 = null;

        pascalParser.statement_return statement321 = null;


        PascalAST WHILE318_tree=null;
        PascalAST DO320_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:728:5: ( WHILE expression DO statement )
            // D:\\m\\antlr\\pascal\\pascal.g:728:7: WHILE expression DO statement
            {
            root_0 = (PascalAST)adaptor.nil();

            WHILE318=(Token)match(input,WHILE,FOLLOW_WHILE_in_whileStatement3581); 
            WHILE318_tree = (PascalAST)adaptor.create(WHILE318);
            root_0 = (PascalAST)adaptor.becomeRoot(WHILE318_tree, root_0);

            pushFollow(FOLLOW_expression_in_whileStatement3584);
            expression319=expression();

            state._fsp--;

            adaptor.addChild(root_0, expression319.getTree());
            DO320=(Token)match(input,DO,FOLLOW_DO_in_whileStatement3586); 
            pushFollow(FOLLOW_statement_in_whileStatement3589);
            statement321=statement();

            state._fsp--;

            adaptor.addChild(root_0, statement321.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "whileStatement"

    public static class repeatStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "repeatStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:731:1: repeatStatement : REPEAT statements UNTIL expression ;
    public final pascalParser.repeatStatement_return repeatStatement() throws RecognitionException {
        pascalParser.repeatStatement_return retval = new pascalParser.repeatStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token REPEAT322=null;
        Token UNTIL324=null;
        pascalParser.statements_return statements323 = null;

        pascalParser.expression_return expression325 = null;


        PascalAST REPEAT322_tree=null;
        PascalAST UNTIL324_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:732:5: ( REPEAT statements UNTIL expression )
            // D:\\m\\antlr\\pascal\\pascal.g:732:7: REPEAT statements UNTIL expression
            {
            root_0 = (PascalAST)adaptor.nil();

            REPEAT322=(Token)match(input,REPEAT,FOLLOW_REPEAT_in_repeatStatement3606); 
            REPEAT322_tree = (PascalAST)adaptor.create(REPEAT322);
            root_0 = (PascalAST)adaptor.becomeRoot(REPEAT322_tree, root_0);

            pushFollow(FOLLOW_statements_in_repeatStatement3609);
            statements323=statements();

            state._fsp--;

            adaptor.addChild(root_0, statements323.getTree());
            UNTIL324=(Token)match(input,UNTIL,FOLLOW_UNTIL_in_repeatStatement3611); 
            pushFollow(FOLLOW_expression_in_repeatStatement3614);
            expression325=expression();

            state._fsp--;

            adaptor.addChild(root_0, expression325.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "repeatStatement"

    public static class forStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "forStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:735:1: forStatement : FOR identifier ASSIGN forList DO statement ;
    public final pascalParser.forStatement_return forStatement() throws RecognitionException {
        pascalParser.forStatement_return retval = new pascalParser.forStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token FOR326=null;
        Token ASSIGN328=null;
        Token DO330=null;
        pascalParser.identifier_return identifier327 = null;

        pascalParser.forList_return forList329 = null;

        pascalParser.statement_return statement331 = null;


        PascalAST FOR326_tree=null;
        PascalAST ASSIGN328_tree=null;
        PascalAST DO330_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:736:5: ( FOR identifier ASSIGN forList DO statement )
            // D:\\m\\antlr\\pascal\\pascal.g:736:7: FOR identifier ASSIGN forList DO statement
            {
            root_0 = (PascalAST)adaptor.nil();

            FOR326=(Token)match(input,FOR,FOLLOW_FOR_in_forStatement3631); 
            FOR326_tree = (PascalAST)adaptor.create(FOR326);
            root_0 = (PascalAST)adaptor.becomeRoot(FOR326_tree, root_0);

            pushFollow(FOLLOW_identifier_in_forStatement3634);
            identifier327=identifier();

            state._fsp--;

            adaptor.addChild(root_0, identifier327.getTree());
            ASSIGN328=(Token)match(input,ASSIGN,FOLLOW_ASSIGN_in_forStatement3636); 
            pushFollow(FOLLOW_forList_in_forStatement3639);
            forList329=forList();

            state._fsp--;

            adaptor.addChild(root_0, forList329.getTree());
            DO330=(Token)match(input,DO,FOLLOW_DO_in_forStatement3641); 
            pushFollow(FOLLOW_statement_in_forStatement3644);
            statement331=statement();

            state._fsp--;

            adaptor.addChild(root_0, statement331.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "forStatement"

    public static class forList_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "forList"
    // D:\\m\\antlr\\pascal\\pascal.g:739:1: forList : initialValue ( TO | DOWNTO ) finalValue ;
    public final pascalParser.forList_return forList() throws RecognitionException {
        pascalParser.forList_return retval = new pascalParser.forList_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token TO333=null;
        Token DOWNTO334=null;
        pascalParser.initialValue_return initialValue332 = null;

        pascalParser.finalValue_return finalValue335 = null;


        PascalAST TO333_tree=null;
        PascalAST DOWNTO334_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:740:5: ( initialValue ( TO | DOWNTO ) finalValue )
            // D:\\m\\antlr\\pascal\\pascal.g:740:7: initialValue ( TO | DOWNTO ) finalValue
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_initialValue_in_forList3661);
            initialValue332=initialValue();

            state._fsp--;

            adaptor.addChild(root_0, initialValue332.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:740:20: ( TO | DOWNTO )
            int alt64=2;
            int LA64_0 = input.LA(1);

            if ( (LA64_0==TO) ) {
                alt64=1;
            }
            else if ( (LA64_0==DOWNTO) ) {
                alt64=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 64, 0, input);

                throw nvae;
            }
            switch (alt64) {
                case 1 :
                    // D:\\m\\antlr\\pascal\\pascal.g:740:21: TO
                    {
                    TO333=(Token)match(input,TO,FOLLOW_TO_in_forList3664); 
                    TO333_tree = (PascalAST)adaptor.create(TO333);
                    root_0 = (PascalAST)adaptor.becomeRoot(TO333_tree, root_0);


                    }
                    break;
                case 2 :
                    // D:\\m\\antlr\\pascal\\pascal.g:740:27: DOWNTO
                    {
                    DOWNTO334=(Token)match(input,DOWNTO,FOLLOW_DOWNTO_in_forList3669); 
                    DOWNTO334_tree = (PascalAST)adaptor.create(DOWNTO334);
                    root_0 = (PascalAST)adaptor.becomeRoot(DOWNTO334_tree, root_0);


                    }
                    break;

            }

            pushFollow(FOLLOW_finalValue_in_forList3673);
            finalValue335=finalValue();

            state._fsp--;

            adaptor.addChild(root_0, finalValue335.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "forList"

    public static class initialValue_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "initialValue"
    // D:\\m\\antlr\\pascal\\pascal.g:743:1: initialValue : expression ;
    public final pascalParser.initialValue_return initialValue() throws RecognitionException {
        pascalParser.initialValue_return retval = new pascalParser.initialValue_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.expression_return expression336 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:744:5: ( expression )
            // D:\\m\\antlr\\pascal\\pascal.g:744:7: expression
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_expression_in_initialValue3690);
            expression336=expression();

            state._fsp--;

            adaptor.addChild(root_0, expression336.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "initialValue"

    public static class finalValue_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "finalValue"
    // D:\\m\\antlr\\pascal\\pascal.g:747:1: finalValue : expression ;
    public final pascalParser.finalValue_return finalValue() throws RecognitionException {
        pascalParser.finalValue_return retval = new pascalParser.finalValue_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        pascalParser.expression_return expression337 = null;



        try {
            // D:\\m\\antlr\\pascal\\pascal.g:748:5: ( expression )
            // D:\\m\\antlr\\pascal\\pascal.g:748:7: expression
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_expression_in_finalValue3707);
            expression337=expression();

            state._fsp--;

            adaptor.addChild(root_0, expression337.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "finalValue"

    public static class withStatement_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "withStatement"
    // D:\\m\\antlr\\pascal\\pascal.g:751:1: withStatement : WITH recordVariableList DO statement ;
    public final pascalParser.withStatement_return withStatement() throws RecognitionException {
        pascalParser.withStatement_return retval = new pascalParser.withStatement_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token WITH338=null;
        Token DO340=null;
        pascalParser.recordVariableList_return recordVariableList339 = null;

        pascalParser.statement_return statement341 = null;


        PascalAST WITH338_tree=null;
        PascalAST DO340_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:752:5: ( WITH recordVariableList DO statement )
            // D:\\m\\antlr\\pascal\\pascal.g:752:7: WITH recordVariableList DO statement
            {
            root_0 = (PascalAST)adaptor.nil();

            WITH338=(Token)match(input,WITH,FOLLOW_WITH_in_withStatement3724); 
            WITH338_tree = (PascalAST)adaptor.create(WITH338);
            root_0 = (PascalAST)adaptor.becomeRoot(WITH338_tree, root_0);

            pushFollow(FOLLOW_recordVariableList_in_withStatement3727);
            recordVariableList339=recordVariableList();

            state._fsp--;

            adaptor.addChild(root_0, recordVariableList339.getTree());
            DO340=(Token)match(input,DO,FOLLOW_DO_in_withStatement3729); 
            pushFollow(FOLLOW_statement_in_withStatement3732);
            statement341=statement();

            state._fsp--;

            adaptor.addChild(root_0, statement341.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "withStatement"

    public static class recordVariableList_return extends ParserRuleReturnScope {
        PascalAST tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "recordVariableList"
    // D:\\m\\antlr\\pascal\\pascal.g:755:1: recordVariableList : variable ( COMMA variable )* ;
    public final pascalParser.recordVariableList_return recordVariableList() throws RecognitionException {
        pascalParser.recordVariableList_return retval = new pascalParser.recordVariableList_return();
        retval.start = input.LT(1);

        PascalAST root_0 = null;

        Token COMMA343=null;
        pascalParser.variable_return variable342 = null;

        pascalParser.variable_return variable344 = null;


        PascalAST COMMA343_tree=null;

        try {
            // D:\\m\\antlr\\pascal\\pascal.g:756:5: ( variable ( COMMA variable )* )
            // D:\\m\\antlr\\pascal\\pascal.g:756:7: variable ( COMMA variable )*
            {
            root_0 = (PascalAST)adaptor.nil();

            pushFollow(FOLLOW_variable_in_recordVariableList3749);
            variable342=variable();

            state._fsp--;

            adaptor.addChild(root_0, variable342.getTree());
            // D:\\m\\antlr\\pascal\\pascal.g:756:16: ( COMMA variable )*
            loop65:
            do {
                int alt65=2;
                int LA65_0 = input.LA(1);

                if ( (LA65_0==COMMA) ) {
                    alt65=1;
                }


                switch (alt65) {
            	case 1 :
            	    // D:\\m\\antlr\\pascal\\pascal.g:756:18: COMMA variable
            	    {
            	    COMMA343=(Token)match(input,COMMA,FOLLOW_COMMA_in_recordVariableList3753); 
            	    pushFollow(FOLLOW_variable_in_recordVariableList3756);
            	    variable344=variable();

            	    state._fsp--;

            	    adaptor.addChild(root_0, variable344.getTree());

            	    }
            	    break;

            	default :
            	    break loop65;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (PascalAST)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (PascalAST)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "recordVariableList"

    // Delegated rules


    protected DFA1 dfa1 = new DFA1(this);
    protected DFA4 dfa4 = new DFA4(this);
    protected DFA6 dfa6 = new DFA6(this);
    protected DFA7 dfa7 = new DFA7(this);
    protected DFA9 dfa9 = new DFA9(this);
    protected DFA10 dfa10 = new DFA10(this);
    protected DFA13 dfa13 = new DFA13(this);
    protected DFA14 dfa14 = new DFA14(this);
    protected DFA24 dfa24 = new DFA24(this);
    protected DFA27 dfa27 = new DFA27(this);
    protected DFA35 dfa35 = new DFA35(this);
    protected DFA36 dfa36 = new DFA36(this);
    protected DFA37 dfa37 = new DFA37(this);
    protected DFA41 dfa41 = new DFA41(this);
    protected DFA43 dfa43 = new DFA43(this);
    protected DFA45 dfa45 = new DFA45(this);
    protected DFA47 dfa47 = new DFA47(this);
    protected DFA48 dfa48 = new DFA48(this);
    protected DFA49 dfa49 = new DFA49(this);
    protected DFA54 dfa54 = new DFA54(this);
    protected DFA61 dfa61 = new DFA61(this);
    static final String DFA1_eotS =
        "\13\uffff";
    static final String DFA1_eofS =
        "\13\uffff";
    static final String DFA1_minS =
        "\1\37\12\uffff";
    static final String DFA1_maxS =
        "\1\133\12\uffff";
    static final String DFA1_acceptS =
        "\1\uffff\1\1\1\2\10\uffff";
    static final String DFA1_specialS =
        "\13\uffff}>";
    static final String[] DFA1_transitionS = {
            "\1\1\7\uffff\3\2\1\uffff\1\2\6\uffff\2\2\1\uffff\1\2\23\uffff"+
            "\1\2\21\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA1_eot = DFA.unpackEncodedString(DFA1_eotS);
    static final short[] DFA1_eof = DFA.unpackEncodedString(DFA1_eofS);
    static final char[] DFA1_min = DFA.unpackEncodedStringToUnsignedChars(DFA1_minS);
    static final char[] DFA1_max = DFA.unpackEncodedStringToUnsignedChars(DFA1_maxS);
    static final short[] DFA1_accept = DFA.unpackEncodedString(DFA1_acceptS);
    static final short[] DFA1_special = DFA.unpackEncodedString(DFA1_specialS);
    static final short[][] DFA1_transition;

    static {
        int numStates = DFA1_transitionS.length;
        DFA1_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA1_transition[i] = DFA.unpackEncodedString(DFA1_transitionS[i]);
        }
    }

    class DFA1 extends DFA {

        public DFA1(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 1;
            this.eot = DFA1_eot;
            this.eof = DFA1_eof;
            this.min = DFA1_min;
            this.max = DFA1_max;
            this.accept = DFA1_accept;
            this.special = DFA1_special;
            this.transition = DFA1_transition;
        }
        public String getDescription() {
            return "271:22: ( INTERFACE )?";
        }
    }
    static final String DFA4_eotS =
        "\12\uffff";
    static final String DFA4_eofS =
        "\12\uffff";
    static final String DFA4_minS =
        "\1\47\11\uffff";
    static final String DFA4_maxS =
        "\1\133\11\uffff";
    static final String DFA4_acceptS =
        "\1\uffff\1\10\1\1\1\2\1\3\1\4\1\5\1\uffff\1\6\1\7";
    static final String DFA4_specialS =
        "\12\uffff}>";
    static final String[] DFA4_transitionS = {
            "\1\11\1\10\1\2\1\uffff\1\3\6\uffff\1\4\1\6\1\uffff\1\6\23\uffff"+
            "\1\5\21\uffff\1\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA4_eot = DFA.unpackEncodedString(DFA4_eotS);
    static final short[] DFA4_eof = DFA.unpackEncodedString(DFA4_eofS);
    static final char[] DFA4_min = DFA.unpackEncodedStringToUnsignedChars(DFA4_minS);
    static final char[] DFA4_max = DFA.unpackEncodedStringToUnsignedChars(DFA4_maxS);
    static final short[] DFA4_accept = DFA.unpackEncodedString(DFA4_acceptS);
    static final short[] DFA4_special = DFA.unpackEncodedString(DFA4_specialS);
    static final short[][] DFA4_transition;

    static {
        int numStates = DFA4_transitionS.length;
        DFA4_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA4_transition[i] = DFA.unpackEncodedString(DFA4_transitionS[i]);
        }
    }

    class DFA4 extends DFA {

        public DFA4(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 4;
            this.eot = DFA4_eot;
            this.eof = DFA4_eof;
            this.min = DFA4_min;
            this.max = DFA4_max;
            this.accept = DFA4_accept;
            this.special = DFA4_special;
            this.transition = DFA4_transition;
        }
        public String getDescription() {
            return "()* loopback of 286:7: ( labelDeclarationPart | constantDefinitionPart | typeDefinitionPart | variableDeclarationPart | procedureAndFunctionDeclarationPart | usesUnitsPart | IMPLEMENTATION )*";
        }
    }
    static final String DFA6_eotS =
        "\14\uffff";
    static final String DFA6_eofS =
        "\14\uffff";
    static final String DFA6_minS =
        "\1\44\1\46\12\uffff";
    static final String DFA6_maxS =
        "\1\44\1\133\12\uffff";
    static final String DFA6_acceptS =
        "\2\uffff\1\2\10\uffff\1\1";
    static final String DFA6_specialS =
        "\14\uffff}>";
    static final String[] DFA6_transitionS = {
            "\1\1",
            "\1\13\3\2\1\uffff\1\2\6\uffff\2\2\1\uffff\1\2\23\uffff\1\2"+
            "\21\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA6_eot = DFA.unpackEncodedString(DFA6_eotS);
    static final short[] DFA6_eof = DFA.unpackEncodedString(DFA6_eofS);
    static final char[] DFA6_min = DFA.unpackEncodedStringToUnsignedChars(DFA6_minS);
    static final char[] DFA6_max = DFA.unpackEncodedStringToUnsignedChars(DFA6_maxS);
    static final short[] DFA6_accept = DFA.unpackEncodedString(DFA6_acceptS);
    static final short[] DFA6_special = DFA.unpackEncodedString(DFA6_specialS);
    static final short[][] DFA6_transition;

    static {
        int numStates = DFA6_transitionS.length;
        DFA6_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA6_transition[i] = DFA.unpackEncodedString(DFA6_transitionS[i]);
        }
    }

    class DFA6 extends DFA {

        public DFA6(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 6;
            this.eot = DFA6_eot;
            this.eof = DFA6_eof;
            this.min = DFA6_min;
            this.max = DFA6_max;
            this.accept = DFA6_accept;
            this.special = DFA6_special;
            this.transition = DFA6_transition;
        }
        public String getDescription() {
            return "()* loopback of 310:33: ( SEMI constantDefinition )*";
        }
    }
    static final String DFA7_eotS =
        "\12\uffff";
    static final String DFA7_eofS =
        "\12\uffff";
    static final String DFA7_minS =
        "\1\36\2\uffff\1\36\6\uffff";
    static final String DFA7_maxS =
        "\1\61\2\uffff\1\56\6\uffff";
    static final String DFA7_acceptS =
        "\1\uffff\1\1\2\uffff\1\3\1\5\1\6\1\4\1\2\1\uffff";
    static final String DFA7_specialS =
        "\12\uffff}>";
    static final String[] DFA7_transitionS = {
            "\1\1\7\uffff\1\4\6\uffff\1\6\1\1\2\3\1\5",
            "",
            "",
            "\1\10\7\uffff\1\7\7\uffff\1\10",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA7_eot = DFA.unpackEncodedString(DFA7_eotS);
    static final short[] DFA7_eof = DFA.unpackEncodedString(DFA7_eofS);
    static final char[] DFA7_min = DFA.unpackEncodedStringToUnsignedChars(DFA7_minS);
    static final char[] DFA7_max = DFA.unpackEncodedStringToUnsignedChars(DFA7_maxS);
    static final short[] DFA7_accept = DFA.unpackEncodedString(DFA7_acceptS);
    static final short[] DFA7_special = DFA.unpackEncodedString(DFA7_specialS);
    static final short[][] DFA7_transition;

    static {
        int numStates = DFA7_transitionS.length;
        DFA7_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA7_transition[i] = DFA.unpackEncodedString(DFA7_transitionS[i]);
        }
    }

    class DFA7 extends DFA {

        public DFA7(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 7;
            this.eot = DFA7_eot;
            this.eof = DFA7_eof;
            this.min = DFA7_min;
            this.max = DFA7_max;
            this.accept = DFA7_accept;
            this.special = DFA7_special;
            this.transition = DFA7_transition;
        }
        public String getDescription() {
            return "321:1: constant : ( unsignedNumber | s= sign n= unsignedNumber -> ^( $s $n) | identifier | s2= sign id= identifier -> ^( $s2 $id) | string | constantChr );";
        }
    }
    static final String DFA9_eotS =
        "\14\uffff";
    static final String DFA9_eofS =
        "\14\uffff";
    static final String DFA9_minS =
        "\1\44\1\46\12\uffff";
    static final String DFA9_maxS =
        "\1\44\1\133\12\uffff";
    static final String DFA9_acceptS =
        "\2\uffff\1\1\1\2\10\uffff";
    static final String DFA9_specialS =
        "\14\uffff}>";
    static final String[] DFA9_transitionS = {
            "\1\1",
            "\1\2\3\3\1\uffff\1\3\6\uffff\2\3\1\uffff\1\3\23\uffff\1\3"+
            "\21\uffff\1\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA9_eot = DFA.unpackEncodedString(DFA9_eotS);
    static final short[] DFA9_eof = DFA.unpackEncodedString(DFA9_eofS);
    static final char[] DFA9_min = DFA.unpackEncodedStringToUnsignedChars(DFA9_minS);
    static final char[] DFA9_max = DFA.unpackEncodedStringToUnsignedChars(DFA9_maxS);
    static final short[] DFA9_accept = DFA.unpackEncodedString(DFA9_acceptS);
    static final short[] DFA9_special = DFA.unpackEncodedString(DFA9_specialS);
    static final short[][] DFA9_transition;

    static {
        int numStates = DFA9_transitionS.length;
        DFA9_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA9_transition[i] = DFA.unpackEncodedString(DFA9_transitionS[i]);
        }
    }

    class DFA9 extends DFA {

        public DFA9(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 9;
            this.eot = DFA9_eot;
            this.eof = DFA9_eof;
            this.min = DFA9_min;
            this.max = DFA9_max;
            this.accept = DFA9_accept;
            this.special = DFA9_special;
            this.transition = DFA9_transition;
        }
        public String getDescription() {
            return "()* loopback of 353:28: ( SEMI typeDefinition )*";
        }
    }
    static final String DFA10_eotS =
        "\25\uffff";
    static final String DFA10_eofS =
        "\25\uffff";
    static final String DFA10_minS =
        "\1\36\24\uffff";
    static final String DFA10_maxS =
        "\1\110\24\uffff";
    static final String DFA10_acceptS =
        "\1\uffff\1\1\21\uffff\1\2\1\3";
    static final String DFA10_specialS =
        "\25\uffff}>";
    static final String[] DFA10_transitionS = {
            "\1\1\3\uffff\1\1\3\uffff\1\1\6\uffff\5\1\1\uffff\1\23\1\uffff"+
            "\1\24\1\uffff\6\1\2\uffff\1\1\3\uffff\1\1\2\uffff\3\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA10_eot = DFA.unpackEncodedString(DFA10_eotS);
    static final short[] DFA10_eof = DFA.unpackEncodedString(DFA10_eofS);
    static final char[] DFA10_min = DFA.unpackEncodedStringToUnsignedChars(DFA10_minS);
    static final char[] DFA10_max = DFA.unpackEncodedStringToUnsignedChars(DFA10_maxS);
    static final short[] DFA10_accept = DFA.unpackEncodedString(DFA10_acceptS);
    static final short[] DFA10_special = DFA.unpackEncodedString(DFA10_specialS);
    static final short[][] DFA10_transition;

    static {
        int numStates = DFA10_transitionS.length;
        DFA10_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA10_transition[i] = DFA.unpackEncodedString(DFA10_transitionS[i]);
        }
    }

    class DFA10 extends DFA {

        public DFA10(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 10;
            this.eot = DFA10_eot;
            this.eof = DFA10_eof;
            this.min = DFA10_min;
            this.max = DFA10_max;
            this.accept = DFA10_accept;
            this.special = DFA10_special;
            this.transition = DFA10_transition;
        }
        public String getDescription() {
            return "359:7: ( type | functionType | procedureType )";
        }
    }
    static final String DFA13_eotS =
        "\23\uffff";
    static final String DFA13_eofS =
        "\23\uffff";
    static final String DFA13_minS =
        "\1\36\22\uffff";
    static final String DFA13_maxS =
        "\1\110\22\uffff";
    static final String DFA13_acceptS =
        "\1\uffff\1\1\13\uffff\1\2\4\uffff\1\3";
    static final String DFA13_specialS =
        "\23\uffff}>";
    static final String[] DFA13_transitionS = {
            "\1\1\3\uffff\1\1\3\uffff\1\1\6\uffff\5\1\5\uffff\5\1\1\15\2"+
            "\uffff\1\15\3\uffff\1\15\2\uffff\2\15\1\22",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA13_eot = DFA.unpackEncodedString(DFA13_eotS);
    static final short[] DFA13_eof = DFA.unpackEncodedString(DFA13_eofS);
    static final char[] DFA13_min = DFA.unpackEncodedStringToUnsignedChars(DFA13_minS);
    static final char[] DFA13_max = DFA.unpackEncodedStringToUnsignedChars(DFA13_maxS);
    static final short[] DFA13_accept = DFA.unpackEncodedString(DFA13_acceptS);
    static final short[] DFA13_special = DFA.unpackEncodedString(DFA13_specialS);
    static final short[][] DFA13_transition;

    static {
        int numStates = DFA13_transitionS.length;
        DFA13_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA13_transition[i] = DFA.unpackEncodedString(DFA13_transitionS[i]);
        }
    }

    class DFA13 extends DFA {

        public DFA13(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 13;
            this.eot = DFA13_eot;
            this.eof = DFA13_eof;
            this.min = DFA13_min;
            this.max = DFA13_max;
            this.accept = DFA13_accept;
            this.special = DFA13_special;
            this.transition = DFA13_transition;
        }
        public String getDescription() {
            return "375:1: type : ( simpleType | structuredType | pointerType );";
        }
    }
    static final String DFA14_eotS =
        "\33\uffff";
    static final String DFA14_eofS =
        "\33\uffff";
    static final String DFA14_minS =
        "\1\36\4\uffff\1\43\6\uffff\1\43\16\uffff";
    static final String DFA14_maxS =
        "\1\73\4\uffff\1\104\6\uffff\1\104\16\uffff";
    static final String DFA14_acceptS =
        "\1\uffff\1\1\1\2\5\uffff\1\3\13\uffff\1\4\6\uffff";
    static final String DFA14_specialS =
        "\33\uffff}>";
    static final String[] DFA14_transitionS = {
            "\1\2\3\uffff\1\1\3\uffff\1\5\6\uffff\5\2\5\uffff\4\10\1\14",
            "",
            "",
            "",
            "",
            "\2\10\5\uffff\1\10\13\uffff\1\2\7\uffff\1\10\3\uffff\1\10"+
            "\1\uffff\1\10",
            "",
            "",
            "",
            "",
            "",
            "",
            "\2\10\5\uffff\1\10\22\uffff\1\24\1\10\3\uffff\1\10\1\uffff"+
            "\1\10",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA14_eot = DFA.unpackEncodedString(DFA14_eotS);
    static final short[] DFA14_eof = DFA.unpackEncodedString(DFA14_eofS);
    static final char[] DFA14_min = DFA.unpackEncodedStringToUnsignedChars(DFA14_minS);
    static final char[] DFA14_max = DFA.unpackEncodedStringToUnsignedChars(DFA14_maxS);
    static final short[] DFA14_accept = DFA.unpackEncodedString(DFA14_acceptS);
    static final short[] DFA14_special = DFA.unpackEncodedString(DFA14_specialS);
    static final short[][] DFA14_transition;

    static {
        int numStates = DFA14_transitionS.length;
        DFA14_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA14_transition[i] = DFA.unpackEncodedString(DFA14_transitionS[i]);
        }
    }

    class DFA14 extends DFA {

        public DFA14(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 14;
            this.eot = DFA14_eot;
            this.eof = DFA14_eof;
            this.min = DFA14_min;
            this.max = DFA14_max;
            this.accept = DFA14_accept;
            this.special = DFA14_special;
            this.transition = DFA14_transition;
        }
        public String getDescription() {
            return "381:1: simpleType : ( scalarType | subrangeType | typeIdentifier | stringtype );";
        }
    }
    static final String DFA24_eotS =
        "\15\uffff";
    static final String DFA24_eofS =
        "\15\uffff";
    static final String DFA24_minS =
        "\1\43\2\uffff\1\36\11\uffff";
    static final String DFA24_maxS =
        "\1\104\2\uffff\1\104\11\uffff";
    static final String DFA24_acceptS =
        "\1\uffff\1\3\2\uffff\1\2\2\uffff\1\1\5\uffff";
    static final String DFA24_specialS =
        "\15\uffff}>";
    static final String[] DFA24_transitionS = {
            "\1\1\1\3\37\uffff\1\1",
            "",
            "",
            "\1\7\4\uffff\2\4\1\uffff\1\7\6\uffff\5\7\22\uffff\1\4",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA24_eot = DFA.unpackEncodedString(DFA24_eotS);
    static final short[] DFA24_eof = DFA.unpackEncodedString(DFA24_eofS);
    static final char[] DFA24_min = DFA.unpackEncodedStringToUnsignedChars(DFA24_minS);
    static final char[] DFA24_max = DFA.unpackEncodedStringToUnsignedChars(DFA24_maxS);
    static final short[] DFA24_accept = DFA.unpackEncodedString(DFA24_acceptS);
    static final short[] DFA24_special = DFA.unpackEncodedString(DFA24_specialS);
    static final short[][] DFA24_transition;

    static {
        int numStates = DFA24_transitionS.length;
        DFA24_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA24_transition[i] = DFA.unpackEncodedString(DFA24_transitionS[i]);
        }
    }

    class DFA24 extends DFA {

        public DFA24(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 24;
            this.eot = DFA24_eot;
            this.eof = DFA24_eof;
            this.min = DFA24_min;
            this.max = DFA24_max;
            this.accept = DFA24_accept;
            this.special = DFA24_special;
            this.transition = DFA24_transition;
        }
        public String getDescription() {
            return "()* loopback of 460:29: ( SEMI variant | SEMI )*";
        }
    }
    static final String DFA27_eotS =
        "\14\uffff";
    static final String DFA27_eofS =
        "\14\uffff";
    static final String DFA27_minS =
        "\1\44\1\46\12\uffff";
    static final String DFA27_maxS =
        "\1\44\1\133\12\uffff";
    static final String DFA27_acceptS =
        "\2\uffff\1\2\10\uffff\1\1";
    static final String DFA27_specialS =
        "\14\uffff}>";
    static final String[] DFA27_transitionS = {
            "\1\1",
            "\1\13\3\2\1\uffff\1\2\6\uffff\2\2\1\uffff\1\2\23\uffff\1\2"+
            "\21\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA27_eot = DFA.unpackEncodedString(DFA27_eotS);
    static final short[] DFA27_eof = DFA.unpackEncodedString(DFA27_eofS);
    static final char[] DFA27_min = DFA.unpackEncodedStringToUnsignedChars(DFA27_minS);
    static final char[] DFA27_max = DFA.unpackEncodedStringToUnsignedChars(DFA27_maxS);
    static final short[] DFA27_accept = DFA.unpackEncodedString(DFA27_acceptS);
    static final short[] DFA27_special = DFA.unpackEncodedString(DFA27_specialS);
    static final short[][] DFA27_transition;

    static {
        int numStates = DFA27_transitionS.length;
        DFA27_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA27_transition[i] = DFA.unpackEncodedString(DFA27_transitionS[i]);
        }
    }

    class DFA27 extends DFA {

        public DFA27(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 27;
            this.eot = DFA27_eot;
            this.eof = DFA27_eof;
            this.min = DFA27_min;
            this.max = DFA27_max;
            this.accept = DFA27_accept;
            this.special = DFA27_special;
            this.transition = DFA27_transition;
        }
        public String getDescription() {
            return "()* loopback of 492:32: ( SEMI variableDeclaration )*";
        }
    }
    static final String DFA35_eotS =
        "\20\uffff";
    static final String DFA35_eofS =
        "\20\uffff";
    static final String DFA35_minS =
        "\1\44\17\uffff";
    static final String DFA35_maxS =
        "\1\146\17\uffff";
    static final String DFA35_acceptS =
        "\1\uffff\1\1\1\2\15\uffff";
    static final String DFA35_specialS =
        "\20\uffff}>";
    static final String[] DFA35_transitionS = {
            "\1\2\1\uffff\1\2\7\uffff\1\1\25\uffff\2\2\5\uffff\1\2\16\uffff"+
            "\3\2\1\uffff\2\2\1\uffff\3\2\2\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA35_eot = DFA.unpackEncodedString(DFA35_eotS);
    static final short[] DFA35_eof = DFA.unpackEncodedString(DFA35_eofS);
    static final char[] DFA35_min = DFA.unpackEncodedStringToUnsignedChars(DFA35_minS);
    static final char[] DFA35_max = DFA.unpackEncodedStringToUnsignedChars(DFA35_maxS);
    static final short[] DFA35_accept = DFA.unpackEncodedString(DFA35_acceptS);
    static final short[] DFA35_special = DFA.unpackEncodedString(DFA35_specialS);
    static final short[][] DFA35_transition;

    static {
        int numStates = DFA35_transitionS.length;
        DFA35_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA35_transition[i] = DFA.unpackEncodedString(DFA35_transitionS[i]);
        }
    }

    class DFA35 extends DFA {

        public DFA35(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 35;
            this.eot = DFA35_eot;
            this.eof = DFA35_eof;
            this.min = DFA35_min;
            this.max = DFA35_max;
            this.accept = DFA35_accept;
            this.special = DFA35_special;
            this.transition = DFA35_transition;
        }
        public String getDescription() {
            return "550:1: statement : ( label COLON unlabelledStatement | unlabelledStatement );";
        }
    }
    static final String DFA36_eotS =
        "\17\uffff";
    static final String DFA36_eofS =
        "\17\uffff";
    static final String DFA36_minS =
        "\1\44\16\uffff";
    static final String DFA36_maxS =
        "\1\146\16\uffff";
    static final String DFA36_acceptS =
        "\1\uffff\1\1\6\uffff\1\2\6\uffff";
    static final String DFA36_specialS =
        "\17\uffff}>";
    static final String[] DFA36_transitionS = {
            "\1\1\1\uffff\1\1\35\uffff\1\1\1\10\5\uffff\1\1\16\uffff\1\1"+
            "\2\10\1\uffff\1\1\1\10\1\uffff\1\10\1\1\1\10\2\uffff\1\10",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA36_eot = DFA.unpackEncodedString(DFA36_eotS);
    static final short[] DFA36_eof = DFA.unpackEncodedString(DFA36_eofS);
    static final char[] DFA36_min = DFA.unpackEncodedStringToUnsignedChars(DFA36_minS);
    static final char[] DFA36_max = DFA.unpackEncodedStringToUnsignedChars(DFA36_maxS);
    static final short[] DFA36_accept = DFA.unpackEncodedString(DFA36_acceptS);
    static final short[] DFA36_special = DFA.unpackEncodedString(DFA36_specialS);
    static final short[][] DFA36_transition;

    static {
        int numStates = DFA36_transitionS.length;
        DFA36_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA36_transition[i] = DFA.unpackEncodedString(DFA36_transitionS[i]);
        }
    }

    class DFA36 extends DFA {

        public DFA36(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 36;
            this.eot = DFA36_eot;
            this.eof = DFA36_eof;
            this.min = DFA36_min;
            this.max = DFA36_max;
            this.accept = DFA36_accept;
            this.special = DFA36_special;
            this.transition = DFA36_transition;
        }
        public String getDescription() {
            return "555:1: unlabelledStatement : ( simpleStatement | structuredStatement );";
        }
    }
    static final String DFA37_eotS =
        "\22\uffff";
    static final String DFA37_eofS =
        "\22\uffff";
    static final String DFA37_minS =
        "\1\44\1\uffff\1\40\17\uffff";
    static final String DFA37_maxS =
        "\1\142\1\uffff\1\142\17\uffff";
    static final String DFA37_acceptS =
        "\1\uffff\1\1\1\uffff\1\3\1\4\10\uffff\1\2\4\uffff";
    static final String DFA37_specialS =
        "\22\uffff}>";
    static final String[] DFA37_transitionS = {
            "\1\4\1\uffff\1\2\35\uffff\1\4\6\uffff\1\1\16\uffff\1\3\3\uffff"+
            "\1\4\3\uffff\1\4",
            "",
            "\1\1\1\uffff\1\15\1\uffff\1\15\30\uffff\1\1\3\uffff\1\1\2"+
            "\uffff\1\15\3\uffff\1\1\1\uffff\1\1\23\uffff\1\15\3\uffff\1"+
            "\15",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA37_eot = DFA.unpackEncodedString(DFA37_eotS);
    static final short[] DFA37_eof = DFA.unpackEncodedString(DFA37_eofS);
    static final char[] DFA37_min = DFA.unpackEncodedStringToUnsignedChars(DFA37_minS);
    static final char[] DFA37_max = DFA.unpackEncodedStringToUnsignedChars(DFA37_maxS);
    static final short[] DFA37_accept = DFA.unpackEncodedString(DFA37_acceptS);
    static final short[] DFA37_special = DFA.unpackEncodedString(DFA37_specialS);
    static final short[][] DFA37_transition;

    static {
        int numStates = DFA37_transitionS.length;
        DFA37_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA37_transition[i] = DFA.unpackEncodedString(DFA37_transitionS[i]);
        }
    }

    class DFA37 extends DFA {

        public DFA37(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 37;
            this.eot = DFA37_eot;
            this.eof = DFA37_eof;
            this.min = DFA37_min;
            this.max = DFA37_max;
            this.accept = DFA37_accept;
            this.special = DFA37_special;
            this.transition = DFA37_transition;
        }
        public String getDescription() {
            return "560:1: simpleStatement : ( assignmentStatement | procedureStatement | gotoStatement | emptyStatement );";
        }
    }
    static final String DFA41_eotS =
        "\43\uffff";
    static final String DFA41_eofS =
        "\43\uffff";
    static final String DFA41_minS =
        "\1\40\42\uffff";
    static final String DFA41_maxS =
        "\1\145\42\uffff";
    static final String DFA41_acceptS =
        "\1\uffff\1\5\35\uffff\1\1\1\2\1\3\1\4";
    static final String DFA41_specialS =
        "\43\uffff}>";
    static final String[] DFA41_transitionS = {
            "\1\41\2\uffff\2\1\5\uffff\1\1\1\uffff\1\1\2\uffff\2\1\5\uffff"+
            "\1\1\6\uffff\1\37\1\1\1\uffff\1\1\1\40\1\1\1\uffff\1\1\3\uffff"+
            "\1\42\1\uffff\1\1\1\uffff\14\1\5\uffff\2\1\1\uffff\1\1\1\uffff"+
            "\1\1\1\uffff\2\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA41_eot = DFA.unpackEncodedString(DFA41_eotS);
    static final short[] DFA41_eof = DFA.unpackEncodedString(DFA41_eofS);
    static final char[] DFA41_min = DFA.unpackEncodedStringToUnsignedChars(DFA41_minS);
    static final char[] DFA41_max = DFA.unpackEncodedStringToUnsignedChars(DFA41_maxS);
    static final short[] DFA41_accept = DFA.unpackEncodedString(DFA41_acceptS);
    static final short[] DFA41_special = DFA.unpackEncodedString(DFA41_specialS);
    static final short[][] DFA41_transition;

    static {
        int numStates = DFA41_transitionS.length;
        DFA41_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA41_transition[i] = DFA.unpackEncodedString(DFA41_transitionS[i]);
        }
    }

    class DFA41 extends DFA {

        public DFA41(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 41;
            this.eot = DFA41_eot;
            this.eof = DFA41_eof;
            this.min = DFA41_min;
            this.max = DFA41_max;
            this.accept = DFA41_accept;
            this.special = DFA41_special;
            this.transition = DFA41_transition;
        }
        public String getDescription() {
            return "()* loopback of 590:7: ( LBRACK expression ( COMMA expression )* RBRACK | LBRACK2 expression ( COMMA expression )* RBRACK2 | DOT identifier | POINTER )*";
        }
    }
    static final String DFA43_eotS =
        "\26\uffff";
    static final String DFA43_eofS =
        "\26\uffff";
    static final String DFA43_minS =
        "\1\43\25\uffff";
    static final String DFA43_maxS =
        "\1\145\25\uffff";
    static final String DFA43_acceptS =
        "\1\uffff\1\2\15\uffff\1\1\6\uffff";
    static final String DFA43_specialS =
        "\26\uffff}>";
    static final String[] DFA43_transitionS = {
            "\2\1\5\uffff\1\1\1\uffff\1\17\11\uffff\1\1\7\uffff\1\1\1\uffff"+
            "\1\1\1\uffff\1\1\1\uffff\1\1\7\uffff\6\17\13\uffff\2\1\1\uffff"+
            "\1\1\1\uffff\1\1\1\uffff\2\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA43_eot = DFA.unpackEncodedString(DFA43_eotS);
    static final short[] DFA43_eof = DFA.unpackEncodedString(DFA43_eofS);
    static final char[] DFA43_min = DFA.unpackEncodedStringToUnsignedChars(DFA43_minS);
    static final char[] DFA43_max = DFA.unpackEncodedStringToUnsignedChars(DFA43_maxS);
    static final short[] DFA43_accept = DFA.unpackEncodedString(DFA43_acceptS);
    static final short[] DFA43_special = DFA.unpackEncodedString(DFA43_specialS);
    static final short[][] DFA43_transition;

    static {
        int numStates = DFA43_transitionS.length;
        DFA43_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA43_transition[i] = DFA.unpackEncodedString(DFA43_transitionS[i]);
        }
    }

    class DFA43 extends DFA {

        public DFA43(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 43;
            this.eot = DFA43_eot;
            this.eof = DFA43_eof;
            this.min = DFA43_min;
            this.max = DFA43_max;
            this.accept = DFA43_accept;
            this.special = DFA43_special;
            this.transition = DFA43_transition;
        }
        public String getDescription() {
            return "()* loopback of 599:4: ( ( EQUAL | NOT_EQUAL | LT | LE | GE | GT | IN ) simpleExpression )*";
        }
    }
    static final String DFA45_eotS =
        "\31\uffff";
    static final String DFA45_eofS =
        "\31\uffff";
    static final String DFA45_minS =
        "\1\43\30\uffff";
    static final String DFA45_maxS =
        "\1\145\30\uffff";
    static final String DFA45_acceptS =
        "\1\uffff\1\2\24\uffff\1\1\2\uffff";
    static final String DFA45_specialS =
        "\31\uffff}>";
    static final String[] DFA45_transitionS = {
            "\2\1\5\uffff\1\1\1\uffff\1\1\2\uffff\2\26\5\uffff\1\1\7\uffff"+
            "\1\1\1\uffff\1\1\1\uffff\1\1\1\uffff\1\1\7\uffff\6\1\1\26\12"+
            "\uffff\2\1\1\uffff\1\1\1\uffff\1\1\1\uffff\2\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA45_eot = DFA.unpackEncodedString(DFA45_eotS);
    static final short[] DFA45_eof = DFA.unpackEncodedString(DFA45_eofS);
    static final char[] DFA45_min = DFA.unpackEncodedStringToUnsignedChars(DFA45_minS);
    static final char[] DFA45_max = DFA.unpackEncodedStringToUnsignedChars(DFA45_maxS);
    static final short[] DFA45_accept = DFA.unpackEncodedString(DFA45_acceptS);
    static final short[] DFA45_special = DFA.unpackEncodedString(DFA45_specialS);
    static final short[][] DFA45_transition;

    static {
        int numStates = DFA45_transitionS.length;
        DFA45_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA45_transition[i] = DFA.unpackEncodedString(DFA45_transitionS[i]);
        }
    }

    class DFA45 extends DFA {

        public DFA45(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 45;
            this.eot = DFA45_eot;
            this.eof = DFA45_eof;
            this.min = DFA45_min;
            this.max = DFA45_max;
            this.accept = DFA45_accept;
            this.special = DFA45_special;
            this.transition = DFA45_transition;
        }
        public String getDescription() {
            return "()* loopback of 603:12: ( ( PLUS | MINUS | OR ) term )*";
        }
    }
    static final String DFA47_eotS =
        "\36\uffff";
    static final String DFA47_eofS =
        "\36\uffff";
    static final String DFA47_minS =
        "\1\43\35\uffff";
    static final String DFA47_maxS =
        "\1\145\35\uffff";
    static final String DFA47_acceptS =
        "\1\uffff\1\2\27\uffff\1\1\4\uffff";
    static final String DFA47_specialS =
        "\36\uffff}>";
    static final String[] DFA47_transitionS = {
            "\2\1\5\uffff\1\1\1\uffff\1\1\2\uffff\2\1\5\uffff\1\1\7\uffff"+
            "\1\1\1\uffff\1\1\1\uffff\1\1\1\uffff\1\1\7\uffff\7\1\5\31\5"+
            "\uffff\2\1\1\uffff\1\1\1\uffff\1\1\1\uffff\2\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA47_eot = DFA.unpackEncodedString(DFA47_eotS);
    static final short[] DFA47_eof = DFA.unpackEncodedString(DFA47_eofS);
    static final char[] DFA47_min = DFA.unpackEncodedStringToUnsignedChars(DFA47_minS);
    static final char[] DFA47_max = DFA.unpackEncodedStringToUnsignedChars(DFA47_maxS);
    static final short[] DFA47_accept = DFA.unpackEncodedString(DFA47_acceptS);
    static final short[] DFA47_special = DFA.unpackEncodedString(DFA47_specialS);
    static final short[][] DFA47_transition;

    static {
        int numStates = DFA47_transitionS.length;
        DFA47_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA47_transition[i] = DFA.unpackEncodedString(DFA47_transitionS[i]);
        }
    }

    class DFA47 extends DFA {

        public DFA47(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 47;
            this.eot = DFA47_eot;
            this.eof = DFA47_eof;
            this.min = DFA47_min;
            this.max = DFA47_max;
            this.accept = DFA47_accept;
            this.special = DFA47_special;
            this.transition = DFA47_transition;
        }
        public String getDescription() {
            return "()* loopback of 607:17: ( ( STAR | SLASH | DIV | MOD | AND ) signedFactor )*";
        }
    }
    static final String DFA48_eotS =
        "\16\uffff";
    static final String DFA48_eofS =
        "\16\uffff";
    static final String DFA48_minS =
        "\1\36\15\uffff";
    static final String DFA48_maxS =
        "\1\131\15\uffff";
    static final String DFA48_acceptS =
        "\1\uffff\1\1\1\2\1\3\12\uffff";
    static final String DFA48_specialS =
        "\16\uffff}>";
    static final String[] DFA48_transitionS = {
            "\1\3\3\uffff\1\3\3\uffff\1\3\6\uffff\2\3\1\1\1\2\1\3\13\uffff"+
            "\1\3\3\uffff\1\3\11\uffff\1\3\14\uffff\2\3",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA48_eot = DFA.unpackEncodedString(DFA48_eotS);
    static final short[] DFA48_eof = DFA.unpackEncodedString(DFA48_eofS);
    static final char[] DFA48_min = DFA.unpackEncodedStringToUnsignedChars(DFA48_minS);
    static final char[] DFA48_max = DFA.unpackEncodedStringToUnsignedChars(DFA48_maxS);
    static final short[] DFA48_accept = DFA.unpackEncodedString(DFA48_acceptS);
    static final short[] DFA48_special = DFA.unpackEncodedString(DFA48_specialS);
    static final short[][] DFA48_transition;

    static {
        int numStates = DFA48_transitionS.length;
        DFA48_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA48_transition[i] = DFA.unpackEncodedString(DFA48_transitionS[i]);
        }
    }

    class DFA48 extends DFA {

        public DFA48(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 48;
            this.eot = DFA48_eot;
            this.eof = DFA48_eof;
            this.min = DFA48_min;
            this.max = DFA48_max;
            this.accept = DFA48_accept;
            this.special = DFA48_special;
            this.transition = DFA48_transition;
        }
        public String getDescription() {
            return "611:7: ( PLUS | MINUS )?";
        }
    }
    static final String DFA49_eotS =
        "\56\uffff";
    static final String DFA49_eofS =
        "\56\uffff";
    static final String DFA49_minS =
        "\1\36\1\uffff\1\40\53\uffff";
    static final String DFA49_maxS =
        "\1\131\1\uffff\1\145\53\uffff";
    static final String DFA49_acceptS =
        "\1\uffff\1\1\1\uffff\1\2\1\4\4\uffff\1\5\1\uffff\1\6\41\uffff\1"+
        "\3";
    static final String DFA49_specialS =
        "\56\uffff}>";
    static final String[] DFA49_transitionS = {
            "\1\4\3\uffff\1\3\3\uffff\1\2\6\uffff\2\4\2\uffff\1\4\13\uffff"+
            "\1\11\3\uffff\1\11\11\uffff\1\1\14\uffff\1\13\1\4",
            "",
            "\1\1\1\uffff\1\55\2\1\5\uffff\1\1\1\uffff\1\1\2\uffff\2\1"+
            "\5\uffff\1\1\6\uffff\2\1\1\uffff\3\1\1\uffff\1\1\3\uffff\1\1"+
            "\3\uffff\14\1\5\uffff\2\1\1\uffff\1\1\1\uffff\1\1\1\uffff\2"+
            "\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA49_eot = DFA.unpackEncodedString(DFA49_eotS);
    static final short[] DFA49_eof = DFA.unpackEncodedString(DFA49_eofS);
    static final char[] DFA49_min = DFA.unpackEncodedStringToUnsignedChars(DFA49_minS);
    static final char[] DFA49_max = DFA.unpackEncodedStringToUnsignedChars(DFA49_maxS);
    static final short[] DFA49_accept = DFA.unpackEncodedString(DFA49_acceptS);
    static final short[] DFA49_special = DFA.unpackEncodedString(DFA49_specialS);
    static final short[][] DFA49_transition;

    static {
        int numStates = DFA49_transitionS.length;
        DFA49_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA49_transition[i] = DFA.unpackEncodedString(DFA49_transitionS[i]);
        }
    }

    class DFA49 extends DFA {

        public DFA49(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 49;
            this.eot = DFA49_eot;
            this.eof = DFA49_eof;
            this.min = DFA49_min;
            this.max = DFA49_max;
            this.accept = DFA49_accept;
            this.special = DFA49_special;
            this.transition = DFA49_transition;
        }
        public String getDescription() {
            return "614:1: factor : ( variable | LPAREN expression RPAREN | functionDesignator | unsignedConstant | set | NOT factor );";
        }
    }
    static final String DFA54_eotS =
        "\20\uffff";
    static final String DFA54_eofS =
        "\20\uffff";
    static final String DFA54_minS =
        "\1\36\17\uffff";
    static final String DFA54_maxS =
        "\1\131\17\uffff";
    static final String DFA54_acceptS =
        "\1\uffff\1\1\14\uffff\1\2\1\uffff";
    static final String DFA54_specialS =
        "\20\uffff}>";
    static final String[] DFA54_transitionS = {
            "\1\1\3\uffff\1\1\3\uffff\1\1\6\uffff\5\1\13\uffff\1\1\1\16"+
            "\2\uffff\1\1\1\16\10\uffff\1\1\14\uffff\2\1",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA54_eot = DFA.unpackEncodedString(DFA54_eotS);
    static final short[] DFA54_eof = DFA.unpackEncodedString(DFA54_eofS);
    static final char[] DFA54_min = DFA.unpackEncodedStringToUnsignedChars(DFA54_minS);
    static final char[] DFA54_max = DFA.unpackEncodedStringToUnsignedChars(DFA54_maxS);
    static final short[] DFA54_accept = DFA.unpackEncodedString(DFA54_acceptS);
    static final short[] DFA54_special = DFA.unpackEncodedString(DFA54_specialS);
    static final short[][] DFA54_transition;

    static {
        int numStates = DFA54_transitionS.length;
        DFA54_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA54_transition[i] = DFA.unpackEncodedString(DFA54_transitionS[i]);
        }
    }

    class DFA54 extends DFA {

        public DFA54(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 54;
            this.eot = DFA54_eot;
            this.eof = DFA54_eof;
            this.min = DFA54_min;
            this.max = DFA54_max;
            this.accept = DFA54_accept;
            this.special = DFA54_special;
            this.transition = DFA54_transition;
        }
        public String getDescription() {
            return "645:1: elementList : ( element ( COMMA element )* | );";
        }
    }
    static final String DFA61_eotS =
        "\12\uffff";
    static final String DFA61_eofS =
        "\12\uffff";
    static final String DFA61_minS =
        "\1\44\1\36\10\uffff";
    static final String DFA61_maxS =
        "\1\104\1\136\10\uffff";
    static final String DFA61_acceptS =
        "\2\uffff\1\2\1\uffff\1\1\5\uffff";
    static final String DFA61_specialS =
        "\12\uffff}>";
    static final String[] DFA61_transitionS = {
            "\1\1\37\uffff\1\2",
            "\1\4\7\uffff\1\4\6\uffff\5\4\54\uffff\1\2",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA61_eot = DFA.unpackEncodedString(DFA61_eotS);
    static final short[] DFA61_eof = DFA.unpackEncodedString(DFA61_eofS);
    static final char[] DFA61_min = DFA.unpackEncodedStringToUnsignedChars(DFA61_minS);
    static final char[] DFA61_max = DFA.unpackEncodedStringToUnsignedChars(DFA61_maxS);
    static final short[] DFA61_accept = DFA.unpackEncodedString(DFA61_acceptS);
    static final short[] DFA61_special = DFA.unpackEncodedString(DFA61_specialS);
    static final short[][] DFA61_transition;

    static {
        int numStates = DFA61_transitionS.length;
        DFA61_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA61_transition[i] = DFA.unpackEncodedString(DFA61_transitionS[i]);
        }
    }

    class DFA61 extends DFA {

        public DFA61(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 61;
            this.eot = DFA61_eot;
            this.eof = DFA61_eof;
            this.min = DFA61_min;
            this.max = DFA61_max;
            this.accept = DFA61_accept;
            this.special = DFA61_special;
            this.transition = DFA61_transition;
        }
        public String getDescription() {
            return "()* loopback of 712:25: ( SEMI caseListElement )*";
        }
    }
 

    public static final BitSet FOLLOW_programHeading_in_program521 = new BitSet(new long[]{0x002C0B8080000000L,0x0000000008000200L});
    public static final BitSet FOLLOW_INTERFACE_in_program524 = new BitSet(new long[]{0x002C0B8080000000L,0x0000000008000200L});
    public static final BitSet FOLLOW_block_in_program535 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_DOT_in_program543 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PROGRAM_in_programHeading561 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_identifier_in_programHeading564 = new BitSet(new long[]{0x0000001400000000L});
    public static final BitSet FOLLOW_LPAREN_in_programHeading567 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_identifierList_in_programHeading570 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_RPAREN_in_programHeading572 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_SEMI_in_programHeading577 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_UNIT_in_programHeading586 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_identifier_in_programHeading589 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_SEMI_in_programHeading591 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENT_in_identifier606 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_labelDeclarationPart_in_block625 = new BitSet(new long[]{0x002C0B8080000000L,0x0000000008000200L});
    public static final BitSet FOLLOW_constantDefinitionPart_in_block635 = new BitSet(new long[]{0x002C0B8080000000L,0x0000000008000200L});
    public static final BitSet FOLLOW_typeDefinitionPart_in_block645 = new BitSet(new long[]{0x002C0B8080000000L,0x0000000008000200L});
    public static final BitSet FOLLOW_variableDeclarationPart_in_block655 = new BitSet(new long[]{0x002C0B8080000000L,0x0000000008000200L});
    public static final BitSet FOLLOW_procedureAndFunctionDeclarationPart_in_block665 = new BitSet(new long[]{0x002C0B8080000000L,0x0000000008000200L});
    public static final BitSet FOLLOW_usesUnitsPart_in_block675 = new BitSet(new long[]{0x002C0B8080000000L,0x0000000008000200L});
    public static final BitSet FOLLOW_IMPLEMENTATION_in_block685 = new BitSet(new long[]{0x002C0B8080000000L,0x0000000008000200L});
    public static final BitSet FOLLOW_compoundStatement_in_block702 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_USES_in_usesUnitsPart719 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_identifierList_in_usesUnitsPart722 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_SEMI_in_usesUnitsPart724 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LABEL_in_labelDeclarationPart742 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_label_in_labelDeclarationPart745 = new BitSet(new long[]{0x0000041000000000L});
    public static final BitSet FOLLOW_COMMA_in_labelDeclarationPart749 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_label_in_labelDeclarationPart752 = new BitSet(new long[]{0x0000041000000000L});
    public static final BitSet FOLLOW_SEMI_in_labelDeclarationPart757 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unsignedInteger_in_label775 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CONST_in_constantDefinitionPart792 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_constantDefinition_in_constantDefinitionPart795 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_SEMI_in_constantDefinitionPart799 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_constantDefinition_in_constantDefinitionPart802 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_SEMI_in_constantDefinitionPart807 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_identifier_in_constantDefinition825 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_EQUAL_in_constantDefinition827 = new BitSet(new long[]{0x0003E04040000000L});
    public static final BitSet FOLLOW_constant_in_constantDefinition830 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CHR_in_constantChr847 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_LPAREN_in_constantChr850 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_unsignedInteger_in_constantChr853 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_RPAREN_in_constantChr855 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unsignedNumber_in_constant873 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_sign_in_constant883 = new BitSet(new long[]{0x0000400040000000L});
    public static final BitSet FOLLOW_unsignedNumber_in_constant887 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_identifier_in_constant906 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_sign_in_constant916 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_identifier_in_constant920 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_string_in_constant944 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_constantChr_in_constant952 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unsignedInteger_in_unsignedNumber969 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unsignedReal_in_unsignedNumber977 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUM_INT_in_unsignedInteger994 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUM_REAL_in_unsignedReal1011 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_sign0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_LITERAL_in_string1049 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_TYPE_in_typeDefinitionPart1066 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_typeDefinition_in_typeDefinitionPart1069 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_SEMI_in_typeDefinitionPart1073 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_typeDefinition_in_typeDefinitionPart1076 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_SEMI_in_typeDefinitionPart1081 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_identifier_in_typeDefinition1100 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_EQUAL_in_typeDefinition1104 = new BitSet(new long[]{0x9FABE04440000000L,0x00000000000001C8L});
    public static final BitSet FOLLOW_type_in_typeDefinition1117 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_functionType_in_typeDefinition1127 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_procedureType_in_typeDefinition1139 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FUNCTION_in_functionType1165 = new BitSet(new long[]{0x0010000400000000L});
    public static final BitSet FOLLOW_formalParameterList_in_functionType1169 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_COLON_in_functionType1173 = new BitSet(new long[]{0x0F80004000000000L});
    public static final BitSet FOLLOW_resultType_in_functionType1176 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PROCEDURE_in_procedureType1193 = new BitSet(new long[]{0x0000000400000002L});
    public static final BitSet FOLLOW_formalParameterList_in_procedureType1197 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleType_in_type1216 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_structuredType_in_type1224 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_pointerType_in_type1232 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_scalarType_in_simpleType1249 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_subrangeType_in_simpleType1257 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeIdentifier_in_simpleType1265 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_stringtype_in_simpleType1273 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_scalarType1290 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_identifierList_in_scalarType1292 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_RPAREN_in_scalarType1294 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_constant_in_subrangeType1325 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_DOTDOT_in_subrangeType1327 = new BitSet(new long[]{0x0003E04040000000L});
    public static final BitSet FOLLOW_constant_in_subrangeType1330 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_identifier_in_typeIdentifier1347 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CHAR_in_typeIdentifier1355 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BOOLEAN_in_typeIdentifier1363 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INTEGER_in_typeIdentifier1371 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_REAL_in_typeIdentifier1379 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_in_typeIdentifier1387 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PACKED_in_structuredType1405 = new BitSet(new long[]{0x9000000000000000L,0x00000000000000C8L});
    public static final BitSet FOLLOW_unpackedStructuredType_in_structuredType1408 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unpackedStructuredType_in_structuredType1414 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_arrayType_in_unpackedStructuredType1431 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_recordType_in_unpackedStructuredType1439 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_setType_in_unpackedStructuredType1447 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fileType_in_unpackedStructuredType1455 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_in_stringtype1472 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_LBRACK_in_stringtype1475 = new BitSet(new long[]{0x0000404040000000L});
    public static final BitSet FOLLOW_identifier_in_stringtype1479 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_unsignedNumber_in_stringtype1481 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_RBRACK_in_stringtype1484 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ARRAY_in_arrayType1502 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_LBRACK_in_arrayType1505 = new BitSet(new long[]{0x0F83E04440000000L});
    public static final BitSet FOLLOW_typeList_in_arrayType1508 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_RBRACK_in_arrayType1510 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_OF_in_arrayType1513 = new BitSet(new long[]{0x9F83E04440000000L,0x00000000000001C8L});
    public static final BitSet FOLLOW_componentType_in_arrayType1516 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ARRAY_in_arrayType1524 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_LBRACK2_in_arrayType1527 = new BitSet(new long[]{0x0F83E04440000000L});
    public static final BitSet FOLLOW_typeList_in_arrayType1530 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000004L});
    public static final BitSet FOLLOW_RBRACK2_in_arrayType1532 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_OF_in_arrayType1535 = new BitSet(new long[]{0x9F83E04440000000L,0x00000000000001C8L});
    public static final BitSet FOLLOW_componentType_in_arrayType1538 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_indexType_in_typeList1549 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_COMMA_in_typeList1553 = new BitSet(new long[]{0x0F83E04440000000L});
    public static final BitSet FOLLOW_indexType_in_typeList1555 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_simpleType_in_indexType1582 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_type_in_componentType1599 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RECORD_in_recordType1616 = new BitSet(new long[]{0x0000004000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_fieldList_in_recordType1619 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_END_in_recordType1621 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_fixedPart_in_fieldList1641 = new BitSet(new long[]{0x0000001000000002L});
    public static final BitSet FOLLOW_SEMI_in_fieldList1645 = new BitSet(new long[]{0x0000004000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_variantPart_in_fieldList1647 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SEMI_in_fieldList1651 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variantPart_in_fieldList1674 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_recordSection_in_fixedPart1713 = new BitSet(new long[]{0x0000001000000002L});
    public static final BitSet FOLLOW_SEMI_in_fixedPart1717 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_recordSection_in_fixedPart1720 = new BitSet(new long[]{0x0000001000000002L});
    public static final BitSet FOLLOW_identifierList_in_recordSection1740 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_COLON_in_recordSection1742 = new BitSet(new long[]{0x9F83E04440000000L,0x00000000000001C8L});
    public static final BitSet FOLLOW_type_in_recordSection1744 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CASE_in_variantPart1772 = new BitSet(new long[]{0x0F80004000000000L});
    public static final BitSet FOLLOW_tag_in_variantPart1775 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_OF_in_variantPart1777 = new BitSet(new long[]{0x0003E04040000000L});
    public static final BitSet FOLLOW_variant_in_variantPart1780 = new BitSet(new long[]{0x0000001000000002L});
    public static final BitSet FOLLOW_SEMI_in_variantPart1784 = new BitSet(new long[]{0x0003E04040000000L});
    public static final BitSet FOLLOW_variant_in_variantPart1787 = new BitSet(new long[]{0x0000001000000002L});
    public static final BitSet FOLLOW_SEMI_in_variantPart1791 = new BitSet(new long[]{0x0000001000000002L});
    public static final BitSet FOLLOW_identifier_in_tag1815 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_COLON_in_tag1817 = new BitSet(new long[]{0x0F80004000000000L});
    public static final BitSet FOLLOW_typeIdentifier_in_tag1821 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeIdentifier_in_tag1844 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_constList_in_variant1880 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_COLON_in_variant1884 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_LPAREN_in_variant1892 = new BitSet(new long[]{0x0000004000000000L,0x0000000000000020L});
    public static final BitSet FOLLOW_fieldList_in_variant1895 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_RPAREN_in_variant1897 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SET_in_setType1915 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_OF_in_setType1918 = new BitSet(new long[]{0x0F83E04440000000L});
    public static final BitSet FOLLOW_baseType_in_setType1921 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleType_in_baseType1938 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FILE_in_fileType1955 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_OF_in_fileType1958 = new BitSet(new long[]{0x9F83E04440000000L,0x00000000000001C8L});
    public static final BitSet FOLLOW_type_in_fileType1961 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FILE_in_fileType1969 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_POINTER_in_pointerType1986 = new BitSet(new long[]{0x0F80004000000000L});
    public static final BitSet FOLLOW_typeIdentifier_in_pointerType1989 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_VAR_in_variableDeclarationPart2008 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_variableDeclaration_in_variableDeclarationPart2011 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_SEMI_in_variableDeclarationPart2015 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_variableDeclaration_in_variableDeclarationPart2018 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_SEMI_in_variableDeclarationPart2023 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_identifierList_in_variableDeclaration2041 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_COLON_in_variableDeclaration2045 = new BitSet(new long[]{0x9F83E04440000000L,0x00000000000001C8L});
    public static final BitSet FOLLOW_type_in_variableDeclaration2050 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_procedureOrFunctionDeclaration_in_procedureAndFunctionDeclarationPart2067 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_SEMI_in_procedureAndFunctionDeclarationPart2069 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_procedureDeclaration_in_procedureOrFunctionDeclaration2087 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_functionDeclaration_in_procedureOrFunctionDeclaration2095 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PROCEDURE_in_procedureDeclaration2112 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_identifier_in_procedureDeclaration2115 = new BitSet(new long[]{0x0000001400000000L});
    public static final BitSet FOLLOW_formalParameterList_in_procedureDeclaration2118 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_SEMI_in_procedureDeclaration2122 = new BitSet(new long[]{0x002C0B8080000000L,0x0000000008000200L});
    public static final BitSet FOLLOW_block_in_procedureDeclaration2131 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_formalParameterList2148 = new BitSet(new long[]{0x0028004000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_formalParameterSection_in_formalParameterList2150 = new BitSet(new long[]{0x0000001800000000L});
    public static final BitSet FOLLOW_SEMI_in_formalParameterList2154 = new BitSet(new long[]{0x0028004000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_formalParameterSection_in_formalParameterList2156 = new BitSet(new long[]{0x0000001800000000L});
    public static final BitSet FOLLOW_RPAREN_in_formalParameterList2161 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_parameterGroup_in_formalParameterSection2197 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_VAR_in_formalParameterSection2205 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_parameterGroup_in_formalParameterSection2208 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FUNCTION_in_formalParameterSection2216 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_parameterGroup_in_formalParameterSection2219 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PROCEDURE_in_formalParameterSection2227 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_parameterGroup_in_formalParameterSection2230 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_identifierList_in_parameterGroup2250 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_COLON_in_parameterGroup2252 = new BitSet(new long[]{0x0F80004000000000L});
    public static final BitSet FOLLOW_typeIdentifier_in_parameterGroup2256 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_identifier_in_identifierList2287 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_COMMA_in_identifierList2291 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_identifier_in_identifierList2293 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_constant_in_constList2324 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_COMMA_in_constList2328 = new BitSet(new long[]{0x0003E04040000000L});
    public static final BitSet FOLLOW_constant_in_constList2330 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_FUNCTION_in_functionDeclaration2361 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_identifier_in_functionDeclaration2364 = new BitSet(new long[]{0x0010000400000000L});
    public static final BitSet FOLLOW_formalParameterList_in_functionDeclaration2367 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_COLON_in_functionDeclaration2371 = new BitSet(new long[]{0x0F80004000000000L});
    public static final BitSet FOLLOW_resultType_in_functionDeclaration2374 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_SEMI_in_functionDeclaration2376 = new BitSet(new long[]{0x002C0B8080000000L,0x0000000008000200L});
    public static final BitSet FOLLOW_block_in_functionDeclaration2385 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeIdentifier_in_resultType2402 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_label_in_statement2419 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_COLON_in_statement2421 = new BitSet(new long[]{0x002C0BC080000000L,0x0000004A9C000A20L});
    public static final BitSet FOLLOW_unlabelledStatement_in_statement2424 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unlabelledStatement_in_statement2432 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_simpleStatement_in_unlabelledStatement2449 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_structuredStatement_in_unlabelledStatement2457 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assignmentStatement_in_simpleStatement2474 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_procedureStatement_in_simpleStatement2482 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_gotoStatement_in_simpleStatement2490 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_emptyStatement_in_simpleStatement2498 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_assignmentStatement2515 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_ASSIGN_in_assignmentStatement2517 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_expression_in_assignmentStatement2520 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_AT_in_variable2541 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_identifier_in_variable2544 = new BitSet(new long[]{0x2000000100000002L,0x0000000000000102L});
    public static final BitSet FOLLOW_identifier_in_variable2555 = new BitSet(new long[]{0x2000000100000002L,0x0000000000000102L});
    public static final BitSet FOLLOW_LBRACK_in_variable2573 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_expression_in_variable2576 = new BitSet(new long[]{0x4000040000000000L});
    public static final BitSet FOLLOW_COMMA_in_variable2580 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_expression_in_variable2583 = new BitSet(new long[]{0x4000040000000000L});
    public static final BitSet FOLLOW_RBRACK_in_variable2587 = new BitSet(new long[]{0x2000000100000002L,0x0000000000000102L});
    public static final BitSet FOLLOW_LBRACK2_in_variable2598 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_expression_in_variable2601 = new BitSet(new long[]{0x0000040000000000L,0x0000000000000004L});
    public static final BitSet FOLLOW_COMMA_in_variable2605 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_expression_in_variable2608 = new BitSet(new long[]{0x0000040000000000L,0x0000000000000004L});
    public static final BitSet FOLLOW_RBRACK2_in_variable2612 = new BitSet(new long[]{0x2000000100000002L,0x0000000000000102L});
    public static final BitSet FOLLOW_DOT_in_variable2623 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_identifier_in_variable2626 = new BitSet(new long[]{0x2000000100000002L,0x0000000000000102L});
    public static final BitSet FOLLOW_POINTER_in_variable2636 = new BitSet(new long[]{0x2000000100000002L,0x0000000000000102L});
    public static final BitSet FOLLOW_simpleExpression_in_expression2663 = new BitSet(new long[]{0x0000100000000002L,0x000000000003F000L});
    public static final BitSet FOLLOW_EQUAL_in_expression2671 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_NOT_EQUAL_in_expression2676 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_LT_in_expression2681 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_LE_in_expression2686 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_GE_in_expression2691 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_GT_in_expression2696 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_IN_in_expression2701 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_simpleExpression_in_expression2705 = new BitSet(new long[]{0x0000100000000002L,0x000000000003F000L});
    public static final BitSet FOLLOW_term_in_simpleExpression2725 = new BitSet(new long[]{0x0001800000000002L,0x0000000000040000L});
    public static final BitSet FOLLOW_PLUS_in_simpleExpression2730 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_MINUS_in_simpleExpression2735 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_OR_in_simpleExpression2740 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_term_in_simpleExpression2744 = new BitSet(new long[]{0x0001800000000002L,0x0000000000040000L});
    public static final BitSet FOLLOW_signedFactor_in_term2761 = new BitSet(new long[]{0x0000000000000002L,0x0000000000F80000L});
    public static final BitSet FOLLOW_STAR_in_term2766 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_SLASH_in_term2771 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_DIV_in_term2776 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_MOD_in_term2781 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_AND_in_term2786 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_signedFactor_in_term2790 = new BitSet(new long[]{0x0000000000000002L,0x0000000000F80000L});
    public static final BitSet FOLLOW_PLUS_in_signedFactor2811 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_MINUS_in_signedFactor2814 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_factor_in_signedFactor2819 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_factor2836 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_factor2844 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_expression_in_factor2847 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_RPAREN_in_factor2849 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_functionDesignator_in_factor2858 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unsignedConstant_in_factor2866 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_factor2874 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOT_in_factor2882 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_factor_in_factor2885 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_unsignedNumber_in_unsignedConstant2902 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_constantChr_in_unsignedConstant2910 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_string_in_unsignedConstant2927 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NIL_in_unsignedConstant2935 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_identifier_in_functionDesignator2955 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_LPAREN_in_functionDesignator2957 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_parameterList_in_functionDesignator2961 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_RPAREN_in_functionDesignator2963 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_actualParameter_in_parameterList2994 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_COMMA_in_parameterList2998 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_actualParameter_in_parameterList3000 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_LBRACK_in_set3031 = new BitSet(new long[]{0x6003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_elementList_in_set3033 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_RBRACK_in_set3035 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LBRACK2_in_set3053 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000806L});
    public static final BitSet FOLLOW_elementList_in_set3055 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000004L});
    public static final BitSet FOLLOW_RBRACK2_in_set3057 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_element_in_elementList3084 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_COMMA_in_elementList3088 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_element_in_elementList3091 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_expression_in_element3117 = new BitSet(new long[]{0x0040000000000002L});
    public static final BitSet FOLLOW_DOTDOT_in_element3121 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_expression_in_element3124 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_identifier_in_procedureStatement3146 = new BitSet(new long[]{0x0000000400000002L});
    public static final BitSet FOLLOW_LPAREN_in_procedureStatement3150 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_parameterList_in_procedureStatement3154 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_RPAREN_in_procedureStatement3156 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_actualParameter3190 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_GOTO_in_gotoStatement3207 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_label_in_gotoStatement3210 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_compoundStatement_in_structuredStatement3259 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_conditionalStatement_in_structuredStatement3267 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_repetetiveStatement_in_structuredStatement3275 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_withStatement_in_structuredStatement3283 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BEGIN_in_compoundStatement3300 = new BitSet(new long[]{0x002C4BC080000000L,0x0000004A9C000A20L});
    public static final BitSet FOLLOW_statements_in_compoundStatement3305 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_END_in_compoundStatement3313 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_statement_in_statements3331 = new BitSet(new long[]{0x0000001000000002L});
    public static final BitSet FOLLOW_SEMI_in_statements3335 = new BitSet(new long[]{0x002C4BC080000000L,0x0000004A9C000A20L});
    public static final BitSet FOLLOW_statement_in_statements3337 = new BitSet(new long[]{0x0000001000000002L});
    public static final BitSet FOLLOW_ifStatement_in_conditionalStatement3368 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_caseStatement_in_conditionalStatement3376 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IF_in_ifStatement3393 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_expression_in_ifStatement3396 = new BitSet(new long[]{0x0000000000000000L,0x0000000020000000L});
    public static final BitSet FOLLOW_THEN_in_ifStatement3398 = new BitSet(new long[]{0x002C4BC080000000L,0x0000004A9C000A20L});
    public static final BitSet FOLLOW_statement_in_ifStatement3401 = new BitSet(new long[]{0x0000000000000002L,0x0000000040000000L});
    public static final BitSet FOLLOW_ELSE_in_ifStatement3428 = new BitSet(new long[]{0x002C4BC080000000L,0x0000004A9C000A20L});
    public static final BitSet FOLLOW_statement_in_ifStatement3431 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CASE_in_caseStatement3455 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_expression_in_caseStatement3458 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_OF_in_caseStatement3460 = new BitSet(new long[]{0x0003E04040000000L});
    public static final BitSet FOLLOW_caseListElement_in_caseStatement3471 = new BitSet(new long[]{0x0000001000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_SEMI_in_caseStatement3475 = new BitSet(new long[]{0x0003E04040000000L});
    public static final BitSet FOLLOW_caseListElement_in_caseStatement3478 = new BitSet(new long[]{0x0000001000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_SEMI_in_caseStatement3491 = new BitSet(new long[]{0x0000000000000000L,0x0000000040000000L});
    public static final BitSet FOLLOW_ELSE_in_caseStatement3494 = new BitSet(new long[]{0x002C4BC080000000L,0x0000004A9C000A20L});
    public static final BitSet FOLLOW_statements_in_caseStatement3497 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_END_in_caseStatement3508 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_constList_in_caseListElement3526 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_COLON_in_caseListElement3528 = new BitSet(new long[]{0x002C4BC080000000L,0x0000004A9C000A20L});
    public static final BitSet FOLLOW_statement_in_caseListElement3531 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_whileStatement_in_repetetiveStatement3548 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_repeatStatement_in_repetetiveStatement3556 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_forStatement_in_repetetiveStatement3564 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHILE_in_whileStatement3581 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_expression_in_whileStatement3584 = new BitSet(new long[]{0x0000000000000000L,0x0000000100000000L});
    public static final BitSet FOLLOW_DO_in_whileStatement3586 = new BitSet(new long[]{0x002C4BC080000000L,0x0000004A9C000A20L});
    public static final BitSet FOLLOW_statement_in_whileStatement3589 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_REPEAT_in_repeatStatement3606 = new BitSet(new long[]{0x002C4BC080000000L,0x0000004A9C000A20L});
    public static final BitSet FOLLOW_statements_in_repeatStatement3609 = new BitSet(new long[]{0x0000000000000000L,0x0000000400000000L});
    public static final BitSet FOLLOW_UNTIL_in_repeatStatement3611 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_expression_in_repeatStatement3614 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FOR_in_forStatement3631 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_identifier_in_forStatement3634 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_ASSIGN_in_forStatement3636 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_forList_in_forStatement3639 = new BitSet(new long[]{0x0000000000000000L,0x0000000100000000L});
    public static final BitSet FOLLOW_DO_in_forStatement3641 = new BitSet(new long[]{0x002C4BC080000000L,0x0000004A9C000A20L});
    public static final BitSet FOLLOW_statement_in_forStatement3644 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_initialValue_in_forList3661 = new BitSet(new long[]{0x0000000000000000L,0x0000003000000000L});
    public static final BitSet FOLLOW_TO_in_forList3664 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_DOWNTO_in_forList3669 = new BitSet(new long[]{0x2003E04440000000L,0x0000000003000802L});
    public static final BitSet FOLLOW_finalValue_in_forList3673 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_initialValue3690 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_expression_in_finalValue3707 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WITH_in_withStatement3724 = new BitSet(new long[]{0x0000004000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_recordVariableList_in_withStatement3727 = new BitSet(new long[]{0x0000000000000000L,0x0000000100000000L});
    public static final BitSet FOLLOW_DO_in_withStatement3729 = new BitSet(new long[]{0x002C4BC080000000L,0x0000004A9C000A20L});
    public static final BitSet FOLLOW_statement_in_withStatement3732 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_variable_in_recordVariableList3749 = new BitSet(new long[]{0x0000040000000002L});
    public static final BitSet FOLLOW_COMMA_in_recordVariableList3753 = new BitSet(new long[]{0x0000004000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_variable_in_recordVariableList3756 = new BitSet(new long[]{0x0000040000000002L});

}