import java.io.*;

public class Unit extends Symbol implements Serializable {
    public Unit(String name) {
		super(name);
    }
}
